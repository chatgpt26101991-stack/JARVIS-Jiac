package com.jarvis.openandroid.vision

/** Reglas sencillas y probables mediante pruebas JVM sin llamar a servicios externos. */
object VisionRequestPolicy {
    const val MODEL = "qwen/qwen3.6-27b"
    const val MAX_IMAGE_BYTES = 4 * 1024 * 1024
    const val ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"

    fun validateJpeg(photo: ByteArray) {
        require(photo.size in 4..MAX_IMAGE_BYTES) { "Fotografía vacía o demasiado grande." }
        require(photo[0] == 0xFF.toByte() && photo[1] == 0xD8.toByte() &&
            photo[photo.size - 2] == 0xFF.toByte() && photo.last() == 0xD9.toByte()) {
            "La foto debe ser una imagen JPEG válida."
        }
    }

    fun isGroqEndpoint(endpoint: String): Boolean = try {
        val uri = java.net.URI(endpoint.trim())
        uri.scheme.equals("https", true) && uri.host.equals("api.groq.com", true) &&
            uri.path == "/openai/v1/chat/completions" && uri.rawUserInfo == null &&
            uri.rawQuery == null && uri.rawFragment == null
    } catch (_: Exception) { false }
}
