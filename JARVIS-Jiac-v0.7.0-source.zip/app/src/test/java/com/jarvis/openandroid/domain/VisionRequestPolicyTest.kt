package com.jarvis.openandroid.domain

import com.jarvis.openandroid.vision.VisionRequestPolicy
import org.junit.Assert.*
import org.junit.Test

class VisionRequestPolicyTest {
    @Test fun groqEndpointStrict() {
        assertTrue(VisionRequestPolicy.isGroqEndpoint("https://api.groq.com/openai/v1/chat/completions"))
        assertFalse(VisionRequestPolicy.isGroqEndpoint("https://example.com/openai/v1/chat/completions"))
        assertFalse(VisionRequestPolicy.isGroqEndpoint("http://api.groq.com/openai/v1/chat/completions"))
        assertFalse(VisionRequestPolicy.isGroqEndpoint("https://api.groq.com@other.invalid/openai/v1/chat/completions"))
    }

    @Test fun acceptsJpegBoundaries() {
        VisionRequestPolicy.validateJpeg(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xD9.toByte()))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsNonJpeg() { VisionRequestPolicy.validateJpeg(byteArrayOf(1,2,3,4)) }
}
