package com.jarvis.openandroid

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.jarvis.openandroid.domain.AssistantAction
import com.jarvis.openandroid.speech.TtsSpeaker
import com.jarvis.openandroid.ui.JarvisScreen
import com.jarvis.openandroid.ui.JarvisViewModel
import com.jarvis.openandroid.wake.JarvisListeningService
import com.jarvis.openandroid.wake.OfflineModelInstaller
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var model: JarvisViewModel
    private lateinit var speaker: TtsSpeaker
    private var recognizer: SpeechRecognizer? = null
    private val activityScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val modelReady = MutableStateFlow(false)
    private val downloading = MutableStateFlow(false)
    private val downloadProgress = MutableStateFlow(OfflineModelInstaller.Progress())
    private val requestWakePermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchWakeService()
        } else {
            model.addJarvisAnswer("Para activar Jarvis en segundo plano debes permitir el micrófono.")
        }
    }


    private val requestMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening() else model.addJarvisAnswer("Sin permiso de micrófono puedes seguir escribiendo comandos.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        model = ViewModelProvider(this)[JarvisViewModel::class.java]
        speaker = TtsSpeaker(this)
        modelReady.value = OfflineModelInstaller.isInstalled(this)
        setContent {
            val voiceOptions by speaker.voices.collectAsState()
            val voiceConfig by speaker.config.collectAsState()
            val activeWake by JarvisListeningService.isRunning.collectAsState()
            val wakeStatus by JarvisListeningService.status.collectAsState()
            val hasModel by modelReady.collectAsState()
            val downloadingModel by downloading.collectAsState()
            val progress by downloadProgress.collectAsState()
            LaunchedEffect(Unit) {
                model.speech.collect { speaker.speak(it) }
            }
            LaunchedEffect(Unit) {
                model.actions.collect { action ->
                    when (action) {
                        AssistantAction.OpenDeviceSettings -> startActivity(Intent(Settings.ACTION_SETTINGS))
                    }
                }
            }
            JarvisScreen(
                model = model,
                onListen = { requestListening() },
                onStopSpeech = { stopJarvisSpeech() },
                voiceOptions = voiceOptions,
                voiceConfig = voiceConfig,
                onSaveVoice = { voiceId, pitch, rate -> speaker.saveVoice(voiceId, pitch, rate) },
                onPreviewVoice = { voiceId, pitch, rate -> speaker.preview(voiceId, pitch, rate) },
                wakeActive = activeWake,
                wakeStatus = wakeStatus,
                hasWakeModel = hasModel,
                downloadingWakeModel = downloadingModel,
                modelStatus = progress.message,
                modelDownloadProgress = progress,
                onInstallWakeModel = { downloadWakeModel() },
                onStartWake = { requestWakeActivation() },
                onStopWake = { stopService(Intent(this@MainActivity, JarvisListeningService::class.java)) }
            )
        }
    }

    private fun downloadWakeModel() {
        if (downloading.value) return
        downloading.value = true
        activityScope.launch {
            try {
                OfflineModelInstaller.install(this@MainActivity) { downloadProgress.value = it }
                modelReady.value = OfflineModelInstaller.isInstalled(this@MainActivity)
                if (modelReady.value) model.addJarvisAnswer("Modelo local de voz instalado. Ya puedes activar el modo manos libres.")
            } catch (error: Exception) {
                val previous = downloadProgress.value
                val message = "Error al instalar: ${error.message ?: "desconocido"}. Pulsa Reintentar."
                downloadProgress.value = previous.copy(message = message, downloading = false)
                model.addJarvisAnswer(message)
            } finally {
                downloading.value = false
            }
        }
    }

    private fun requestWakeActivation() {
        if (!modelReady.value) {
            model.addJarvisAnswer("Primero descarga el modelo local en español.")
            return
        }
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        requestWakePermissions.launch(permissions.toTypedArray())
    }

    private fun launchWakeService() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, JarvisListeningService::class.java).setAction(JarvisListeningService.ACTION_START))
        } catch (error: Exception) {
            model.addJarvisAnswer("No se pudo activar la escucha: ${error.message}")
        }
    }

    private fun stopJarvisSpeech() {
        speaker.stop()
        if (JarvisListeningService.isRunning.value) {
            try {
                startService(Intent(this, JarvisListeningService::class.java)
                    .setAction(JarvisListeningService.ACTION_SILENCE))
            } catch (error: Exception) {
                model.addJarvisAnswer("No pude detener la voz de fondo: ${error.message ?: "error"}")
            }
        }
    }

    private fun requestListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            requestMic.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            model.addJarvisAnswer("No encuentro un servicio de reconocimiento de voz instalado. Puedes usar el teclado.")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { model.setListening(true) }
                    override fun onBeginningOfSpeech() = Unit
                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() { model.setListening(false) }
                    override fun onError(error: Int) {
                        model.setListening(false)
                        model.addJarvisAnswer("No pude reconocer el audio (código $error). Inténtalo otra vez.")
                    }
                    override fun onResults(results: Bundle?) {
                        model.setListening(false)
                        val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        if (phrase.isNullOrBlank()) model.addJarvisAnswer("No escuché palabras reconocibles.")
                        else model.submit(phrase)
                    }
                    override fun onPartialResults(partialResults: Bundle?) = Unit
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })
            }
        }
        speaker.stop()
        model.setListening(true)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try {
            recognizer?.startListening(intent)
        } catch (error: Exception) {
            model.setListening(false)
            model.addJarvisAnswer("No pude iniciar el micrófono: ${error.message}")
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        speaker.close()
        activityScope.cancel()
        super.onDestroy()
    }
}
