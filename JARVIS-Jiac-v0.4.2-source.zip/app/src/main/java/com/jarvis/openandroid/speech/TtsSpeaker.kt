package com.jarvis.openandroid.speech

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

/** The Android TTS engine does not expose a reliable male/female voice property. */
data class VoiceOption(val id: String, val label: String, val requiresNetwork: Boolean)
data class VoiceConfig(val voiceId: String = "", val pitch: Float = 0.85f, val rate: Float = 0.93f)

class TtsSpeaker(context: Context) : TextToSpeech.OnInitListener {
    private val prefs = context.applicationContext.getSharedPreferences("jarvis_voice_v02", Context.MODE_PRIVATE)
    private var ready = false
    private var pending: String? = null
    private var speakingId: String? = null
    private var nextId = 0L
    private val mainHandler = Handler(Looper.getMainLooper())

    private fun finishSpeaking(id: String?) {
        mainHandler.post {
            if (id != null && id == speakingId) {
                speakingId = null
                VoicePlaybackState.appVoiceActive.value = false
            }
        }
    }

    private fun speakTracked(message: String, prefix: String) {
        if (!ready) { pending = message; return }
        val id = "$prefix-${++nextId}"
        speakingId = id
        VoicePlaybackState.appVoiceActive.value = true
        val code = speaker.speak(SpokenResponse.concise(message), TextToSpeech.QUEUE_FLUSH, null, id)
        if (code != TextToSpeech.SUCCESS) finishSpeaking(id)
        // Un motor TTS que falle sin devolver un callback no debe silenciar Vosk indefinidamente.
        mainHandler.postDelayed({ finishSpeaking(id) }, 90_000L)
    }
    private val _config = MutableStateFlow(
        VoiceConfig(
            voiceId = prefs.getString("voice_id", "") ?: "",
            pitch = prefs.getFloat("pitch", 0.85f).coerceIn(0.65f, 1.15f),
            rate = prefs.getFloat("rate", 0.93f).coerceIn(0.75f, 1.15f)
        )
    )
    val config: StateFlow<VoiceConfig> = _config
    private val _voices = MutableStateFlow<List<VoiceOption>>(emptyList())
    val voices: StateFlow<List<VoiceOption>> = _voices

    private val speaker = TextToSpeech(context.applicationContext, this)

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val locales = listOf(Locale.forLanguageTag("es-MX"), Locale.forLanguageTag("es-PE"), Locale.forLanguageTag("es-ES"))
        val available = locales.firstOrNull { locale ->
            speaker.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE
        }
        if (available != null) speaker.setLanguage(available)
        ready = true
        speaker.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) = finishSpeaking(utteranceId)
            @Deprecated("Legacy callback")
            override fun onError(utteranceId: String?) = finishSpeaking(utteranceId)
            override fun onError(utteranceId: String?, errorCode: Int) = finishSpeaking(utteranceId)
            override fun onStop(utteranceId: String?, interrupted: Boolean) = finishSpeaking(utteranceId)
        })
        _voices.value = spanishVoices().map { voice ->
            val where = voice.locale.getDisplayName(Locale.forLanguageTag("es"))
            val local = if (voice.isNetworkConnectionRequired) "requiere conexión" else "sin conexión"
            VoiceOption(voice.name, "$where · ${voice.name} ($local)", voice.isNetworkConnectionRequired)
        }
        applyConfiguration(_config.value)
        pending?.let { speak(it) }
        pending = null
    }

    private fun spanishVoices(): List<Voice> =
        (speaker.voices ?: emptySet()).filter { it.locale.language == "es" }
            .sortedWith(
                compareBy<Voice> { it.isNetworkConnectionRequired }
                    .thenBy { if (it.locale.country == "MX") 0 else 1 }
                    .thenBy { it.name }
            )

    private fun applyConfiguration(configuration: VoiceConfig) {
        if (!ready) return
        val selected = spanishVoices().firstOrNull { it.name == configuration.voiceId }
        if (selected != null) speaker.setVoice(selected)
        speaker.setPitch(configuration.pitch)
        speaker.setSpeechRate(configuration.rate)
    }

    fun saveVoice(voiceId: String, pitch: Float, rate: Float) {
        val safe = VoiceConfig(voiceId, pitch.coerceIn(0.65f, 1.15f), rate.coerceIn(0.75f, 1.15f))
        _config.value = safe
        prefs.edit().putString("voice_id", safe.voiceId).putFloat("pitch", safe.pitch)
            .putFloat("rate", safe.rate).apply()
        applyConfiguration(safe)
    }

    /** Only previews the selected voice. It does not overwrite saved settings. */
    fun preview(voiceId: String, pitch: Float, rate: Float) {
        if (!ready) return
        applyConfiguration(VoiceConfig(voiceId, pitch, rate))
        speakTracked("Señor, sistemas en línea. Todos los protocolos están funcionando correctamente. A su servicio.", "jarvis-voice-preview")
    }

    fun speak(text: String) {
        if (!ready) { pending = text; return }
        applyConfiguration(_config.value)
        speakTracked(text, "jarvis-response")
    }

    fun stop() {
        if (ready) speaker.stop()
        speakingId = null
        VoicePlaybackState.appVoiceActive.value = false
    }
    fun close() {
        stop()
        speaker.shutdown()
    }
}
