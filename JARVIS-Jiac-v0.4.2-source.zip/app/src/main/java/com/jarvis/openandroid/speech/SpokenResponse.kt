package com.jarvis.openandroid.speech

/** Acota la voz, no el texto ni el historial de la respuesta. */
object SpokenResponse {
    fun concise(text: String, maxCharacters: Int = 500): String {
        require(maxCharacters >= 120)
        val normalized = text.replace(Regex("\\s+"), " ").trim()
        if (normalized.length <= maxCharacters) return normalized
        val candidate = normalized.take(maxCharacters)
        val sentenceBoundary = Regex("[.!?](?=\\s)").findAll(candidate).lastOrNull()?.range?.last?.plus(1) ?: 0
        val end = if (sentenceBoundary >= maxCharacters / 2) sentenceBoundary else
            candidate.lastIndexOf(' ').takeIf { it >= maxCharacters / 2 } ?: maxCharacters
        return normalized.take(end).trimEnd(' ', ',', ';', ':', '.') + ". Si quieres, puedo ampliar la respuesta."
    }
}
