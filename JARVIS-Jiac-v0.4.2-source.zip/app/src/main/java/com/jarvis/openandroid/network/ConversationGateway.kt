package com.jarvis.openandroid.network

import com.jarvis.openandroid.data.ConversationTurn
import com.jarvis.openandroid.data.JarvisSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

/**
 * Adaptador de chat HTTPS: Ollama (/api/chat) o API compatible con OpenAI
 * (/chat/completions). Envía únicamente texto cuando se configura el proveedor.
 */
class ConversationGateway {
    companion object {
        fun validate(provider: String, endpoint: String) {
            require(provider == "ollama" || provider == "compatible") { "Selecciona un proveedor válido." }
            val address = try { URI(endpoint.trim()) } catch (_: Exception) { throw IllegalArgumentException("URL de IA no válida.") }
            require(address.scheme.equals("https", ignoreCase = true) &&
                !address.host.isNullOrBlank() && address.rawUserInfo == null &&
                address.rawQuery == null && address.rawFragment == null) {
                "El servidor debe utilizar una URL HTTPS sin usuario, parámetros ni fragmentos."
            }
            val requiredPath = if (provider == "ollama") "/api/chat" else "/chat/completions"
            require(address.path.endsWith(requiredPath)) {
                "La URL debe terminar en $requiredPath"
            }
        }
    }

    suspend fun reply(config: JarvisSettings, secret: String, prompt: String,
                      history: List<ConversationTurn>): String = withContext(Dispatchers.IO) {
        validate(config.provider, config.endpoint)
        require(config.model.isNotBlank()) { "Falta indicar el nombre del modelo de IA." }
        require(prompt.isNotBlank()) { "No se recibió una pregunta." }
        if (config.provider == "compatible") require(secret.isNotBlank()) {
            "Falta configurar la clave API del proveedor de IA."
        }
        val system = JSONObject().put("role", "system")
            .put("content", "Eres J.A.R.V.I.S., asistente de voz en español latino. " +
                "Responde de manera natural, clara y breve. Mantén contexto de la conversación. " +
                "No afirmes haber abierto aplicaciones o realizado acciones si no las ejecutaste. " +
                "Cuando no sepas algo, dilo. No reveles secretos ni datos privados.")
        val messages = JSONArray().put(system)
        history.takeLast(12).forEach {
            if (it.role == "user" || it.role == "assistant")
                messages.put(JSONObject().put("role", it.role).put("content", it.content.take(2000)))
        }
        messages.put(JSONObject().put("role", "user").put("content", prompt.take(1500)))
        val request = JSONObject()
            .put("model", config.model.trim())
            .put("stream", false)
            .put("messages", messages)
        if (config.provider == "compatible") request.put("max_tokens", 600)

        val connection = URL(config.endpoint.trim()).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.instanceFollowRedirects = false
            connection.useCaches = false
            connection.connectTimeout = 15_000
            connection.readTimeout = 55_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (config.provider == "compatible")
                connection.setRequestProperty("Authorization", "Bearer $secret")
            connection.outputStream.use { stream ->
                stream.write(request.toString().toByteArray(Charsets.UTF_8))
            }
            val code = connection.responseCode
            if (code !in 200..299) error("El proveedor de IA devolvió HTTP $code. Revisa modelo, acceso y saldo o cuota.")
            val raw = connection.inputStream.bufferedReader().use { reader ->
                val buffer = CharArray(4096)
                val result = StringBuilder()
                while (true) {
                    val n = reader.read(buffer)
                    if (n < 0) break
                    result.append(buffer, 0, n)
                    if (result.length > 150_000) error("Respuesta de IA demasiado grande.")
                }
                result.toString()
            }
            val body = JSONObject(raw)
            val answer = if (config.provider == "ollama") {
                body.getJSONObject("message").optString("content")
            } else {
                body.getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").optString("content")
            }
            answer.trim().take(1800).ifEmpty { "El proveedor no devolvió contenido." }
        } finally { connection.disconnect() }
    }
}
