package com.jarvis.openandroid.domain

import com.jarvis.openandroid.speech.SpokenResponse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpokenResponseTest {
    @Test fun shortReplyIsUnchanged() {
        assertEquals("A sus órdenes.", SpokenResponse.concise("A sus órdenes."))
    }

    @Test fun longReplyIsCondensedWithoutCuttingWords() {
        val verbose = "Una explicación clara que ocupa varias palabras. ".repeat(20)
        val result = SpokenResponse.concise(verbose, 160)
        assertTrue(result.length < verbose.length)
        assertTrue(result.endsWith("Si quieres, puedo ampliar la respuesta."))
    }
}
