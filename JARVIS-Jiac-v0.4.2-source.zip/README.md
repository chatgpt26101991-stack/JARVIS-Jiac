# J.A.R.V.I.S. Android v0.4.2 — hora local y enrutamiento de voz

Aplicación Android **de código abierto (Apache-2.0)**.

## Corrección puntual v0.4.2: hora y fecha fiables

- Detecta variantes habituales de la pregunta horaria (por ejemplo «¿Qué hora es?», «Jarvis, dime la hora», «¿Me puedes decir qué hora es?») y consulta el reloj del propio Android **sin enviar la pregunta a Groq**.
- La misma regla se aplica tanto a la pantalla principal como al modo manos libres y con la pantalla bloqueada, sin solicitar permiso adicional.
- Evita tratar como hora local preguntas diferentes («¿A qué hora empieza la película?», «¿Qué hora es en Tokio?»).
- Incluye nuevas pruebas unitarias, con reloj fijo para validar hora y zona horaria.
- Mantiene el proveedor Groq, la clave del dispositivo, la voz masculina y el detector Vosk sin modificaciones.
- Esta entrega **no certifica** que la escucha con pantalla bloqueada sea estable: es un aspecto que sigue en evaluación.

## Mejoras de estabilidad v0.4.1

- Se suspende el detector Vosk durante respuestas de voz tanto de la pantalla principal como del servicio manos libres; se espera **1,2 segundos** tras terminar el TTS antes de reanudar la captura para reducir la realimentación acústica.
- El usuario puede **Detener voz** desde la app y **Silenciar voz** desde la notificación de escucha; el servicio puede seguir activado.
- Las respuestas por voz se acortan a aproximadamente 500 caracteres, con invitación a ampliar la explicación; el texto íntegro de IA permanece visible en la pantalla y en su historial local.
- Las respuestas TTS usan identificadores únicos para no reactivar el micrófono por una finalización antigua. Se registran los errores de Vosk sin imprimir conversaciones ni secretos.
- Se agregaron pruebas unitarias para el tiempo de silencio tras hablar y el acortamiento de respuestas.
- Corrección preventiva: hace falta **validar el comportamiento en un Android real**; esta entrega todavía no certifica la estabilidad con pantalla apagada.
 Evolución directa del proyecto 0.3.1: conserva la voz masculina seleccionada, la interfaz futurista y el detector Vosk; añade conversación con un modelo de IA opcional y contexto breve.

## ¿Qué puede hacer?

- Responder preguntas abiertas (explicaciones, recetas, ideas, programación, conversación) **cuando configures un modelo externo**. No hay IA generativa integrada sin configurar el proveedor.
- Escuchar órdenes tras la palabra **«Jarvis»**, tanto con la app abierta como con el servicio activado en segundo plano. La disponibilidad con la pantalla apagada sigue dependiendo de Android/fabricante.
- Hablar con el motor TTS y la **voz masculina** previamente seleccionada. No altera esos ajustes.
- Conservar localmente hasta seis intercambios anteriores como contexto y permitir **Borrar conversación local**.
- Mantener las funciones sin nube: hora, fecha, saludo, abrir ajustes (desde la pantalla activa), memoria local y detección Vosk.
- Conectarse por HTTPS a **Ollama** (`/api/chat`) o una **API compatible con OpenAI** (`/chat/completions`) como Groq u OpenRouter.
- Guardar la API key **cifrada en Android Keystore** y eliminarla desde Ajustes. No incluye credenciales en el APK ni en GitHub.
- Por defecto, **no consulta IA externa con el celular bloqueado**. La opción de permitirlo requiere activación explícita y puede exponer respuestas audibles o texto de preguntas al proveedor.

## Configura una IA conversacional usando solo el celular

1. Instala el APK 0.4 compilado desde **tu repositorio** y abre J.A.R.V.I.S.
2. Toca el engranaje ⚙️ en la parte superior y selecciona **API compatible (Groq, OpenRouter…)**.
3. Puedes registrarte en [GroqCloud](https://console.groq.com/keys) y crear tu **propia clave API**. Nunca la compartas en un chat ni la subas a GitHub.
4. Revisa los costos, cuotas y condiciones del proveedor antes de usarlo. Tener código abierto no hace gratuitas las llamadas a servicios de terceros.
5. Comprueba estos valores:
   - URL: `https://api.groq.com/openai/v1/chat/completions`
   - Modelo: `openai/gpt-oss-20b` (modelo que el proveedor documenta actualmente, sujeto a cambios)
   - Clave API: la creada por ti, introducida **solamente dentro de la app**.
6. Deja desactivado «Permitir respuestas de IA con pantalla bloqueada» inicialmente. Pulsa **Guardar**.
7. Prueba por texto: «Explícame cómo se produce un eclipse»; luego «Resúmelo en dos frases» para comprobar el contexto.
8. Para la prueba de voz di «Jarvis, explícale a alguien de 10 años qué es la inteligencia artificial». La consulta se enviará **como texto reconocido**, no como audio, al proveedor elegido.
9. Si deseas permitir respuestas cuando esté bloqueado, actívalo expresamente y comprende sus riesgos de privacidad. Comienza probando con la pantalla encendida.

Alternativa: selecciona **Servidor Ollama privado** con un endpoint HTTPS de `/api/chat` que tú controles. No publiques un Ollama sin autenticación en Internet.

## Seguridad y límites

- No promete entender literalmente todas las frases: la exactitud depende de Vosk, de la pronunciación, la calidad del micrófono y el modelo conectado.
- No realiza acciones arbitrarias como enviar WhatsApps, compras, movimientos bancarios o saltar bloqueos; esas acciones necesitan integraciones y confirmaciones adicionales.
- Los mensajes que no sean comandos locales se envían al proveedor elegido cuando la IA esté activada. El texto del diálogo se conserva localmente en las preferencias privadas de la app y se comparte como contexto con ese proveedor (máximo seis pares anteriores). Se puede borrar desde la interfaz.
- La versión 0.3.1 tenía reconocimiento **intermitente con pantalla bloqueada**. Esta entrega añade inteligencia conversacional, pero **no certifica la corrección de esa incidencia**; mantiene pendiente el diagnóstico de batería y micrófono.
- El motor de voz puede requerir conexión dependiendo del servicio TTS elegido. Vosk continúa funcionando localmente.
- La clave API está cifrada usando Android Keystore, pero una app maliciosa en un teléfono comprometido podría leer mensajes en pantalla. Evita poner secretos en preguntas.
- Si el APK tiene una firma de depuración distinta, Android puede rechazar la instalación sobre la versión existente; desinstalar puede borrar el modelo Vosk descargado, el historial y la selección local de voz.

## Compilación desde GitHub Actions (sin PC)

1. Sube `JARVIS-Jiac-v0.4.2-source.zip` al repositorio `JARVIS-Jiac` con **Add file → Upload files**.
2. En el workflow **raíz del repositorio** `.github/workflows/build-apk.yml`, cambia **solo** el ZIP de la línea `unzip -q ...` por `JARVIS-Jiac-v0.4.2-source.zip`. No cambies los ajustes de SDK 36 que ya funcionaron en la 0.3.1.
3. Opcional: cambia `name:` dentro de `uses: actions/upload-artifact@v4` por `JARVIS-Jiac-v0.4.2-debug-APK` para distinguir los entregables.
4. Pulsa **Commit changes**. Revisa **Actions** y comprueba `success`, pruebas y APK generado antes de instalar.
5. Descarga el artefacto ZIP en Actions y extrae `app-debug.apk`. Nunca instales un archivo que no provenga de tu compilación.

Este ZIP incluye el código del proyecto y sus pruebas, pero **NO es un APK**. La compilación Android y las pruebas de uso deben verificarse en GitHub Actions y el teléfono.

## Archivos principales

- `data/JarvisPreferences.kt`: preferencias del proveedor, privacidad en bloqueo.
- `data/SecureApiKeyStore.kt`: cifrado de credenciales con Keystore.
- `data/ConversationMemory.kt`: contexto conversacional corto borrable.
- `network/ConversationGateway.kt`: llamadas a Ollama o API compatible a través de HTTPS.
- `wake/JarvisListeningService.kt`: conexión del detector Vosk a las respuestas por IA y TTS.
- `domain/LocalRouting.kt`: evita que preguntas generales se confundan con órdenes locales.
- `ui/JarvisViewModel.kt`, `ui/JarvisScreen.kt`: interfaz de configuración y chat.

Licencia del proyecto: Apache-2.0. Los motores y modelos de terceros conservan sus propias licencias.
