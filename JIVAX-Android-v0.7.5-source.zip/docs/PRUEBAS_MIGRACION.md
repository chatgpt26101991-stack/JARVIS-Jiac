# Plan de pruebas JIVAX 0.7.4

| N.º | Caso de prueba | Resultado esperado |
|---:|---|---|
| 1 | Actualizar APK 0.7.3 a 0.7.4 sin desinstalar | Android actualiza la app sin pérdida de datos ni error de firma |
| 2 | Abrir aplicación | Nombre y pantalla principal muestran **JIVAX** e icono propio |
| 3 | Revisar historial y memoria personal | Aparecen los registros que ya estaban en 0.7.3 |
| 4 | Revisar modelo Groq configurado | Persisten la clave cifrada, proveedor y ajustes previos |
| 5 | Activar escucha con modelo Vosk | El estado indica escucha de «JIVAX» |
| 6 | Decir «JIVAX, ¿qué hora es?» | Responde a la hora local por voz y guarda historial |
| 7 | Decir «JIVAX» y esperar respuesta | Indica que espera una orden; permite seguimiento si está configurado |
| 8 | Decir «Jarvis, ¿qué hora es?» | No se activa la nueva palabra por accidente, salvo sesión ya abierta |
| 9 | Voz de JIVAX mientras el micrófono está activo | Se pausa el reconocimiento para evitar eco y luego se reanuda |
| 10 | Tomar una foto, describir y preguntar por ella | Mantiene flujo de visión, memoria textual y salida por voz |
| 11 | Reiniciar app | Conserva historial, ajustes y recuerdos |
| 12 | Bloquear pantalla con escucha iniciada | Permanece el servicio permitido; respeta privacidad y reglas de Android |
| 13 | Orden «JIVAX, abre ajustes» | Se ejecuta exclusivamente la acción que admite la versión actual |

**Importante:** se sugiere probar la pronunciación YÍ-VAKS y las variantes reconocidas en Vosk, observando las transcripciones. El reconocedor puede confundir un nombre poco habitual; las variantes no garantizan reconocimiento.

## Paso 84 — Diagnóstico manos libres (versión 0.7.5)
1. Iniciar la aplicación y confirmar modelo Vosk descargado.
2. Pulsar «Activar JIVAX en segundo plano» y comprobar «Escuchando JIVAX».
3. Pulsar «Probar detector manos libres (20 s)».
4. Pronunciar «YÍ-VAKS» y comprobar que aparece una transcripción temporal de Vosk.
5. Si Vosk escribe `yivaks`, `jivaks` o una variante admitida, debe responder «A sus órdenes».
6. Si escribe otra frase, anotar **solo** la transcripción para ajustar el detector.
7. Comprobar que «Hablar con JIVAX» sigue funcionando después de la prueba.
8. Repetir con la pantalla bloqueada (sin garantizar comportamientos que Android restringe).
