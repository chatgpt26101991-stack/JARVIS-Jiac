package com.jivax.openandroid.wake

import java.text.Normalizer
import java.util.Locale

/** Pure Kotlin, covered by JVM tests. Vosk returns words as JSON; parse JSON outside this class. */
object WakeWordMatcher {
    // Vosk puede escribir la X final como ks, cs, x o s al escuchar «YÍ-VAKS».
    // No admitir palabras comunes como «vivas» o «ibas» para evitar activaciones accidentales.
    // Estas alternativas se aplican únicamente a una palabra completa.
    const val WORDS_PATTERN = "jivax|yivax|jibax|yibax|jivacs|yivacs|jibacs|yibacs|jivaks|yivaks|jibaks|yibaks|jivas|yivas|jibas|yibas|(?:ji|yi)[\\s-]+(?:vaks|vacs|vax)"
    private val pattern = Regex("\\b(?:$WORDS_PATTERN)\\b")

    fun commandAfterWakeWord(phrase: String): String? {
        val normalized = Normalizer.normalize(phrase.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        val match = pattern.find(normalized) ?: return null
        // Indexes generally align for 'jivax'; extracting from normalized text is intentional.
        return normalized.substring(match.range.last + 1).trim(' ', ',', '.', ':', '¿', '?', '¡', '!')
    }
}
