$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$dest = Join-Path $PSScriptRoot 'gradle\wrapper\gradle-wrapper.jar'
$base = 'https://services.gradle.org/distributions/gradle-9.5.0-wrapper.jar'
Write-Host 'Obteniendo el Gradle Wrapper oficial 9.5.0...'
Invoke-WebRequest -Uri $base -OutFile $dest
$expected = (Invoke-WebRequest -Uri ($base + '.sha256')).Content.Trim().Split(' ')[0].ToLowerInvariant()
$actual = (Get-FileHash -Path $dest -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $expected) {
    Remove-Item $dest -Force
    throw 'Error: la suma SHA256 del wrapper no coincide.'
}
Write-Host 'Gradle Wrapper descargado y verificado correctamente.' -ForegroundColor Green
Write-Host 'Ahora ejecuta: .\gradlew.bat :app:assembleDebug'
