@echo off
setlocal
set "APP_HOME=%~dp0"
if not exist "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" (
  echo Falta gradle-wrapper.jar. Ejecuta antes: powershell -ExecutionPolicy Bypass -File .\setup-wrapper.ps1
  exit /b 1
)
java -cp "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
