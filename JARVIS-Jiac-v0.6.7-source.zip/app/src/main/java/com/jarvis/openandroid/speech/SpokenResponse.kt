package com.jarvis.openandroid.speech

/**
 * Prepara texto para TTS sin alterar el mensaje original, la UI ni el historial.
 * Solo elimina marcas comunes de Markdown cuando están bien delimitadas;
 * conserva operadores matemáticos y símbolos que sí tienen significado.
 */
object SpokenResponse {
    private val markdownLink = Regex("""\[([^\]\n]+)]\((?:https?://|mailto:)[^\s)]+\)""")
    private val markdownImage = Regex("""!\[([^\]\n]*)]\((?:https?://|data:)[^\s)]+\)""")
    private val boldItalicStars = Regex("""\*\*\*([^*\s](?:[^*\n]*?[^*\s])?)\*\*\*""")
    private val boldStars = Regex("""\*\*([^*\s](?:[^*\n]*?[^*\s])?)\*\*""")
    private val boldUnderscores = Regex("""(?<![\p{L}\p{N}])__([^_\s](?:[^_\n]*?[^_\s])?)__(?![\p{L}\p{N}])""")
    private val italicStars = Regex("""(?<![\p{L}\p{N}*])\*([^*\s](?:[^*\n]*?[^*\s])?)\*(?![\p{L}\p{N}*])""")
    private val italicUnderscores = Regex("""(?<![\p{L}\p{N}_])_([^_\s](?:[^_\n]*?[^_\s])?)_(?![\p{L}\p{N}_])""")
    private val inlineCode = Regex("""(?<!`)`([^`\n]+)`(?!`)""")
    private val deleted = Regex("""~~([^~\n]+)~~""")
    private val heading = Regex("""(?m)^\s{0,3}#{1,6}\s*(?=\p{L}|\d)""")
    private val quote = Regex("""(?m)^\s{0,3}>\s?""")
    private val unorderedBullet = Regex("""(?m)^\s{0,3}[-*+]\s+""")
    private val horizontalRule = Regex("""(?m)^\s{0,3}(?:-{3,}|\*{3,}|_{3,})\s*$""")
    private val fencedCodeMarker = Regex("""(?m)^\s{0,3}`{3,}[^\n]*$""")

    /**
     * Convierte tablas Markdown en frases que nombran explícitamente cada columna.
     * Una tabla «Aspecto | Iron Man | Batman» pasa a hablar como:
     * «Tecnología. Iron Man: armadura. Batman: dispositivos.»
     * NO modifica el texto original, el historial ni el portapapeles.
     */
    private fun verbalizeTables(source: String): String {
        val lines = source.split('\n')
        val result = mutableListOf<String>()
        var index = 0
        while (index < lines.size) {
            val headers = parseCells(lines[index])
            val sep = if (index + 1 < lines.size) parseCells(lines[index + 1]) else null
            if (headers != null && sep != null &&
                headers.size == sep.size && sep.all { it.matches(Regex("""^:?-{3,}:?$""")) }
            ) {
                index += 2
                var rows = 0
                while (index < lines.size) {
                    val cells = parseCells(lines[index])
                    if (cells == null || cells.size != headers.size) break
                    result.add(verbalizeRow(headers, cells))
                    index++
                    rows++
                }
                // Las cabeceras sin filas se pronuncian normalmente (caso excepcional).
                if (rows == 0) result.add(headers.joinToString(". "))
            } else {
                result.add(lines[index])
                index++
            }
        }
        return result.joinToString("\n")
    }

    private fun parseCells(line: String): List<String>? {
        val trimmed = line.trim()
        if (!trimmed.contains('|') || trimmed.startsWith("```")) return null
        val cells = trimmed.removePrefix("|").removeSuffix("|").split('|').map { it.trim() }
        return cells.takeIf { it.size >= 2 }
    }

    private fun verbalizeRow(headers: List<String>, cells: List<String>): String {
        // «Aspecto | Iron Man | Batman»: el primer dato es el aspecto a comparar.
        val categoryHeader = headers[0].trim().lowercase()
        val hasCategory = headers.size >= 3 && categoryHeader in setOf(
            "aspecto", "característica", "caracteristicas", "criterio", "tema", "categoría", "categoria", "atributo", "diferencia", "punto"
        )
        val parts = mutableListOf<String>()
        if (hasCategory && cells[0].isNotBlank()) parts.add(asSentence(cells[0]))
        val first = if (hasCategory) 1 else 0
        for (i in first until headers.size) {
            val label = headers[i].trim().trimEnd(':', '.')
            val value = cells[i].trim()
            if (value.isNotBlank()) {
                parts.add(asSentence(if (label.isBlank()) value else "$label: $value"))
            }
        }
        return parts.joinToString(" ")
    }

    private fun asSentence(text: String): String {
        val clean = text.trim()
        return if (clean.isBlank() || clean.last() in ".!?:;") clean else "$clean."
    }

    /** Elimina *solo* marcas de formato reconocibles antes de convertir a voz. */
    fun plainForSpeech(text: String): String {
        if (text.isBlank()) return ""
        val normalized = text.replace("\r\n", "\n").replace('\r', '\n')
        return verbalizeTables(normalized)
            .replace(horizontalRule, " ")
            .replace(fencedCodeMarker, " ")
            .replace(heading, "")
            .replace(quote, "")
            .replace(unorderedBullet, "")
            .replace(markdownImage, "$1")
            .replace(markdownLink, "$1")
            .replace(inlineCode, "$1")
            .replace(boldItalicStars, "$1")
            .replace(boldStars, "$1")
            .replace(boldUnderscores, "$1")
            .replace(italicStars, "$1")
            .replace(italicUnderscores, "$1")
            .replace(deleted, "$1")
            // Marcadores de encabezado aislados o títulos mal formados: «#Iron Man».
            // C# y símbolos matemáticos no se modifican.
            .replace(Regex("""(?<![\p{L}\p{N}])#{1,6}(?=\s)"""), " ")
            .replace(Regex("""\s+\|\s+"""), "; ")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    /**
     * v0.6.6: segmenta la respuesta COMPLETA para motores TTS de Android.
     * Ninguna parte se omite y cada bloque cabe bajo el máximo de entrada de Android.
     * El texto del historial y del portapapeles no se modifica.
     */
    fun chunks(text: String, maxCharacters: Int = 650): List<String> {
        require(maxCharacters in 120..3500)
        val normalized = plainForSpeech(text)
        if (normalized.isEmpty()) return emptyList()
        val result = mutableListOf<String>()
        var start = 0
        while (start < normalized.length) {
            var end = (start + maxCharacters).coerceAtMost(normalized.length)
            if (end < normalized.length) {
                val available = normalized.substring(start, end)
                val sentenceEnd = Regex("""[.!?](?=\s)""").findAll(available)
                    .lastOrNull()?.range?.last?.plus(1)
                val space = available.lastIndexOf(' ')
                end = when {
                    sentenceEnd != null && sentenceEnd >= maxCharacters / 3 -> start + sentenceEnd
                    space >= maxCharacters / 3 -> start + space
                    space >= 0 -> start + space
                    else -> end // Solo divide una palabra si supera por sí sola el límite.
                }
            }
            result.add(normalized.substring(start, end).trim())
            start = end
            while (start < normalized.length && normalized[start] == ' ') start++
        }
        return result.filter { it.isNotBlank() }
    }

    /** Compatibilidad con las pruebas antiguas: NO usar en producción para respuestas largas. */
    fun concise(text: String, maxCharacters: Int = 500): String {
        require(maxCharacters >= 120)
        val normalized = plainForSpeech(text)
        if (normalized.length <= maxCharacters) return normalized
        val candidate = normalized.take(maxCharacters)
        val sentenceBoundary = Regex("[.!?](?=\\s)").findAll(candidate).lastOrNull()?.range?.last?.plus(1) ?: 0
        val end = if (sentenceBoundary >= maxCharacters / 2) sentenceBoundary else
            candidate.lastIndexOf(' ').takeIf { it >= maxCharacters / 2 } ?: maxCharacters
        return normalized.take(end).trimEnd(' ', ',', ';', ':', '.') + ". Si quieres, puedo ampliar la respuesta."
    }
}
