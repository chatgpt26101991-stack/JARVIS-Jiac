package com.jarvis.openandroid.domain

import java.text.Normalizer
import java.util.Locale

/**
 * Decide qué consultas deben resolverse en el dispositivo, incluso con Groq activado.
 * La hora y la fecha del teléfono son hechos locales, no respuestas generativas.
 */
object LocalRouting {
    private val whitespace = Regex("\\s+")
    private val punctuation = Regex("[^a-z0-9 ]")
    private val modifiers = listOf(
        "por favor ", "me puedes decir ", "me podrias decir ", "podrias decirme ",
        "puedes decirme ", "me dices ", "me das ", "dime ", "sabes ",
        "quisiera saber ", "necesito saber "
    )

    private fun normalize(phrase: String): String {
        var text = Normalizer.normalize(phrase.lowercase(Locale.forLanguageTag("es-PE")), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(punctuation, " ")
            .replace(whitespace, " ").trim()
        // Vosk puede incluir la palabra de activación dentro de la orden.
        text = text.replace(Regex("^(?:oye )?(?:jarvis|yarvis|llarvis) "), "")
        return text.trim()
    }

    private fun politeCore(phrase: String): String {
        var text = normalize(phrase)
        repeat(3) {
            val prefix = modifiers.firstOrNull { text.startsWith(it) }
            if (prefix != null) text = text.removePrefix(prefix).trim()
        }
        if (text.endsWith(" por favor")) text = text.removeSuffix(" por favor").trim()
        return text
    }

    /** Solo pregunta por la hora ACTUAL de este teléfono; nunca horarios de eventos ni otras ciudades. */
    fun isTimeQuery(phrase: String): Boolean = politeCore(phrase) in setOf(
        "hora", "la hora", "hora actual", "la hora actual", "que hora es", "que hora es ahora",
        "que hora es en este momento", "que hora tenemos", "que horas son", "que horas son ahora",
        "cual es la hora", "cual es la hora actual"
    )

    fun isDateQuery(phrase: String): Boolean = politeCore(phrase) in setOf(
        "fecha", "la fecha", "fecha actual", "la fecha actual", "fecha de hoy", "la fecha de hoy", "que fecha es", "que fecha es hoy",
        "que dia es", "que dia es hoy", "cual es la fecha", "cual es la fecha de hoy"
    )

    fun isLocal(phrase: String): Boolean {
        if (isTimeQuery(phrase) || isDateQuery(phrase)) return true
        val text = normalize(phrase)
        return text.startsWith("recuerda que ") || text in setOf(
            "hola", "buenas", "abre ajustes", "abrir ajustes", "abre configuracion",
            "que recuerdas", "borra el recuerdo", "olvida lo que recordaste"
        )
    }

    /** Los datos horarios públicos pueden decirse aunque el teléfono esté bloqueado. */
    fun isPublicWhenLocked(phrase: String): Boolean =
        isTimeQuery(phrase) || isDateQuery(phrase) || normalize(phrase) in setOf("hola", "buenas")
}
