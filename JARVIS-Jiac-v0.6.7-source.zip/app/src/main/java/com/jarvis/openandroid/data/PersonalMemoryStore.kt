package com.jarvis.openandroid.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/** Recuerdos explícitos, locales y separados del historial visible y del contexto de Groq. */
class PersonalMemoryStore(context: Context) {
    companion object {
        const val STORAGE_NAME = "jarvis_personal_memories_v061"
        const val KEY_ITEMS = "items"
        private const val KEY_LEGACY = "legacy_migrated"
        private val lock = Any()
    }

    private val prefs = context.applicationContext.getSharedPreferences(STORAGE_NAME, Context.MODE_PRIVATE)

    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.registerOnSharedPreferenceChangeListener(listener)

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.unregisterOnSharedPreferenceChangeListener(listener)

    fun read(): List<String> = synchronized(lock) { load() }

    fun add(text: String): Boolean = synchronized(lock) {
        val before = load()
        val after = PersonalMemoryPolicy.add(before, text)
        if (after == before) return@synchronized false
        prefs.edit().putString(KEY_ITEMS, JSONArray(after).toString()).apply()
        true
    }

    fun remove(index: Int): Boolean = synchronized(lock) {
        val before = load()
        if (index !in before.indices) return@synchronized false
        prefs.edit().putString(KEY_ITEMS, JSONArray(before.filterIndexed { i, _ -> i != index }).toString()).apply()
        true
    }

    fun clear() = synchronized(lock) { prefs.edit().putString(KEY_ITEMS, "[]").putBoolean(KEY_LEGACY, true).apply() }

    /** Migración única del antiguo recuerdo individual sin perder información. */
    fun migrateLegacy(legacy: String) = synchronized(lock) {
        if (!prefs.getBoolean(KEY_LEGACY, false)) {
            val merged = PersonalMemoryPolicy.add(load(), legacy)
            prefs.edit().putString(KEY_ITEMS, JSONArray(merged).toString())
                .putBoolean(KEY_LEGACY, true).apply()
        }
    }

    fun respond(command: PersonalMemoryCommand): String = when (command) {
        is PersonalMemoryCommand.Save -> when {
            command.value.isBlank() -> "Dime qué deseas que recuerde. Por ejemplo, recuerda que prefiero respuestas breves."
            add(command.value) -> "Entendido. Guardé un nuevo recuerdo en este teléfono."
            else -> "Ya tenía guardado ese recuerdo."
        }
        PersonalMemoryCommand.Show -> {
            val list = read()
            if (list.isEmpty()) "Todavía no tengo recuerdos personales guardados."
            else "Estos son tus recuerdos: " + list.mapIndexed { index, value -> "${index + 1}: $value" }.joinToString(". ")
        }
        PersonalMemoryCommand.RequestClear ->
            "Para borrar recuerdos, abre Mis recuerdos en la aplicación y confirma la eliminación."
    }

    private fun load(): List<String> = try {
        val parsed = JSONArray(prefs.getString(KEY_ITEMS, "[]") ?: "[]")
        (0 until parsed.length()).mapNotNull { parsed.optString(it, "").trim().takeIf { value -> value.isNotBlank() } }
            .takeLast(PersonalMemoryPolicy.MAX_ITEMS).map(PersonalMemoryPolicy::clean)
    } catch (_: Exception) { emptyList() }
}
