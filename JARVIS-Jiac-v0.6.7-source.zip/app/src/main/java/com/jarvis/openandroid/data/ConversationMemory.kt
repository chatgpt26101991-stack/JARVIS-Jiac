package com.jarvis.openandroid.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Historial breve y local. No sincroniza datos ni registra secretos. */
data class ConversationTurn(val role: String, val content: String)

class ConversationMemory(context: Context) {
    private val storage = context.applicationContext.getSharedPreferences("jarvis_conversation_v04", Context.MODE_PRIVATE)
    private val key = "messages"

    @Synchronized
    fun read(): List<ConversationTurn> {
        val raw = storage.getString(key, "[]").orEmpty()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { index ->
                val objectValue = array.optJSONObject(index) ?: return@mapNotNull null
                val role = objectValue.optString("role")
                val content = objectValue.optString("content")
                if (role !in listOf("user", "assistant") || content.isBlank()) null
                else ConversationTurn(role, content.take(2000))
            }.takeLast(12)
        } catch (_: Exception) { emptyList() }
    }

    @Synchronized
    fun addPair(question: String, answer: String) {
        val turns = (read() + ConversationTurn("user", question.take(1500)) +
            ConversationTurn("assistant", answer.take(2000))).takeLast(12)
        val array = JSONArray()
        turns.forEach { entry ->
            array.put(JSONObject().put("role", entry.role).put("content", entry.content))
        }
        storage.edit().putString(key, array.toString()).apply()
    }

    @Synchronized
    fun clear() { storage.edit().remove(key).apply() }
}
