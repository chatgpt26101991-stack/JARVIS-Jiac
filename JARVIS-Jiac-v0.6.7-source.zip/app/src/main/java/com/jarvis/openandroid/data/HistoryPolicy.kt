package com.jarvis.openandroid.data

/** Historial visible local. Separado de la memoria breve enviada a la IA. */
data class HistoryEntry(
    val role: String,
    val content: String,
    val timestamp: Long,
    val origin: String
)

/** Restricciones puras para poder comprobarlas con pruebas unitarias. */
object HistoryPolicy {
    const val MAX_PAIRS = 100
    const val MAX_QUESTION_LENGTH = 1500
    const val MAX_ANSWER_LENGTH = 20000

    fun append(previous: List<HistoryEntry>, question: String, answer: String, origin: String,
               timestamp: Long): List<HistoryEntry> {
        if (question.isBlank() || answer.isBlank()) return previous
        val safeOrigin = if (origin in setOf("voz", "manos libres", "escrito", "anterior")) origin else "escrito"
        val pair = listOf(
            HistoryEntry("user", question.trim().take(MAX_QUESTION_LENGTH), timestamp, safeOrigin),
            HistoryEntry("assistant", answer.trim().take(MAX_ANSWER_LENGTH), timestamp, safeOrigin)
        )
        return (previous + pair).takeLast(MAX_PAIRS * 2)
    }
}

