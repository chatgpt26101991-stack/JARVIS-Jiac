package com.jarvis.openandroid.wake

import java.text.Normalizer
import java.util.Locale

/** Pure Kotlin, covered by JVM tests. Vosk returns words as JSON; parse JSON outside this class. */
object WakeWordMatcher {
    private val pattern = Regex("\\b(jarvis|yarvis|llarvis)\\b")

    fun commandAfterWakeWord(phrase: String): String? {
        val normalized = Normalizer.normalize(phrase.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        val match = pattern.find(normalized) ?: return null
        // Indexes generally align for 'jarvis'; extracting from normalized text is intentional.
        return normalized.substring(match.range.last + 1).trim(' ', ',', '.', ':', '¿', '?', '¡', '!')
    }
}
