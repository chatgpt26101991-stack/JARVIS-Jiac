package com.jarvis.openandroid.domain

import java.time.Clock
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

sealed interface AssistantAction {
    data object OpenDeviceSettings : AssistantAction
}

data class AssistantResponse(
    val text: String,
    val newMemory: String? = null,
    val action: AssistantAction? = null
)

/** Comandos deterministas: no constituye un modelo de IA generativa local. */
class LocalCommandEngine(private val clock: Clock = Clock.systemDefaultZone()) {
    private val peruvianSpanish = Locale("es", "PE")

    fun answer(phrase: String, currentMemory: String): AssistantResponse? {
        val original = phrase.trim()
        val input = original.lowercase(peruvianSpanish)

        if (input.startsWith("recuerda que ")) {
            val remembered = original.substring("recuerda que ".length).trim()
            return if (remembered.isBlank()) {
                AssistantResponse("Dime qué información debo recordar.")
            } else {
                AssistantResponse("Entendido. Lo guardaré en este dispositivo.", newMemory = remembered)
            }
        }
        if (input == "recuerda que") return AssistantResponse("Dime qué información debo recordar.")

        if (input.contains("qué recuerdas") || input.contains("que recuerdas") ||
            input.contains("qué has recordado") || input.contains("que has recordado")) {
            return AssistantResponse(
                if (currentMemory.isBlank()) "Todavía no tengo recuerdos guardados."
                else "Recuerdo esto: $currentMemory"
            )
        }
        if (input.contains("borra el recuerdo") || input.contains("olvida lo que recordaste")) {
            return AssistantResponse("He eliminado el recuerdo guardado.", newMemory = "")
        }
        if (input.contains("abre ajustes") || input.contains("abrir ajustes") ||
            input.contains("abre configuración") || input.contains("abre configuracion")) {
            return AssistantResponse("Abriendo los ajustes del dispositivo.", action = AssistantAction.OpenDeviceSettings)
        }
        if (LocalRouting.isTimeQuery(original)) {
            val time = LocalTime.now(clock).format(DateTimeFormatter.ofPattern("HH:mm", peruvianSpanish))
            return AssistantResponse("Son las $time.")
        }
        if (LocalRouting.isDateQuery(original)) {
            val date = LocalDate.now(clock).format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM 'de' yyyy", peruvianSpanish))
            return AssistantResponse("Hoy es $date.")
        }
        if (input == "jarvis" || input.contains("hola jarvis") || input == "hola" || input == "buenas") {
            return AssistantResponse("Sistemas listos. ¿En qué puedo ayudarte?")
        }
        if (input.contains("qué puedes hacer") || input.contains("que puedes hacer")) {
            return AssistantResponse("Puedo responder por voz, consultar la fecha y hora, guardar un recuerdo y abrir los ajustes. También puedo consultar un modelo externo si lo configuras.")
        }
        return null
    }
}
