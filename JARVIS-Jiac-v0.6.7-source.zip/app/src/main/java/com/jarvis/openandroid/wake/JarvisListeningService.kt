package com.jarvis.openandroid.wake

import android.Manifest
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import com.jarvis.openandroid.MainActivity
import com.jarvis.openandroid.domain.LocalCommandEngine
import com.jarvis.openandroid.domain.LocalRouting
import com.jarvis.openandroid.data.JarvisPreferences
import com.jarvis.openandroid.data.ConversationMemory
import com.jarvis.openandroid.data.ConversationHistory
import com.jarvis.openandroid.data.PersonalMemoryStore
import com.jarvis.openandroid.data.PersonalMemoryCommands
import com.jarvis.openandroid.data.SecureApiKeyStore
import com.jarvis.openandroid.network.ConversationGateway
import com.jarvis.openandroid.speech.SpokenResponse
import com.jarvis.openandroid.speech.VoicePlaybackState
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.util.Locale

/**
 * Servicio EXPLÍCITO iniciado desde la Activity visible.
 * No inicia con BOOT_COMPLETED, no intenta eludir el bloqueo de pantalla
 * ni abre otras aplicaciones desde segundo plano.
 */
class JarvisListeningService : Service(), RecognitionListener {
    companion object {
        const val ACTION_START = "com.jarvis.openandroid.wake.START"
        const val ACTION_STOP = "com.jarvis.openandroid.wake.STOP"
        const val ACTION_SILENCE = "com.jarvis.openandroid.wake.SILENCE"
        private const val TAG = "JarvisWake"
        private const val CHANNEL = "jarvis_active_listening"
        private const val NOTIFICATION_ID = 2203
        val isRunning = MutableStateFlow(false)
        val status = MutableStateFlow("Escucha desactivada")
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var speechService: SpeechService? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var appVoiceActive = false
    private val conversationSession = ConversationSession()
    private var continuousVoiceEnabled = false
    private var utteranceCounter = 0L
    private var currentUtteranceId: String? = null
    private var speechChunks: List<String> = emptyList()
    private var nextSpeechChunk = 0
    private var resumeJob: Job? = null
    private var windowExpiryJob: Job? = null
    private val audioGate = WakeAudioGate()
    private var workInProgress = false
    private val commandEngine = LocalCommandEngine()
    private val ai = ConversationGateway()
    private val visibleHistory by lazy { ConversationHistory(applicationContext) }
    private val personalMemories by lazy { PersonalMemoryStore(applicationContext) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(applicationContext) { code ->
            if (code == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setLanguage(Locale.forLanguageTag("es-MX"))
                val prefs = getSharedPreferences("jarvis_voice_v02", MODE_PRIVATE)
                val chosen = prefs.getString("voice_id", "").orEmpty()
                tts?.voices?.firstOrNull { it.name == chosen && it.locale.language == "es" }
                    ?.let { tts?.voice = it }
                tts?.setPitch(prefs.getFloat("pitch", 0.85f))
                tts?.setSpeechRate(prefs.getFloat("rate", 0.93f))
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) = onSpeechFinished(utteranceId, true)
                    @Deprecated("Legacy callback")
                    override fun onError(utteranceId: String?) = onSpeechFinished(utteranceId, false)
                    override fun onError(utteranceId: String?, errorCode: Int) = onSpeechFinished(utteranceId, false)
                    override fun onStop(utteranceId: String?, interrupted: Boolean) = onSpeechFinished(utteranceId, false)
                })
            }
        }
        scope.launch {
            JarvisPreferences(applicationContext).settings.collect { updated ->
                if (continuousVoiceEnabled && !updated.continuousVoice) conversationSession.end()
                continuousVoiceEnabled = updated.continuousVoice
            }
        }
        scope.launch {
            VoicePlaybackState.appVoiceActive.collect { active ->
                appVoiceActive = active
                if (active) {
                    pauseRecognition()
                    status.value = "Voz activa · micrófono pausado para evitar eco"
                } else if (isRunning.value && !speaking && !workInProgress) {
                    scheduleRecognitionResume()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_SILENCE) {
            if (isRunning.value) {
                currentUtteranceId = null
                speechChunks = emptyList()
                nextSpeechChunk = 0
                tts?.stop()
                speaking = false
                conversationSession.end()
                windowExpiryJob?.cancel()
                status.value = "Respuesta detenida · reanudando escucha"
                scheduleRecognitionResume()
            }
            return START_NOT_STICKY
        }
        if (isRunning.value) return START_NOT_STICKY
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
            !OfflineModelInstaller.isInstalled(this)) {
            status.value = "Faltan permiso de micrófono o modelo local"
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (error: Exception) {
            status.value = "No se pudo iniciar servicio: ${error.message.orEmpty()}"
            stopSelf()
            return START_NOT_STICKY
        }
        isRunning.value = true
        status.value = "Cargando detector de voz local…"
        scope.launch {
            try {
                val nativeModel = withContext(Dispatchers.IO) { Model(OfflineModelInstaller.modelPath(this@JarvisListeningService).absolutePath) }
                if (!isRunning.value) { nativeModel.close(); return@launch }
                model = nativeModel
                recognizer = Recognizer(nativeModel, 16000.0f)
                speechService = SpeechService(requireNotNull(recognizer), 16000.0f)
                speechService?.startListening(this@JarvisListeningService)
                // El modelo empieza en pausa hasta confirmar que no hay voz sintética reproduciéndose.
                pauseRecognition()
                scheduleRecognitionResume()
            } catch (error: Exception) {
                status.value = "Error iniciando Vosk: ${error.message ?: "desconocido"}"
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val showApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, JarvisListeningService::class.java).setAction(ACTION_STOP)
        val stop = PendingIntent.getService(
            this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val silenceIntent = Intent(this, JarvisListeningService::class.java).setAction(ACTION_SILENCE)
        val silence = PendingIntent.getService(
            this, 2, silenceIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("J.A.R.V.I.S. · escucha activa")
            .setContentText("Detectando la palabra Jarvis en este dispositivo")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(showApp)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_lock_silent_mode, "Silenciar voz", silence).build())
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Detener", stop).build())
            .build()
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL, "Escucha J.A.R.V.I.S.", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Escucha local iniciada por el usuario; se puede detener desde la notificación"
            }
        )
    }

    override fun onPartialResult(hypothesis: String?) = Unit // Evita disparar con hipótesis incompletas.
    override fun onResult(hypothesis: String?) = processHypothesis(hypothesis)
    override fun onFinalResult(hypothesis: String?) = Unit
    override fun onTimeout() = Unit
    override fun onError(exception: Exception?) {
        Log.w(TAG, "Vosk/micrófono reportó un error", exception)
        status.value = "El micrófono se detuvo: ${exception?.message ?: "error"}"
        stopSelf()
    }

    private fun processHypothesis(json: String?) {
        if (!isRunning.value || speaking || workInProgress || appVoiceActive ||
            !audioGate.mayAccept(SystemClock.elapsedRealtime()) || json.isNullOrBlank()) return
        val spoken = try { JSONObject(json).optString("text").trim() } catch (_: Exception) { "" }
        if (spoken.isBlank()) return
        val now = SystemClock.elapsedRealtime()
        val afterWake = WakeWordMatcher.commandAfterWakeWord(spoken)
        when {
            afterWake != null -> {
                if (ConversationSession.isEndCommand(spoken) || ConversationSession.isEndCommand(afterWake)) {
                    conversationSession.end()
                    say("Entendido. Conversación finalizada.")
                } else {
                    conversationSession.onWake(afterWake.isNotBlank(), continuousVoiceEnabled)
                    if (afterWake.isNotBlank()) handleCommand(afterWake)
                    else say("A sus órdenes.")
                }
            }
            conversationSession.isOpen(now) && conversationSession.takeFollowup(now) -> {
                if (ConversationSession.isEndCommand(spoken)) {
                    conversationSession.end()
                    say("Entendido. Conversación finalizada.")
                } else {
                    handleCommand(spoken)
                }
            }
            else -> Unit // Sin activación ni sesión vigente, no enviar voz accidental a Groq.
        }
    }

    private fun handleCommand(phrase: String) {
        workInProgress = true
        pauseRecognition()
        status.value = "Procesando orden…"
        scope.launch {
            try {
                val keyguard = getSystemService(KeyguardManager::class.java)
                val locked = keyguard.isDeviceLocked
                val config = JarvisPreferences(applicationContext).settings.first()
                val safePublic = LocalRouting.isPublicWhenLocked(phrase)
                personalMemories.migrateLegacy(config.memory)
                val memoryCommand = PersonalMemoryCommands.parse(phrase)
                val localOnly = config.provider == "local" || LocalRouting.isLocal(phrase) || memoryCommand != null
                val output = when {
                    locked && !safePublic && !config.allowOnLock ->
                        "Por privacidad, desbloquea el teléfono para hacer preguntas abiertas. Puedes cambiarlo en Ajustes de Jarvis."
                    locked && localOnly && !safePublic ->
                        "Por seguridad, desbloquea el teléfono para gestionar información o ejecutar comandos."
                    memoryCommand != null -> personalMemories.respond(memoryCommand)
                    localOnly ->
                        commandEngine.answer(phrase, "")?.text ?: "Configura un modelo de inteligencia artificial en la aplicación para poder responder preguntas abiertas."
                    config.provider == "local" ->
                        "Configura un modelo de inteligencia artificial en Ajustes para conversar conmigo."
                    else -> {
                        // Solo envía TEXTO reconocido, jamás audio, con consentimiento expreso.
                        val memory = ConversationMemory(applicationContext)
                        val optionalPersonal = if (!locked && config.usePersonalMemoriesWithAi)
                            personalMemories.read() else emptyList()
                        val answer = ai.reply(config, SecureApiKeyStore(applicationContext).read(),
                            phrase, memory.read(), optionalPersonal)
                        memory.addPair(phrase, answer)
                        answer
                    }
                }
                visibleHistory.addPair(phrase, output, "manos libres")
                say(output)
            } catch (error: Exception) {
                val response = "No pude comunicarme con el modelo de IA: ${error.message ?: "revisa la conexión"}"
                visibleHistory.addPair(phrase, response, "manos libres")
                say(response)
            } finally {
                workInProgress = false
            }
        }
    }

    private fun pauseRecognition() {
        resumeJob?.cancel()
        audioGate.mute()
        speechService?.setPause(true)
    }

    /** Espera a que el altavoz termine y que desaparezca su eco acústico. */
    private fun scheduleRecognitionResume() {
        pauseRecognition()
        if (!isRunning.value || speaking || workInProgress || appVoiceActive) return
        audioGate.prepareToResume(SystemClock.elapsedRealtime())
        resumeJob = scope.launch {
            delay(audioGate.millisUntilReady(SystemClock.elapsedRealtime()))
            if (!isRunning.value || speaking || workInProgress || appVoiceActive ||
                !audioGate.mayAccept(SystemClock.elapsedRealtime())) return@launch
            speechService?.reset()
            speechService?.setPause(false)
            val expiresAt = conversationSession.onRecognitionResumed(SystemClock.elapsedRealtime())
            windowExpiryJob?.cancel()
            status.value = if (expiresAt != null)
                "Conversación activa · pregunta sin decir «Jarvis»"
            else "Escuchando «Jarvis» (detección local)"
            if (expiresAt != null) {
                windowExpiryJob = scope.launch {
                    delay((expiresAt - SystemClock.elapsedRealtime()).coerceAtLeast(0L))
                    if (isRunning.value && !speaking && !workInProgress &&
                        !conversationSession.isOpen(SystemClock.elapsedRealtime())) {
                        status.value = "Escuchando «Jarvis» (detección local)"
                    }
                }
            }
            Log.d(TAG, "Micrófono reanudado tras terminar voz y cooldown")
        }
    }

    /** Cada callback avanza al siguiente bloque. El micrófono sigue pausado hasta el último. */
    private fun onSpeechFinished(id: String?, successful: Boolean) {
        android.os.Handler(mainLooper).post {
            if (id == null || id != currentUtteranceId) return@post
            currentUtteranceId = null
            if (successful && nextSpeechChunk < speechChunks.size) {
                playNextSpeechChunk()
            } else {
                if (!successful) {
                    Log.w(TAG, "La síntesis de voz falló durante un fragmento")
                    status.value = "Lectura de voz interrumpida · respuesta escrita disponible"
                    tts?.stop()
                }
                speechChunks = emptyList()
                nextSpeechChunk = 0
                speaking = false
                scheduleRecognitionResume()
            }
        }
    }

    private fun playNextSpeechChunk() {
        if (!speaking || nextSpeechChunk >= speechChunks.size) return
        val part = speechChunks[nextSpeechChunk++]
        val id = "jarvis-background-${++utteranceCounter}"
        currentUtteranceId = id
        status.value = "Respondiendo por voz… ($nextSpeechChunk/${speechChunks.size})"
        if (!ttsReady || tts?.speak(part, TextToSpeech.QUEUE_FLUSH, null, id) != TextToSpeech.SUCCESS) {
            onSpeechFinished(id, false)
        } else {
            // Protección POR BLOQUE; una respuesta de varios minutos ya no caduca a los 90 s.
            android.os.Handler(mainLooper).postDelayed({
                if (currentUtteranceId == id) onSpeechFinished(id, false)
            }, 90_000L)
        }
    }

    private fun say(message: String) {
        pauseRecognition()
        // El texto original se guarda íntegro; solo se normaliza para el sintetizador.
        speechChunks = SpokenResponse.chunks(message)
        nextSpeechChunk = 0
        currentUtteranceId = null
        speaking = speechChunks.isNotEmpty()
        if (speaking) playNextSpeechChunk()
        else scheduleRecognitionResume()
    }

    override fun onDestroy() {
        isRunning.value = false
        status.value = "Escucha desactivada"
        resumeJob?.cancel()
        windowExpiryJob?.cancel()
        conversationSession.end()
        scope.cancel()
        try { speechService?.cancel() } catch (_: Exception) { }
        try { speechService?.shutdown() } catch (_: Exception) { }
        try { recognizer?.close() } catch (_: Exception) { }
        try { model?.close() } catch (_: Exception) { }
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
