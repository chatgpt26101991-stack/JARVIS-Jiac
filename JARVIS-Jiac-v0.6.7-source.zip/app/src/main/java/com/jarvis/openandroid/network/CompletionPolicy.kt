package com.jarvis.openandroid.network

/**
 * Límites de generación y ensamblado de respuestas. No recorta silenciosamente texto.
 * La generación se puede continuar automáticamente cuando el proveedor informa `length`.
 */
object CompletionPolicy {
    const val REQUEST_TOKEN_BUDGET = 2600
    const val MAX_CONTINUATIONS = 2
    const val MAX_FULL_ANSWER_LENGTH = 16000
    private const val OVERLAP_SEARCH_LENGTH = 200
    private const val MIN_OVERLAP = 12
    private const val INCOMPLETE_NOTICE = "\n\n[Aviso de J.A.R.V.I.S.: la respuesta quedó incompleta por un límite de generación. Puedes pedirme que continúe.]"
    private const val MAXIMUM_NOTICE = "\n\n[Aviso de J.A.R.V.I.S.: se alcanzó el límite de longitud de una respuesta. Pídeme continuar en otra pregunta.]"

    fun needsContinuation(finishReason: String?): Boolean =
        finishReason?.trim()?.lowercase() in setOf("length", "max_tokens", "max_output_tokens")

    /** La siguiente parte puede repetir unas palabras del final; evita duplicarlas. */
    fun join(previous: String, continuation: String): String {
        if (previous.isEmpty()) return continuation.trim()
        val next = continuation.trimStart()
        if (next.isEmpty()) return previous
        val limit = minOf(OVERLAP_SEARCH_LENGTH, previous.length, next.length)
        val overlap = (limit downTo MIN_OVERLAP).firstOrNull { count ->
            previous.takeLast(count).equals(next.take(count), ignoreCase = true)
        } ?: 0
        if (overlap > 0) return previous + next.drop(overlap)
        val separator = if (previous.last().isWhitespace() || next.first().isWhitespace() ||
            previous.last() in "([{\"'¡¿" || next.first() in ".,;:!?)]}") "" else " "
        return previous + separator + next
    }

    /** Acota las respuestas anormalmente largas con advertencia explícita y sin exceder la cuota. */
    fun capWithNotice(answer: String): String {
        if (answer.length <= MAX_FULL_ANSWER_LENGTH) return answer
        return answer.take(MAX_FULL_ANSWER_LENGTH - MAXIMUM_NOTICE.length).trimEnd() + MAXIMUM_NOTICE
    }

    /** Si el proveedor agotó su presupuesto, indicar expresamente que falta contenido. */
    fun markIncomplete(answer: String): String =
        if (answer.contains(INCOMPLETE_NOTICE)) answer else capWithNotice(
            answer.take(MAX_FULL_ANSWER_LENGTH - INCOMPLETE_NOTICE.length).trimEnd() + INCOMPLETE_NOTICE)
}
