package com.jarvis.openandroid.ui

/** Solo cambia la PRESENTACIÓN y la copia; el historial original nunca se reescribe. */
object MessageText {
    fun readable(source: String): String {
        return source
            // Encabezados de Markdown (#, ##, ###...) sin perder su contenido.
            .replace(Regex("(?m)^\\s{0,3}#{1,6}\\s+"), "")
            // Eliminar marcadores de negrita/cursiva sin alterar las palabras.
            .replace(Regex("\\*\\*([^*\\n]+)\\*\\*"), "$1")
            .replace(Regex("__([^_\\n]+)__"), "$1")
            .replace(Regex("(?<!\\*)\\*([^*\\n]+)\\*(?!\\*)"), "$1")
            // Código en línea; no elimina ni modifica contenido de bloques de código.
            .replace(Regex("`([^`\\n]+)`"), "$1")
    }
}
