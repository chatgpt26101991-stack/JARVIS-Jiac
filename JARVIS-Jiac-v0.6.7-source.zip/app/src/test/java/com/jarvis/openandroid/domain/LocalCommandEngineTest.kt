package com.jarvis.openandroid.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LocalCommandEngineTest {
    private val sut = LocalCommandEngine()

    @Test fun `guarda un recuerdo sin enviar al servidor`() {
        val reply = sut.answer("Recuerda que prefiero respuestas breves", "")
        assertEquals("prefiero respuestas breves", reply?.newMemory)
    }

    @Test fun `consulta recuerdo local`() {
        val reply = sut.answer("Qué recuerdas", "mi nota")
        assertEquals("Recuerdo esto: mi nota", reply?.text)
    }

    @Test fun `abre ajustes mediante accion tipada`() {
        assertEquals(AssistantAction.OpenDeviceSettings, sut.answer("abre ajustes", "")?.action)
    }

    @Test fun `pregunta abierta se delega a proveedor`() {
        assertNull(sut.answer("explica el aprendizaje automático", ""))
    }
}
