package com.jarvis.openandroid.domain

import com.jarvis.openandroid.speech.SpokenResponse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpokenResponseTest {
    @Test fun shortReplyIsUnchanged() {
        assertEquals("A sus órdenes.", SpokenResponse.concise("A sus órdenes."))
    }

    @Test fun boldAndItalicAreNotPronounced() {
        assertEquals("Júpiter es el mayor planeta.", SpokenResponse.concise("**Júpiter** es el *mayor* planeta."))
        assertEquals("Marte y Saturno.", SpokenResponse.concise("__Marte__ y _Saturno_."))
    }

    @Test fun tripleEmphasisIsNotPronounced() {
        assertEquals("Júpiter y Marte", SpokenResponse.concise("***Júpiter*** y **Marte**"))
    }

    @Test fun headingsListsAndLinksAreReadable() {
        assertEquals("Júpiter Puedes consultar NASA.",
            SpokenResponse.concise("# Júpiter\n- Puedes consultar [NASA](https://science.nasa.gov)."))
        assertEquals("Foto de Júpiter", SpokenResponse.concise("![Foto de Júpiter](https://example.com/jupiter.png)"))
    }

    @Test fun inlineCodeAndStrikethroughHaveNoDelimiters() {
        assertEquals("Usa Kotlin y evita texto viejo.",
            SpokenResponse.concise("Usa `Kotlin` y evita ~~texto viejo~~."))
    }

    @Test fun mathematicalOperatorsAndIdentifiersStayIntact() {
        assertEquals("2 * 3 = 6; 2 ** 3 = 8; archivo_2026; 10 × 2 = 20.",
            SpokenResponse.concise("2 * 3 = 6; 2 ** 3 = 8; archivo_2026; 10 × 2 = 20."))
    }

    @Test fun longReplyIsCondensedWithoutCuttingWords() {
        val verbose = "Una explicación clara que ocupa varias palabras. ".repeat(20)
        val result = SpokenResponse.concise(verbose, 160)
        assertTrue(result.length < verbose.length)
        assertTrue(result.endsWith("Si quieres, puedo ampliar la respuesta."))
    }
    @Test fun longSpeechIsSplitWithoutLosingAnyContent() {
        val text = "Iron Man, el inventor. Batman, el detective. ".repeat(120)
        val expected = SpokenResponse.plainForSpeech(text)
        val chunks = SpokenResponse.chunks(text, 250)
        assertTrue(chunks.size > 5)
        assertTrue(chunks.all { it.isNotBlank() && it.length <= 250 })
        assertEquals(expected, chunks.joinToString(" "))
        assertTrue(chunks.last().endsWith("detective."))
    }

    @Test fun speechChunksKeepBothFirstAndLastParagraph() {
        val text = "# Inicio\n" + "Este es un detalle importante. ".repeat(85) + "\nFin de la explicación."
        val parts = SpokenResponse.chunks(text)
        assertTrue(parts.size > 2)
        assertEquals(SpokenResponse.plainForSpeech(text), parts.joinToString(" "))
        assertTrue(parts.last().endsWith("Fin de la explicación."))
    }

    @Test fun emptyAndShortSpeechHavePredictableChunks() {
        assertEquals(emptyList<String>(), SpokenResponse.chunks("  "))
        assertEquals(listOf("A sus órdenes."), SpokenResponse.chunks("**A sus órdenes.**"))
    }

    @Test fun enormousWordCanBeSplitWithoutDroppingLetters() {
        val longWord = "a".repeat(1500)
        val chunks = SpokenResponse.chunks(longWord, 200)
        assertTrue(chunks.all { it.length <= 200 })
        assertEquals(longWord, chunks.joinToString(""))
    }
    @Test fun markdownHeadingsNeverSayHashOrAlmohadilla() {
        val text = "#Iron Man\n## Batman\n### Comparación de ambos"
        val spoken = SpokenResponse.plainForSpeech(text)
        assertEquals("Iron Man Batman Comparación de ambos", spoken)
        assertTrue(!spoken.contains('#'))
    }

    @Test fun comparativeThreeColumnTableLabelsBothCharacters() {
        val text = "| Aspecto | Iron Man | Batman |\n" +
            "|---------|----------|--------|\n" +
            "| Tecnología | Armadura con IA | Gadgets y Batmóvil |\n" +
            "| Motivación | Redención personal | Justicia en Gotham |"
        assertEquals(
            "Tecnología. Iron Man: Armadura con IA. Batman: Gadgets y Batmóvil. " +
                "Motivación. Iron Man: Redención personal. Batman: Justicia en Gotham.",
            SpokenResponse.plainForSpeech(text)
        )
    }

    @Test fun twoColumnTableExplainsWhoIsWhoWithoutPipes() {
        val text = "| Iron Man | Batman |\n|---|---|\n" +
            "| Usa una armadura. | Es detective. |"
        assertEquals("Iron Man: Usa una armadura. Batman: Es detective.", SpokenResponse.plainForSpeech(text))
    }

    @Test fun longComparativeSpeechKeepsLabelsAndLastRow() {
        val table = "| Aspecto | Iron Man | Batman |\n|---|---|---|\n" +
            (1..18).joinToString("\n") { i ->
                "| Aspecto $i | Armadura $i | Detective $i |"
            }
        val speech = SpokenResponse.chunks(table, 180).joinToString(" ")
        assertEquals(SpokenResponse.plainForSpeech(table), speech)
        assertTrue(speech.contains("Iron Man: Armadura 18."))
        assertTrue(speech.contains("Batman: Detective 18."))
        assertTrue(!speech.contains('|'))
    }

    @Test fun nonMarkdownSymbolsRetainMeaning() {
        val text = "C# y 2 * 3 = 6"
        assertEquals(text, SpokenResponse.plainForSpeech(text))
    }

}
