package com.jarvis.openandroid.domain

import com.jarvis.openandroid.wake.WakeWordMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class WakeWordMatcherTest {
    @Test fun detectsJarvis() { assertEquals("que hora es", WakeWordMatcher.commandAfterWakeWord("Jarvis, ¿qué hora es?")) }
    @Test fun doesNotMatchSimilar() { assertNull(WakeWordMatcher.commandAfterWakeWord("mi jarvisito funciona")) }
    @Test fun recognizesSpanishVariant() { assertEquals("abre ajustes", WakeWordMatcher.commandAfterWakeWord("Yarvis abre ajustes")) }
    @Test fun noKeyword() { assertNull(WakeWordMatcher.commandAfterWakeWord("qué hora es")) }
}
