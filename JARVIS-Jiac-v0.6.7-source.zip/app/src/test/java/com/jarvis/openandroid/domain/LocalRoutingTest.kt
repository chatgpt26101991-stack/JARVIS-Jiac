package com.jarvis.openandroid.domain

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalRoutingTest {
    @Test fun localActionsStayLocal() {
        listOf(
            "Abre ajustes", "Jarvis, ¿Qué hora es?", "Recuerda que mañana salgo",
            "dime la hora", "¿Me puedes decir qué hora es?", "Jarvis dime que hora es ahora",
            "Me das la hora por favor", "¿Qué horas son?", "¿Qué hora tenemos?",
            "Dime la fecha de hoy", "Qué día es hoy"
        ).forEach { assertTrue("No fue local: $it", LocalRouting.isLocal(it)) }
    }

    @Test fun openConversationGoesToModel() {
        listOf(
            "Explícame cómo funciona un Data Warehouse", "¿A qué hora empieza la película?",
            "Hazme un cuento sobre la luna", "¿Qué hora es en Tokio?",
            "¿A qué hora tengo mi cita mañana?", "¿Cuántas horas tiene un día?"
        ).forEach { assertFalse("No debería ser local: $it", LocalRouting.isLocal(it)) }
    }

    @Test fun lockedPhoneOnlyPublicLocalIntents() {
        assertTrue(LocalRouting.isPublicWhenLocked("qué hora es"))
        assertTrue(LocalRouting.isPublicWhenLocked("Jarvis, dime la hora"))
        assertTrue(LocalRouting.isPublicWhenLocked("¿Qué día es hoy?"))
        assertFalse(LocalRouting.isPublicWhenLocked("Qué recuerdas"))
        assertFalse(LocalRouting.isPublicWhenLocked("¿A qué hora empieza la película?"))
    }
}
