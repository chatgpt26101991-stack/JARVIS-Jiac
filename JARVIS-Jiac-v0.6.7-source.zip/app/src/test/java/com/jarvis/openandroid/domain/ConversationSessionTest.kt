package com.jarvis.openandroid.domain

import com.jarvis.openandroid.wake.ConversationSession
import org.junit.Assert.*
import org.junit.Test

class ConversationSessionTest {
    @Test fun wakeAndFollowupsExpireAfterSilence() {
        val session = ConversationSession()
        session.onWake(hasCommand = true, continuousEnabled = true)
        assertEquals(16000L, session.onRecognitionResumed(1000L))
        assertTrue(session.isOpen(15999L))
        assertFalse(session.isOpen(16000L))
        assertFalse(session.takeFollowup(16000L))
    }

    @Test fun followsUpWithoutWakeFourTimesThenRequiresWake() {
        val session = ConversationSession()
        session.onWake(hasCommand = true, continuousEnabled = true)
        var now = 1000L
        repeat(4) { turn ->
            assertEquals(now + 15000L, session.onRecognitionResumed(now))
            assertTrue(session.takeFollowup(now + 100L))
            now += 1000L
        }
        assertNull(session.onRecognitionResumed(now))
        assertFalse(session.takeFollowup(now + 200L))
    }

    @Test fun wakeOnlyStillAllowsOneCommandWithoutContinuousMode() {
        val session = ConversationSession()
        session.onWake(hasCommand = false, continuousEnabled = false)
        assertEquals(13000L, session.onRecognitionResumed(1000L))
        assertTrue(session.takeFollowup(2000L))
        assertNull(session.onRecognitionResumed(3000L))
    }

    @Test fun ordinaryWakeCommandDoesNotAutoListenIfDisabled() {
        val session = ConversationSession()
        session.onWake(hasCommand = true, continuousEnabled = false)
        assertNull(session.onRecognitionResumed(1000L))
    }

    @Test fun endingConversationStopsWindow() {
        val session = ConversationSession()
        session.onWake(hasCommand = true, continuousEnabled = true)
        session.onRecognitionResumed(1000L)
        session.end()
        assertFalse(session.isOpen(1200L))
        assertFalse(session.takeFollowup(1200L))
        assertTrue(ConversationSession.isEndCommand("Terminar conversación"))
        assertFalse(ConversationSession.isEndCommand("Qué hora es"))
    }
}
