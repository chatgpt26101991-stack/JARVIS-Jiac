package com.jarvis.openandroid.domain

import com.jarvis.openandroid.ui.MessageText
import org.junit.Assert.assertEquals
import org.junit.Test

class MessageTextTest {
    @Test fun removesMarkdownEmphasisFromVisibleAndCopiedText() {
        val original = "1. **Seguridad primero** — revisa piezas\n2. **Ventilación** — deja espacios"
        assertEquals("1. Seguridad primero — revisa piezas\n2. Ventilación — deja espacios", MessageText.readable(original))
    }

    @Test fun retainsParagraphsAndNumberingInLongResponses() {
        val longAnswer = (1..40).joinToString("\n") { "$it. **Consejo** $it" }
        val converted = MessageText.readable(longAnswer)
        assertEquals((1..40).joinToString("\n") { "$it. Consejo $it" }, converted)
    }

    @Test fun removesHeaderAndInlineCodeMarkers() {
        assertEquals("Recomendaciones\nUsa println() y actúa con cuidado.",
            MessageText.readable("## Recomendaciones\nUsa `println()` y actúa con *cuidado*."))
    }

    @Test fun doesNotAffectUnformattedText() {
        val text = "Groq funciona, Jarvis recuerda los colores y responde por voz."
        assertEquals(text, MessageText.readable(text))
    }
}
