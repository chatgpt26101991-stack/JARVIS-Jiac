package com.jarvis.openandroid.domain

import org.junit.Assert.*
import org.junit.Test

class JarvisPersonaTest {
    @Test fun `normaliza la configuracion sin perder equilibrio predeterminado`() {
        assertEquals(JarvisPersona.BALANCED, JarvisPersona.normalize(null))
        assertEquals(JarvisPersona.BALANCED, JarvisPersona.normalize("otro"))
        assertEquals(JarvisPersona.PROFESSIONAL, JarvisPersona.normalize("profesional"))
    }

    @Test fun `equilibrado indica una ocurrencia en conversaciones claramente ludicas`() {
        val prompt = JarvisPersona.systemPrompt(JarvisPersona.BALANCED,
            "Jarvis, construiré un traje de Iron Man con cartón, ¿qué opinas?")
        assertTrue(prompt.contains("MODO EQUILIBRADO"))
        assertTrue(prompt.contains("UNA observación breve"))
        assertTrue(prompt.contains("CONTEXTO ACTUAL"))
        assertTrue(prompt.contains("PRIORIDAD ABSOLUTA"))
    }

    @Test fun `pregunta sobre genio recibe pista de contexto pero pregunta normal no`() {
        assertTrue(JarvisPersona.isClearlyPlayful("Jarvis, ¿tú crees que soy un genio?"))
        assertFalse(JarvisPersona.isClearlyPlayful("¿Cuál es la capital de Perú?"))
        assertFalse(JarvisPersona.systemPrompt(JarvisPersona.BALANCED, "¿Cuál es la capital de Perú?")
            .contains("CONTEXTO ACTUAL"))
    }

    @Test fun `emergencia tiene prioridad incluso si incluye palabras ludicas`() {
        assertFalse(JarvisPersona.isClearlyPlayful("Me herí probando mi traje de Iron Man"))
        assertFalse(JarvisPersona.isClearlyPlayful("Tengo una emergencia con un cartón"))
        val prompt = JarvisPersona.systemPrompt(JarvisPersona.WITTY, "Me herí probando mi traje de Iron Man")
        assertFalse(prompt.contains("CONTEXTO ACTUAL"))
        listOf(JarvisPersona.PROFESSIONAL, JarvisPersona.BALANCED, JarvisPersona.WITTY).forEach { mode ->
            val policy = JarvisPersona.systemPrompt(mode)
            assertTrue(policy.contains("omite absolutamente el sarcasmo y las bromas"))
            assertTrue(policy.contains("No inventes hechos"))
        }
    }

    @Test fun `profesional no recibe pista de humor aunque la solicitud sea ludica`() {
        val prompt = JarvisPersona.systemPrompt(JarvisPersona.PROFESSIONAL, "¿Soy un genio?")
        assertTrue(prompt.contains("sin sarcasmo y casi sin bromas"))
        assertFalse(prompt.contains("CONTEXTO ACTUAL"))
        assertFalse(prompt.contains("EJEMPLOS ORIENTATIVOS"))
    }
}
