package com.jarvis.openandroid.vision

/** Reglas sencillas y probables mediante pruebas JVM sin llamar a servicios externos. */
object VisionRequestPolicy {
    const val MODEL = "qwen/qwen3.8-27b"
    const val MAX_IMAGE_BYTES = 4 * 1024 * 1024
    const val ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"

    /** Mensajes de error claros; sin imprimir secretos, imagen, ni la respuesta bruta de Groq. */
    fun httpErrorMessage(status: Int, providerCode: String? = null): String {
        val explanation = when (status) {
            400 -> "Solicitud de imagen rechazada. Revisa el formato y los límites del modelo."
            401 -> "La clave API de Groq no fue aceptada; compruébala en Ajustes."
            403 -> "La clave API no tiene acceso al modelo de visión; revisa los permisos en Groq."
            404 -> "No se encontró el modelo de visión $MODEL o la ruta del servicio. Revisa su disponibilidad en Groq."
            413 -> "La fotografía supera el límite de tamaño del proveedor."
            429 -> "Se alcanzó un límite de solicitudes o cuota de Groq; inténtalo más tarde."
            in 500..599 -> "El servicio de Groq no pudo procesar la imagen temporalmente."
            else -> "No se pudo completar el análisis visual con Groq."
        }
        // El proveedor puede facilitar un código diagnóstico; nunca mostramos una respuesta completa.
        val allowedCodes = setOf(
            "model_not_found", "model_decommissioned", "invalid_api_key", "invalid_request_error",
            "rate_limit_exceeded", "insufficient_quota", "permission_denied", "access_denied"
        )
        val code = providerCode?.takeIf { it in allowedCodes }
        return "Groq HTTP $status: $explanation" + (code?.let { " (código: $it)" } ?: "")
    }

    fun validateJpeg(photo: ByteArray) {
        require(photo.size in 4..MAX_IMAGE_BYTES) { "Fotografía vacía o demasiado grande." }
        require(photo[0] == 0xFF.toByte() && photo[1] == 0xD8.toByte() &&
            photo[photo.size - 2] == 0xFF.toByte() && photo.last() == 0xD9.toByte()) {
            "La foto debe ser una imagen JPEG válida."
        }
    }

    fun isGroqEndpoint(endpoint: String): Boolean = try {
        val uri = java.net.URI(endpoint.trim())
        uri.scheme.equals("https", true) && uri.host.equals("api.groq.com", true) &&
            uri.path == "/openai/v1/chat/completions" && uri.rawUserInfo == null &&
            uri.rawQuery == null && uri.rawFragment == null
    } catch (_: Exception) { false }
}
