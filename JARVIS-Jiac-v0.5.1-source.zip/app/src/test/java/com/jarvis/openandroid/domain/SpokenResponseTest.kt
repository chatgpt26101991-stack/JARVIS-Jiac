package com.jarvis.openandroid.domain

import com.jarvis.openandroid.speech.SpokenResponse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpokenResponseTest {
    @Test fun shortReplyIsUnchanged() {
        assertEquals("A sus órdenes.", SpokenResponse.concise("A sus órdenes."))
    }

    @Test fun boldAndItalicAreNotPronounced() {
        assertEquals("Júpiter es el mayor planeta.", SpokenResponse.concise("**Júpiter** es el *mayor* planeta."))
        assertEquals("Marte y Saturno.", SpokenResponse.concise("__Marte__ y _Saturno_."))
    }

    @Test fun tripleEmphasisIsNotPronounced() {
        assertEquals("Júpiter y Marte", SpokenResponse.concise("***Júpiter*** y **Marte**"))
    }

    @Test fun headingsListsAndLinksAreReadable() {
        assertEquals("Júpiter Puedes consultar NASA.",
            SpokenResponse.concise("# Júpiter\n- Puedes consultar [NASA](https://science.nasa.gov)."))
        assertEquals("Foto de Júpiter", SpokenResponse.concise("![Foto de Júpiter](https://example.com/jupiter.png)"))
    }

    @Test fun inlineCodeAndStrikethroughHaveNoDelimiters() {
        assertEquals("Usa Kotlin y evita texto viejo.",
            SpokenResponse.concise("Usa `Kotlin` y evita ~~texto viejo~~."))
    }

    @Test fun mathematicalOperatorsAndIdentifiersStayIntact() {
        assertEquals("2 * 3 = 6; 2 ** 3 = 8; archivo_2026; 10 × 2 = 20.",
            SpokenResponse.concise("2 * 3 = 6; 2 ** 3 = 8; archivo_2026; 10 × 2 = 20."))
    }

    @Test fun longReplyIsCondensedWithoutCuttingWords() {
        val verbose = "Una explicación clara que ocupa varias palabras. ".repeat(20)
        val result = SpokenResponse.concise(verbose, 160)
        assertTrue(result.length < verbose.length)
        assertTrue(result.endsWith("Si quieres, puedo ampliar la respuesta."))
    }
}
