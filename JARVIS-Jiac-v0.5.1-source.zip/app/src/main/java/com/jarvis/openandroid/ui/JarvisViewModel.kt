package com.jarvis.openandroid.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.openandroid.data.ConversationMemory
import com.jarvis.openandroid.data.JarvisPreferences
import com.jarvis.openandroid.data.JarvisSettings
import com.jarvis.openandroid.data.SecureApiKeyStore
import com.jarvis.openandroid.domain.AssistantAction
import com.jarvis.openandroid.domain.LocalCommandEngine
import com.jarvis.openandroid.domain.LocalRouting
import com.jarvis.openandroid.network.ConversationGateway
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatMessage(val text: String, val isUser: Boolean)

data class JarvisUiState(
    val messages: List<ChatMessage> = listOf(ChatMessage("Sistemas iniciados. Di «Jarvis» para comenzar.", false)),
    val settings: JarvisSettings = JarvisSettings(),
    val busy: Boolean = false,
    val listening: Boolean = false
)

class JarvisViewModel(application: Application) : AndroidViewModel(application) {
    private val preferences = JarvisPreferences(application.applicationContext)
    private val local = LocalCommandEngine()
    private val remote = ConversationGateway()
    private val conversation = ConversationMemory(application.applicationContext)
    private val tokenStore = SecureApiKeyStore(application.applicationContext)
    private val restored = conversation.read().map { ChatMessage(it.content, it.role == "user") }
    private val state = MutableStateFlow(JarvisUiState(messages =
        if (restored.isEmpty()) JarvisUiState().messages else restored))
    val uiState = state.asStateFlow()

    private val _speech = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val speech = _speech.asSharedFlow()
    private val _actions = MutableSharedFlow<AssistantAction>(extraBufferCapacity = 2)
    val actions = _actions.asSharedFlow()

    init {
        viewModelScope.launch {
            preferences.settings.collect { updated -> state.update { it.copy(settings = updated) } }
        }
    }

    fun setContinuousVoice(enabled: Boolean) {
        viewModelScope.launch { preferences.saveContinuousVoice(enabled) }
    }

    fun setListening(value: Boolean) { state.update { it.copy(listening = value) } }

    fun submit(rawText: String) {
        val text = rawText.trim()
        if (text.isBlank() || state.value.busy) return
        state.update { it.copy(busy = true, messages = it.messages + ChatMessage(text, true)) }
        viewModelScope.launch {
            try {
                val settings = state.value.settings
                val simpleCommand = settings.provider == "local" || LocalRouting.isLocal(text)
                val localAnswer = if (simpleCommand) local.answer(text, settings.memory) else null
                val answer = if (localAnswer != null) {
                    if (localAnswer.newMemory != null) preferences.saveMemory(localAnswer.newMemory)
                    localAnswer.action?.let { _actions.emit(it) }
                    localAnswer.text
                } else if (settings.provider != "local") {
                    val reply = remote.reply(settings, tokenStore.read(), text, conversation.read())
                    conversation.addPair(text, reply)
                    reply
                } else {
                    "Para responder preguntas abiertas, configura un modelo en Ajustes → Inteligencia artificial."
                }
                addJarvisAnswer(answer)
            } catch (error: Exception) {
                addJarvisAnswer("No pude consultar el modelo: ${error.message ?: "error de conexión"}")
            } finally { state.update { it.copy(busy = false) } }
        }
    }

    fun addJarvisAnswer(text: String) {
        state.update { it.copy(messages = it.messages + ChatMessage(text, false)) }
        _speech.tryEmit(text)
    }

    fun clearApiKey() {
        tokenStore.clear()
        addJarvisAnswer("Clave API eliminada de este dispositivo.")
    }

    fun clearChat() {
        conversation.clear()
        state.update { it.copy(messages = JarvisUiState().messages) }
        addJarvisAnswer("Conversación borrada de este dispositivo.")
    }

    fun saveRemoteSettings(provider: String, endpoint: String, model: String, secret: String, allowOnLock: Boolean) {
        viewModelScope.launch {
            try {
                require(provider in listOf("local", "ollama", "compatible")) { "Proveedor no válido." }
                if (provider != "local") {
                    ConversationGateway.validate(provider, endpoint)
                    require(model.trim().isNotBlank()) { "Debes indicar el nombre del modelo." }
                    if (provider == "compatible") require(secret.isNotBlank() || tokenStore.read().isNotBlank()) {
                        "Ingresa la clave API. Nunca la pegues en GitHub ni en este chat."
                    }
                }
                if (secret.isNotBlank()) {
                    require(provider == "compatible") { "La clave solo se utiliza con una API compatible." }
                    tokenStore.save(secret.trim())
                }
                preferences.saveAi(provider, if (provider == "local") "" else endpoint.trim(), model.trim(),
                    allowOnLock && provider != "local")
                addJarvisAnswer(if (provider == "local") "Modo local activado." else
                    "Proveedor de IA guardado. Las preguntas abiertas se enviarán a ese servidor cuando me hables.")
            } catch (error: Exception) {
                addJarvisAnswer("No se guardó la configuración: ${error.message ?: "error"}")
            }
        }
    }
}
