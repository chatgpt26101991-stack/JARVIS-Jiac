package com.jarvis.openandroid.speech

/**
 * Prepara texto para TTS sin alterar el mensaje original, la UI ni el historial.
 * Solo elimina marcas comunes de Markdown cuando están bien delimitadas;
 * conserva operadores matemáticos y símbolos que sí tienen significado.
 */
object SpokenResponse {
    private val markdownLink = Regex("""\[([^\]\n]+)]\((?:https?://|mailto:)[^\s)]+\)""")
    private val markdownImage = Regex("""!\[([^\]\n]*)]\((?:https?://|data:)[^\s)]+\)""")
    private val boldItalicStars = Regex("""\*\*\*([^*\s](?:[^*\n]*?[^*\s])?)\*\*\*""")
    private val boldStars = Regex("""\*\*([^*\s](?:[^*\n]*?[^*\s])?)\*\*""")
    private val boldUnderscores = Regex("""(?<![\p{L}\p{N}])__([^_\s](?:[^_\n]*?[^_\s])?)__(?![\p{L}\p{N}])""")
    private val italicStars = Regex("""(?<![\p{L}\p{N}*])\*([^*\s](?:[^*\n]*?[^*\s])?)\*(?![\p{L}\p{N}*])""")
    private val italicUnderscores = Regex("""(?<![\p{L}\p{N}_])_([^_\s](?:[^_\n]*?[^_\s])?)_(?![\p{L}\p{N}_])""")
    private val inlineCode = Regex("""(?<!`)`([^`\n]+)`(?!`)""")
    private val deleted = Regex("""~~([^~\n]+)~~""")
    private val heading = Regex("""(?m)^\s{0,3}#{1,6}\s+""")
    private val quote = Regex("""(?m)^\s{0,3}>\s?""")
    private val unorderedBullet = Regex("""(?m)^\s{0,3}[-*+]\s+""")
    private val horizontalRule = Regex("""(?m)^\s{0,3}(?:-{3,}|\*{3,}|_{3,})\s*$""")
    private val fencedCodeMarker = Regex("""(?m)^\s{0,3}`{3,}[^\n]*$""")

    /** Elimina *solo* marcas de formato reconocibles antes de convertir a voz. */
    fun plainForSpeech(text: String): String {
        if (text.isBlank()) return ""
        return text.replace("\r\n", "\n").replace('\r', '\n')
            .replace(horizontalRule, " ")
            .replace(fencedCodeMarker, " ")
            .replace(heading, "")
            .replace(quote, "")
            .replace(unorderedBullet, "")
            .replace(markdownImage, "$1")
            .replace(markdownLink, "$1")
            .replace(inlineCode, "$1")
            .replace(boldItalicStars, "$1")
            .replace(boldStars, "$1")
            .replace(boldUnderscores, "$1")
            .replace(italicStars, "$1")
            .replace(italicUnderscores, "$1")
            .replace(deleted, "$1")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    /** Acota únicamente lo que se pronuncia, no el texto ni el historial de IA. */
    fun concise(text: String, maxCharacters: Int = 500): String {
        require(maxCharacters >= 120)
        val normalized = plainForSpeech(text)
        if (normalized.length <= maxCharacters) return normalized
        val candidate = normalized.take(maxCharacters)
        val sentenceBoundary = Regex("[.!?](?=\\s)").findAll(candidate).lastOrNull()?.range?.last?.plus(1) ?: 0
        val end = if (sentenceBoundary >= maxCharacters / 2) sentenceBoundary else
            candidate.lastIndexOf(' ').takeIf { it >= maxCharacters / 2 } ?: maxCharacters
        return normalized.take(end).trimEnd(' ', ',', ';', ':', '.') + ". Si quieres, puedo ampliar la respuesta."
    }
}
