package com.jarvis.openandroid.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.openandroid.speech.VoiceConfig
import com.jarvis.openandroid.speech.VoiceOption
import com.jarvis.openandroid.wake.OfflineModelInstaller

private val cyan = Color(0xFF63E6F7)
private val dark = Color(0xFF06131B)
private val panel = Color(0xFF10232D)
private val jarvisPalette = darkColorScheme(
    primary = cyan,
    onPrimary = Color.Black,
    background = dark,
    surface = panel,
    onSurface = Color(0xFFE8F8FD)
)

@Composable
fun JarvisScreen(
    model: JarvisViewModel,
    onListen: () -> Unit,
    onStopSpeech: () -> Unit,
    voiceOptions: List<VoiceOption>,
    voiceConfig: VoiceConfig,
    onSaveVoice: (String, Float, Float) -> Unit,
    onPreviewVoice: (String, Float, Float) -> Unit,
    wakeActive: Boolean,
    wakeStatus: String,
    hasWakeModel: Boolean,
    downloadingWakeModel: Boolean,
    modelStatus: String,
    modelDownloadProgress: OfflineModelInstaller.Progress,
    onInstallWakeModel: () -> Unit,
    onStartWake: () -> Unit,
    onStopWake: () -> Unit
) {
    val state by model.uiState.collectAsState()
    var input by rememberSaveable { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var showVoiceSettings by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current

    fun send() {
        val text = input.trim()
        if (text.isNotBlank() && !state.busy) {
            model.submit(text)
            input = ""
            focus.clearFocus()
        }
    }

    MaterialTheme(colorScheme = jarvisPalette) {
        Scaffold(containerColor = dark) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("J.A.R.V.I.S.", color = cyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { showVoiceSettings = true }) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "Configurar voz de Jarvis", tint = cyan)
                        }
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Configurar proveedor de IA", tint = cyan)
                        }
                    }
                }
                Text("ASISTENTE PERSONAL · OPEN SOURCE", fontSize = 10.sp, color = Color(0xFF8BA5B3), letterSpacing = 2.sp)
                Spacer(Modifier.height(14.dp))
                JarvisCore(state.listening)
                Spacer(Modifier.height(10.dp))
                Text(if (state.listening) "ESCUCHANDO..." else if (state.busy) "PROCESANDO..." else "SISTEMAS EN LÍNEA", color = cyan, fontSize = 12.sp, letterSpacing = 2.sp)
                Text(when (state.settings.provider) {
                    "ollama" -> "MODO HÍBRIDO · OLLAMA"
                    "compatible" -> "MODO HÍBRIDO · IA CONVERSACIONAL"
                    else -> "MODO LOCAL · COMANDOS"
                }, color = Color(0xFF94ADBA), fontSize = 11.sp)
                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    reverseLayout = true
                ) {
                    items(state.messages.asReversed()) { message ->
                        ChatBubble(message)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        label = { Text("Orden para J.A.R.V.I.S.") },
                        maxLines = 3,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send() }),
                        enabled = !state.busy,
                        shape = RoundedCornerShape(14.dp)
                    )
                    IconButton(onClick = { send() }, enabled = input.isNotBlank() && !state.busy) {
                        Icon(Icons.Default.Send, contentDescription = "Enviar orden")
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = onListen, enabled = !state.busy && !state.listening, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Mic, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text(if (state.listening) "Escuchando" else "Hablar con J.A.R.V.I.S.")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = onStopSpeech) { Text("Detener voz") }
                    TextButton(onClick = { model.clearChat() }) { Text("Borrar conversación local") }
                }
                Surface(color = panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("MODO MANOS LIBRES · V0.5.0", color = cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(if (wakeActive) wakeStatus else if (hasWakeModel) "Modelo listo · servicio desactivado" else modelStatus,
                            fontSize = 11.sp, color = Color(0xFFC0D6DF))
                        if (!hasWakeModel) {
                            if (downloadingWakeModel || modelDownloadProgress.downloadedBytes > 0L) {
                                val percentage = modelDownloadProgress.percentage
                                if (percentage == null) {
                                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = cyan)
                                } else {
                                    LinearProgressIndicator(
                                        progress = { percentage / 100f },
                                        modifier = Modifier.fillMaxWidth(),
                                        color = cyan
                                    )
                                }
                                val receivedMb = modelDownloadProgress.downloadedBytes / (1024f * 1024f)
                                val totalMb = modelDownloadProgress.totalBytes?.let { it / (1024f * 1024f) }
                                Text(
                                    buildString {
                                        if (percentage != null) append("$percentage % · ")
                                        append(String.format(java.util.Locale.US, "%.1f MB", receivedMb))
                                        if (totalMb != null) {
                                            append(String.format(java.util.Locale.US, " de %.1f MB", totalMb))
                                        } else append(" descargados")
                                    },
                                    fontSize = 12.sp,
                                    color = cyan
                                )
                            }
                            OutlinedButton(
                                onClick = onInstallWakeModel,
                                enabled = !downloadingWakeModel,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (downloadingWakeModel) "Descargando modelo…"
                                     else if (modelDownloadProgress.downloadedBytes > 0L || modelStatus.startsWith("Error"))
                                         "Reintentar descarga" else "Descargar detector español (~39 MB)")
                            }
                        } else {
                            Button(
                                onClick = if (wakeActive) onStopWake else onStartWake,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(if (wakeActive) "Desactivar escucha de Jarvis" else "Activar Jarvis en segundo plano") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Switch(checked = state.settings.continuousVoice,
                                onCheckedChange = { model.setContinuousVoice(it) })
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Conversación continua (15 segundos)", fontSize = 12.sp)
                                Text("Tras decir «Jarvis», pregunta de nuevo sin repetir su nombre. " +
                                    "Hasta 4 seguimientos por activación. Di «terminar conversación» para salir.",
                                    fontSize = 10.sp, color = Color(0xFF8BA5B3))
                            }
                        }
                        Text("Actívalo desde esta pantalla. Mostrará una notificación con opción Detener. " +
                            "El modo bloqueado depende de Android y del fabricante. Consumo de batería adicional.",
                            fontSize = 10.sp, color = Color(0xFF8BA5B3))
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }

        if (showVoiceSettings) {
            var selectedVoice by remember(showVoiceSettings) { mutableStateOf(voiceConfig.voiceId) }
            var pitch by remember(showVoiceSettings) { mutableFloatStateOf(voiceConfig.pitch) }
            var rate by remember(showVoiceSettings) { mutableFloatStateOf(voiceConfig.rate) }
            var expanded by remember { mutableStateOf(false) }
            AlertDialog(
                onDismissRequest = { showVoiceSettings = false },
                title = { Text("Voz · J.A.R.V.I.S. Latino") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Elige una voz en español instalada en Android y escucha cómo suena. La disponibilidad depende de tu dispositivo.")
                        Box {
                            OutlinedButton(onClick = { expanded = true }) {
                                Text(
                                    voiceOptions.firstOrNull { it.id == selectedVoice }?.label
                                        ?: "Voz predeterminada en español",
                                    maxLines = 2
                                )
                            }
                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false },
                                modifier = Modifier.heightIn(max = 280.dp)
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Voz predeterminada") },
                                    onClick = { selectedVoice = ""; expanded = false }
                                )
                                voiceOptions.forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option.label) },
                                        onClick = { selectedVoice = option.id; expanded = false }
                                    )
                                }
                            }
                        }
                        if (voiceOptions.isEmpty()) {
                            Text("Android no informó voces en español. Revisa la configuración de síntesis de voz del dispositivo.")
                        }
                        Text("Tono grave: ${(pitch * 100).toInt()} %")
                        Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.65f..1.15f)
                        Text("Velocidad: ${(rate * 100).toInt()} %")
                        Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.75f..1.15f)
                        OutlinedButton(onClick = { onPreviewVoice(selectedVoice, pitch, rate) }) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null)
                            Spacer(Modifier.size(6.dp))
                            Text("Probar esta voz")
                        }
                        Text("Nota: bajar el tono no transforma una voz femenina en masculina. Para una voz masculina genuina, selecciona una voz masculina instalada o integra un motor abierto como Piper.", fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        onSaveVoice(selectedVoice, pitch, rate)
                        showVoiceSettings = false
                    }) { Text("Guardar voz") }
                },
                dismissButton = { TextButton(onClick = { showVoiceSettings = false }) { Text("Cancelar") } }
            )
        }

        if (showSettings) {
            var provider by remember(showSettings) { mutableStateOf(state.settings.provider) }
            var endpoint by remember(showSettings) { mutableStateOf(state.settings.endpoint) }
            var remoteModel by remember(showSettings) { mutableStateOf(state.settings.model) }
            var apiKey by remember(showSettings) { mutableStateOf("") }
            var allowOnLock by remember(showSettings) { mutableStateOf(state.settings.allowOnLock) }
            var providerMenu by remember(showSettings) { mutableStateOf(false) }
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Inteligencia artificial · J.A.R.V.I.S.") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Para conversar sobre cualquier tema, conecta un modelo. El detector de «Jarvis» sigue funcionando localmente.")
                        Box {
                            OutlinedButton(onClick = { providerMenu = true }) {
                                Text(when (provider) {
                                    "ollama" -> "Servidor Ollama privado"
                                    "compatible" -> "API compatible (Groq, OpenRouter…)"
                                    else -> "Solo comandos locales"
                                })
                            }
                            DropdownMenu(expanded = providerMenu, onDismissRequest = { providerMenu = false }) {
                                listOf("local" to "Solo comandos locales",
                                    "ollama" to "Servidor Ollama privado",
                                    "compatible" to "API compatible (Groq, OpenRouter…)").forEach { (value, label) ->
                                    DropdownMenuItem(text = { Text(label) }, onClick = {
                                        provider = value
                                        if (value == "compatible" && !endpoint.contains("chat/completions")) {
                                            endpoint = "https://api.groq.com/openai/v1/chat/completions"
                                            remoteModel = "openai/gpt-oss-20b"
                                        }
                                        providerMenu = false
                                    })
                                }
                            }
                        }
                        if (provider != "local") {
                            Text(if (provider == "ollama")
                                "Utiliza un gateway Ollama con HTTPS y acceso controlado."
                                else "Introduce la URL HTTPS y la clave API de un proveedor que controles. El proveedor puede aplicar límites o cargos.",
                                fontSize = 12.sp)
                            OutlinedTextField(value = endpoint, onValueChange = { endpoint = it },
                                label = { Text(if (provider == "ollama") "URL HTTPS /api/chat" else "URL HTTPS /chat/completions") },
                                singleLine = true)
                            OutlinedTextField(value = remoteModel, onValueChange = { remoteModel = it },
                                label = { Text("Identificador del modelo") }, singleLine = true)
                            if (provider == "compatible") {
                                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it },
                                    label = { Text("Clave API (dejar vacío para conservar)") },
                                    singleLine = true, visualTransformation = PasswordVisualTransformation())
                                Text("La clave se cifra con Android Keystore y no se incluye en GitHub. " +
                                    "Tus preguntas de voz se enviarán como texto al proveedor elegido.", fontSize = 11.sp)
                                TextButton(onClick = { model.clearApiKey(); apiKey = "" }) {
                                    Text("Eliminar clave API guardada")
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Switch(checked = allowOnLock, onCheckedChange = { allowOnLock = it })
                                Text("Permitir respuestas de IA con pantalla bloqueada", fontSize = 12.sp)
                            }
                            if (allowOnLock) Text("Aviso: las respuestas se escucharán sin desbloquear el teléfono " +
                                "y se enviará texto de voz al proveedor externo. Evita información privada.", fontSize = 11.sp)
                        }
                        Text("La IA no funciona sin un modelo configurado. No prometemos información en tiempo real ni acciones automáticas.",
                            fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        model.saveRemoteSettings(provider, endpoint, remoteModel, apiKey, allowOnLock)
                        showSettings = false
                    }) { Text("Guardar") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancelar") } }
            )
        }

    }
}

@Composable
private fun JarvisCore(listening: Boolean) {
    Box(Modifier.size(176.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val centerRadius = size.minDimension / 2f
            drawCircle(cyan.copy(alpha = .35f), radius = centerRadius * .93f, style = Stroke(width = 3.dp.toPx()))
            drawCircle(cyan.copy(alpha = .75f), radius = centerRadius * .75f, style = Stroke(width = 2.dp.toPx()))
            drawCircle(if (listening) Color(0xFF43FFD1) else cyan, radius = centerRadius * .54f, style = Stroke(width = 7.dp.toPx()))
            drawCircle(cyan.copy(alpha = .09f), radius = centerRadius * .54f)
        }
        Text("J", color = cyan, fontSize = 56.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
private fun ChatBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(.94f),
            shape = RoundedCornerShape(13.dp),
            color = if (message.isUser) Color(0xFF183A48) else panel,
            tonalElevation = 2.dp
        ) {
            Column(Modifier.padding(12.dp)) {
                Text(if (message.isUser) "TÚ" else "J.A.R.V.I.S.", color = cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(message.text, fontSize = 14.sp, color = Color(0xFFE3F6FC))
            }
        }
    }
}
