package com.jarvis.openandroid.domain

import com.jarvis.openandroid.network.ConversationGateway
import org.junit.Assert.*
import org.junit.Test

class ConversationGatewayRoleTest {
    @Test fun `GPT OSS compatible usa el rol developer para personalidad`() {
        assertEquals("developer", ConversationGateway.personaRole("compatible", "openai/gpt-oss-20b"))
        assertEquals("developer", ConversationGateway.personaRole("compatible", "openai/gpt-oss-120b"))
    }

    @Test fun `modelos no GPT OSS mantienen rol system por compatibilidad`() {
        assertEquals("system", ConversationGateway.personaRole("compatible", "llama-3.3-70b-versatile"))
        assertEquals("system", ConversationGateway.personaRole("ollama", "openai/gpt-oss-20b"))
    }
}
