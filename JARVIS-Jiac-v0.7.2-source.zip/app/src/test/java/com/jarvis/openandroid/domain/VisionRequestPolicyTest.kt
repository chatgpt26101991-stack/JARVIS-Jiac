package com.jarvis.openandroid.domain

import com.jarvis.openandroid.vision.VisionRequestPolicy
import org.junit.Assert.*
import org.junit.Test

class VisionRequestPolicyTest {
    @Test fun groqEndpointStrict() {
        assertTrue(VisionRequestPolicy.isGroqEndpoint("https://api.groq.com/openai/v1/chat/completions"))
        assertFalse(VisionRequestPolicy.isGroqEndpoint("https://example.com/openai/v1/chat/completions"))
        assertFalse(VisionRequestPolicy.isGroqEndpoint("http://api.groq.com/openai/v1/chat/completions"))
        assertFalse(VisionRequestPolicy.isGroqEndpoint("https://api.groq.com@other.invalid/openai/v1/chat/completions"))
    }

    @Test fun usesCurrentlyDocumentedVisionModel() {
        assertEquals("qwen/qwen3.8-27b", VisionRequestPolicy.MODEL)
    }

    @Test fun distinguishesGroqFailures() {
        assertTrue(VisionRequestPolicy.httpErrorMessage(404, "model_not_found").contains("modelo"))
        assertTrue(VisionRequestPolicy.httpErrorMessage(404, "model_not_found").contains("model_not_found"))
        assertTrue(VisionRequestPolicy.httpErrorMessage(401).contains("clave API"))
        assertTrue(VisionRequestPolicy.httpErrorMessage(429).contains("límite"))
        assertFalse(VisionRequestPolicy.httpErrorMessage(404, "Bearer_secret_token").contains("Bearer_secret_token"))
    }

    @Test fun generalDescriptionDoesNotRequireQuestion() {
        assertNull(VisionRequestPolicy.normalizeQuestion(null))
    }

    @Test fun normalizesPhotoQuestion() {
        assertEquals("¿De qué color es la lata?",
            VisionRequestPolicy.normalizeQuestion("  ¿De qué   color es la lata?  "))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsBlankPhotoQuestion() { VisionRequestPolicy.normalizeQuestion("   ") }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsTooLongPhotoQuestion() {
        VisionRequestPolicy.normalizeQuestion("a".repeat(VisionRequestPolicy.MAX_QUESTION_CHARS + 1))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsControlCharactersInPhotoQuestion() {
        VisionRequestPolicy.normalizeQuestion("Foto\u0000imagen")
    }

    @Test fun acceptsJpegBoundaries() {
        VisionRequestPolicy.validateJpeg(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xD9.toByte()))
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsNonJpeg() { VisionRequestPolicy.validateJpeg(byteArrayOf(1,2,3,4)) }
}
