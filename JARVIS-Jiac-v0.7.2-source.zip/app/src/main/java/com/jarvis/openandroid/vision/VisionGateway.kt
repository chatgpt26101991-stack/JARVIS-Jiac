package com.jarvis.openandroid.vision

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Analiza una única foto solo después de que el usuario pulse "Analizar con Groq".
 * No guarda ni registra en logs la imagen o la credencial.
 */
class VisionGateway {
    suspend fun describe(jpeg: ByteArray, apiKey: String, question: String? = null): String = withContext(Dispatchers.IO) {
        VisionRequestPolicy.validateJpeg(jpeg)
        val specificQuestion = VisionRequestPolicy.normalizeQuestion(question)
        require(apiKey.isNotBlank()) { "Configura primero tu clave API de Groq en Ajustes." }
        val data = "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP)
        val instruction = if (specificQuestion == null) {
            "Describe en español, de forma clara y concisa, los objetos y detalles visibles de esta foto."
        } else {
            "Responde en español a esta pregunta específica sobre la fotografía: $specificQuestion. " +
                "Céntrate en lo que se distingue en la imagen; no te limites a una descripción general."
        }
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", JSONArray()
            .put(JSONObject().put("type", "text").put("text",
                "Eres J.A.R.V.I.S. $instruction " +
                "No inventes personas, identidades ni texto ilegible. Si algo es incierto, dilo. " +
                "No presupongas que puedes ver más allá de esta única fotografía."))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", data)))))
        val body = JSONObject()
            .put("model", VisionRequestPolicy.MODEL)
            .put("stream", false)
            .put("max_completion_tokens", 850)
            .put("messages", messages)
        val connection = URL(VisionRequestPolicy.ENDPOINT).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.instanceFollowRedirects = false
            connection.useCaches = false
            connection.connectTimeout = 15_000
            connection.readTimeout = 60_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("Authorization", "Bearer $apiKey")
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            if (code !in 200..299) {
                val providerCode = try {
                    // Leer solo el código de error estructurado, nunca el cuerpo completo en UI o logs.
                    val payload = connection.errorStream?.bufferedReader(Charsets.UTF_8)
                        ?.use { it.readText().take(4_096) }
                    payload?.let { JSONObject(it).optJSONObject("error")?.optString("code") }
                } catch (_: Exception) { null }
                error(VisionRequestPolicy.httpErrorMessage(code, providerCode))
            }
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            require(response.length <= 150_000) { "La respuesta de visión excedió el tamaño previsto." }
            val choice = JSONObject(response).getJSONArray("choices").getJSONObject(0)
            val answer = choice.getJSONObject("message").optString("content").trim()
            require(answer.isNotBlank()) { "Groq no devolvió una descripción de la imagen." }
            if (choice.optString("finish_reason") == "length")
                answer + "\n[Aviso: la descripción puede estar incompleta.]"
            else answer
        } finally {
            connection.disconnect()
        }
    }
}
