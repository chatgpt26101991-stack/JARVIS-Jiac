# J.A.R.V.I.S. Android 0.3.1 — descarga del detector mejorada

Aplicación Android abierta (Apache-2.0) que mantiene la voz configurada en J.A.R.V.I.S. 0.2 e incorpora un **modo manos libres experimental**. No es una copia de la voz de ningún actor.

## Mejoras de la 0.3.1

- Barra de progreso basada en **bytes realmente recibidos**, indicando porcentaje cuando el servidor informa tamaño total y MB descargados.
- **Reintentos automáticos** ante caídas de conexión (hasta cuatro intentos por pulsación, con espera progresiva).
- **Descargas reanudables** desde almacenamiento privado mediante la cabecera HTTP Range cuando el servidor lo admite; si no la admite, el archivo se reinicia de manera segura.
- Archivo ".part" conservado después de un error de red. Pulsa «Reintentar descarga» para continuar.
- No requiere instalar otra voz. Se conserva la configuración masculina de Android de la v0.2/v0.3.
- Si el modelo ya está instalado, no se vuelve a descargar.

**Importante:** si Android reinstala el APK tras desinstalar una versión anterior, se pierden las preferencias y el modelo parcial. Para conservar datos se necesita que ambas versiones tengan el mismo certificado de firma. Los APK de debug compilados en distintos runners de GitHub pueden estar firmados con claves diferentes.

## Funcionalidad nueva

- **Detector local «Jarvis»** mediante Vosk 0.3.47 y el modelo español pequeño `vosk-model-small-es-0.42` (Apache-2.0). No envía audio a servidores durante la detección.
- **Descarga voluntaria** de un modelo de aproximadamente 39 MB desde su sitio oficial; se descomprime en almacenamiento privado. La inferencia necesita memoria adicional.
- **Servicio de primer plano con micrófono**, iniciado expresamente desde una pantalla visible y acompañado de una notificación continua con la opción **Detener**.
- **Respuesta hablada** utilizando el motor TextToSpeech predeterminado de Android y las preferencias de voz guardadas en la v0.2 (`jarvis_voice_v02`). El modelo de Vosk reconoce órdenes; no sintetiza la voz.
- Prueba inicial de comandos públicos en manos libres: saludo, fecha, hora y capacidades. Para otras órdenes, J.A.R.V.I.S. solicita abrir la app. En particular, no accede a recuerdos privados, no ejecuta órdenes arbitrarias ni envía audio al backend.
- Entrada por texto, botón de voz y servidor Ollama opcional conservados de la v0.2.

## Restricciones IMPORTANTES

- **No es un asistente privilegiado del sistema ni un servicio perpetuo.** Android puede detener el proceso en condiciones de presión de memoria o ahorro de batería. No se inicia automáticamente al encender el móvil.
- Android 14+ requiere iniciar este tipo de servicio con la app visible salvo excepciones concretas. Si ya está en marcha, su continuidad en segundo plano y con pantalla bloqueada depende de la versión de Android, permisos y fabricante.
- Escuchar activamente consume batería y mantiene el micrófono en uso. La notificación facilita apagarlo inmediatamente.
- La detección usa reconocimiento de voz general, no un detector acústico dedicado; puede dar falsos positivos y no detectar pronunciaciones distintas de «Jarvis». Es un prototipo, no garantía de activación ininterrumpida.
- Necesita el permiso `RECORD_AUDIO`; `POST_NOTIFICATIONS` permite mostrar la notificación de forma más clara donde aplica.
- El APK es de **depuración**. No utilices compilaciones de terceros ni concedas permisos a archivos desconocidos.
- Esta entrega fuente necesita compilarse y probarse en el teléfono; no se ha certificado su funcionamiento con pantalla bloqueada.

## Uso en Android

1. Instala la v0.3, idealmente actualizando tu aplicación existente para conservar las preferencias de voz. Si la firma del nuevo APK es diferente, Android puede solicitar desinstalar primero la anterior; esto borra sus datos locales y requiere volver a elegir la voz.
2. Abre la app. En **MODO MANOS LIBRES V0.3** toca **Descargar detector español** y espera a que termine con Wi-Fi.
3. Toca **Activar Jarvis en segundo plano**, concede permisos y verifica la notificación de escucha activa.
4. Con la pantalla encendida, di **«Jarvis, qué hora es»**. Luego prueba con otra aplicación abierta.
5. Para finalizar, utiliza **Detener** desde la notificación (o **Desactivar escucha de Jarvis** en la app).
6. Solo después comprueba el comportamiento con pantalla bloqueada. En esa condición no debe revelar información personal ni ejecutar acciones sensibles.

## Compilar desde el celular con GitHub Actions

Este ZIP se diseñó para utilizarlo junto con el workflow existente de `JARVIS-Jiac`, que descomprime el archivo en una carpeta `source`. En `.github/workflows/build-apk.yml` modifica solo el nombre del ZIP extraído por:

`JARVIS-Jiac-v0.3.1-source.zip`

El workflow de GitHub instalado previamente usa Android SDK 36 y parchea temporalmente dependencias que, en sus versiones originales, necesitan SDK 37. Conserva esos ajustes hasta que migremos el proyecto a un SDK soportado. Comprueba que la ejecución termine **success** antes de instalar el APK desde **Artifacts**.

## Código

- `wake/OfflineModelInstaller.kt` — descarga segura por HTTPS con progreso, reintentos, reanudación HTTP Range, límites de tamaño y protección ante Zip Slip.
- `wake/WakeWordMatcher.kt` — reconocimiento de «Jarvis» en texto, con pruebas unitarias.
- `wake/JarvisListeningService.kt` — servicio controlado de escucha y respuesta pública.
- `MainActivity.kt` — permisos y activación desde la app visible.
- `ui/JarvisScreen.kt` — controles para activar/desactivar el modo manos libres.
- `speech/TtsSpeaker.kt` — la voz configurada previamente por el usuario.

Licencias de terceros: Vosk y el modelo español pequeño, Apache-2.0; los componentes Android y demás dependencias mantienen sus propias licencias.

## Prueba de descarga

1. Con Wi-Fi estable, pulsa «Descargar detector español».
2. Comprueba que aparecen la barra, los MB y el porcentaje (si el servidor informa el tamaño).
3. Si se pierde la conexión, espera los reintentos automáticos; si se agotan pulsa «Reintentar descarga».
4. Al terminar, debe mostrarse «Modelo listo» y el botón para activar Jarvis en segundo plano.
5. Esta entrega aún debe validarse mediante GitHub Actions y pruebas en un teléfono Android; no se garantiza que todas las redes acepten HTTP Range.
