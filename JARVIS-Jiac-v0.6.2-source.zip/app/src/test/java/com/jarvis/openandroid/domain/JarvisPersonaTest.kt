package com.jarvis.openandroid.domain

import org.junit.Assert.*
import org.junit.Test

class JarvisPersonaTest {
    @Test fun `modo equilibrado es predeterminado para valores invalidos`() {
        assertEquals(JarvisPersona.BALANCED, JarvisPersona.normalize(null))
        assertEquals(JarvisPersona.BALANCED, JarvisPersona.normalize("otro"))
        assertEquals(JarvisPersona.PROFESSIONAL, JarvisPersona.normalize("profesional"))
    }

    @Test fun `modo equilibrado incluye sarcasmo elegante pero no constante`() {
        val prompt = JarvisPersona.systemPrompt(JarvisPersona.BALANCED)
        assertTrue(prompt.contains("sarcasmo elegante"))
        assertTrue(prompt.contains("ocasionales"))
        assertTrue(prompt.contains("información útil va primero"))
    }

    @Test fun `situaciones serias prohíben bromas en todos los modos`() {
        listOf(JarvisPersona.PROFESSIONAL, JarvisPersona.BALANCED, JarvisPersona.WITTY).forEach { mode ->
            val prompt = JarvisPersona.systemPrompt(mode)
            assertTrue(prompt.contains("emergencias"))
            assertTrue(prompt.contains("omite absolutamente el sarcasmo y las bromas"))
            assertTrue(prompt.contains("No inventes hechos"))
        }
    }

    @Test fun `modo profesional evita sarcasmo`() {
        assertTrue(JarvisPersona.systemPrompt(JarvisPersona.PROFESSIONAL)
            .contains("sin sarcasmo y casi sin bromas"))
    }
}
