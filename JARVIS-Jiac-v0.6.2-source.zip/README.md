# J.A.R.V.I.S. Android v0.6.2 — Fase 2: memoria y personalidad

**Actualización consolidada de la fase 2 sobre la versión 0.6.0**, que incorpora las funciones de memoria de v0.6.1 y una nueva personalidad configurable. No contiene cambios de la fase 3.

## Personalidad

- Predeterminado: **Equilibrado**, inteligencia, trato refinado y sarcasmo elegante ocasional, inspirado en un asistente de ciencia ficción.
- Opciones en **Ajustes → Inteligencia artificial → Personalidad**: Profesional (sin sarcasmo), Equilibrado y Ingenioso.
- Las instrucciones de todos los modos indican expresamente **no bromear en emergencias, salud, seguridad u otras situaciones delicadas**; una indicación al modelo es una preferencia de comportamiento, no una garantía absoluta del proveedor.
- La personalidad afecta las respuestas del modelo Groq/Ollama, tanto en pantalla como en manos libres. Los comandos locales conservan respuestas objetivas.
- Se conserva la memoria personal de hasta 20 recuerdos, el panel «Mis recuerdos», el historial escrito, la voz masculina, Vosk y la conversación continua.
- **Privacidad:** los recuerdos no se envían a Groq por defecto; el usuario debe activar el interruptor en «Mis recuerdos». Nunca subas claves API ni secretos de firma a GitHub.

## Validación recomendada antes de cerrar fase 2

1. Compilar `testDebugUnitTest` y `assembleDebug` en GitHub Actions utilizando `JARVIS-Jiac-v0.6.2-source.zip`, conservando `JARVIS_DEBUG_KEYSTORE_B64`.
2. Instalar APK sobre v0.6.0, **sin desinstalar**, para conservar Groq, Vosk y el historial.
3. Probar memoria: «Jarvis, recuerda que prefiero respuestas breves», «¿Qué recuerdas?», cerrar/reabrir, borrar un recuerdo y comprobar el control opcional de envío a Groq.
4. Probar personalidad equilibrada con consultas ordinarias y serias; confirmar tono, utilidad y ausencia de bromas inadecuadas. Probar también el modo Profesional.
5. Verificar que la conversación continua, el historial escrito, la voz masculina y la escucha bloqueada siguen funcionando. No avanzar a fase 3 si existen defectos por corregir.

**Estado:** código y pruebas locales preparadas. Es necesario compilar y probar en el teléfono antes de declarar finalizada la fase 2.

---

# J.A.R.V.I.S. Android v0.6.1 — Fase 2: recuerdos personales explícitos

**Actualización incremental sobre v0.6.0, sin eliminar el historial ni cambiar la firma fija.**

## Qué incorpora

- Guarda hasta **20 recuerdos separados**, de hasta 240 caracteres cada uno, con la orden **«Jarvis, recuerda que prefiero respuestas breves»** o desde el panel «Mis recuerdos».
- Responde **«¿Qué recuerdas?»** desde la aplicación o manos libres (cuando el dispositivo está desbloqueado).
- Panel **«Mis recuerdos (N)»** en la cabecera del historial para ver, agregar, eliminar recuerdos individuales o borrar todos mediante confirmación.
- Conserva recuerdos al cerrar/reabrir la aplicación y migra una sola vez la memoria individual de versiones anteriores.
- **No envía los recuerdos a Groq/Ollama por defecto.** Solo si se activa «Usar recuerdos en las respuestas de Groq/Ollama» desde «Mis recuerdos», los incluye como contexto con las consultas externas; nunca los incluye desde el modo manos libres cuando el dispositivo está bloqueado.
- La orden de voz «borra todos mis recuerdos» **no borra sin confirmación**: indica cómo abrir el panel para confirmar. Así se reducen pérdidas por reconocimientos falsos.
- El historial visible, el contexto breve, los recuerdos personales y la API Key de Groq son almacenamientos diferentes. Borrar el historial **no borra** recuerdos; borrar recuerdos **no borra** transcripciones del historial ni los datos recibidos previamente por proveedores externos.
- Conserva Groq, voz masculina TTS, Vosk, la conversación continua de 15 segundos y el tratamiento de Markdown.

**Privacidad:** los recuerdos se almacenan en las preferencias privadas de Android, sin cifrado adicional. No guardes contraseñas, claves API, datos bancarios u otra información sensible. No se sincronizan entre dispositivos.

## Pasos de compilación desde Android

1. Sube `JARVIS-Jiac-v0.6.1-source.zip` al repositorio GitHub público.
2. En `.github/workflows/build-apk.yml` del repositorio, cambia **solamente** la línea `unzip -q` para utilizar `JARVIS-Jiac-v0.6.1-source.zip` y el nombre de artefacto a `JARVIS-Jiac-v0.6.1-debug-APK`.
3. Mantén el secreto `JARVIS_DEBUG_KEYSTORE_B64` y toda la sección de firma fija sin cambios. Nunca publiques la clave privada o tu API Key.
4. Verifica que GitHub Actions complete `testDebugUnitTest` y `assembleDebug` con éxito; instala el APK **sobre v0.6.0, sin desinstalar**.
5. Prueba «Jarvis, recuerda que prefiero respuestas breves», «¿Qué recuerdas?», cierre y reapertura, borrado individual y uso opt-in de recuerdos en Groq.

**Estado de validación:** comprobaciones locales de comandos y reglas de memoria superadas. Falta compilar y verificar el APK Android mediante GitHub Actions y probar la funcionalidad en el teléfono.

---

# J.A.R.V.I.S. Android v0.6.0 — Fase 2 (entrega 1): historial escrito local

**Actualización incremental desde v0.5.1.** Esta primera entrega de la fase 2 hace visible el historial de preguntas y respuestas; la memoria personal de preferencias y la personalidad configurable se desarrollarán en pasos siguientes.

## Mejoras

- Guarda preguntas y respuestas de la pantalla principal, reconocimiento de voz desde la aplicación y servicio manos libres (incluidas preguntas de seguimiento y comandos locales).
- Muestra **texto completo de la respuesta almacenada**, separado del resumen hablado por TTS, y fecha/hora cuando se dispone de ella.
- El historial es local y se restaura al cerrar y volver a abrir la aplicación; también se actualiza al regresar desde segundo plano.
- Migra en el primer inicio las últimas entradas disponibles del contexto remoto v0.5.1. Las consultas locales o manos libres antiguas que no se almacenaban antes **no pueden recuperarse**.
- Historial limitado a las **últimas 100 parejas**; cada pregunta se limita a 1.500 caracteres y cada respuesta a 4.000 caracteres para contener el consumo de almacenamiento.
- El panel manos libres tiene sección «Opciones» plegable para que el historial no quede oculto en pantallas pequeñas.
- «Borrar historial» solicita confirmación y elimina también el contexto de conversación local de Groq; **no elimina datos ya recibidos por servicios externos**.
- Conserva la firma fija, clave Groq en Android Keystore, Vosk, conversación continua y voz masculina. No modifica los permisos ni sincroniza el historial con otros dispositivos.

**Privacidad:** el historial está almacenado en las preferencias privadas de la aplicación (sandbox Android), pero **no cuenta con cifrado adicional**. Evita dictar contraseñas u otros datos sensibles si no deseas conservarlos. La memoria de contexto enviada a Groq sigue siendo independiente y limitada a unos pocos turnos.

## Instalación desde el celular

1. Sube `JARVIS-Jiac-v0.6.0-source.zip` a la rama `main` del repositorio público.
2. Edita **solo** la línea de `unzip -q` en `.github/workflows/build-apk.yml` para leer el ZIP 0.6.0 y renombra el artefacto a `JARVIS-Jiac-v0.6.0-debug-APK`.
3. **No edites el paso que restaura `JARVIS_DEBUG_KEYSTORE_B64` ni publiques el secreto.**
4. Espera GitHub Actions, verifica pruebas y compilación; descarga el artefacto e instala el APK encima de v0.5.1, sin desinstalar.
5. Con Groq y Vosk activos, pregunta «Jarvis, háblame de Júpiter» desde segundo plano; abre la aplicación y busca las dos burbujas («TÚ», «J.A.R.V.I.S.»). Cierra/abre la app para comprobar la persistencia.
6. Prueba el modo escrito, el diálogo de borrado y que la clave de Groq se conserve.

**Estado:** las pruebas locales de la política del historial pasaron; la compilación de Android en GitHub y las pruebas en el teléfono siguen pendientes.

---

# J.A.R.V.I.S. Android v0.5.1 — voz natural sin símbolos Markdown

**Actualización incremental sobre 0.5.0.** Se corrige que el motor TTS pronuncie literalmente marcas como `**Júpiter**`. El texto íntegro de la respuesta, el historial conversacional y el contexto de Groq/Ollama no se modifican: se aplica el procesamiento únicamente en `SpokenResponse.concise(...)`, usado por el TTS de la pantalla y del modo manos libres.

- Quita asteriscos y guiones bajos de énfasis Markdown cuando están bien delimitados, marcas de título, viñetas, enlaces Markdown y delimitadores de código.
- Conserva operadores matemáticos como `2 * 3`, `2 ** 3`, `10 × 2`, identificadores con `_` y signos de puntuación.
- Incluye pruebas unitarias de formato y regresión de duración de voz.
- Mantiene la conversación continua, cierre por inactividad, voz masculina, motor Vosk y clave Groq guardada en el teléfono.
- Mantiene el mismo identificador de paquete y el esquema de firma fija del repositorio GitHub.

## Compilar desde el celular

1. Sube `JARVIS-Jiac-v0.5.1-source.zip` al repositorio GitHub en `main`.
2. Edita **solo** la línea de descompresión en el workflow raíz `.github/workflows/build-apk.yml`: cambia el ZIP a `JARVIS-Jiac-v0.5.1-source.zip`.
3. Cambia el nombre del artefacto a `JARVIS-Jiac-v0.5.1-debug-APK` si quieres distinguirlo.
4. Conserva intacta la firma fija `JARVIS_DEBUG_KEYSTORE_B64` de GitHub Actions.
5. Espera a que pasen las pruebas y la compilación; descarga el APK e instálalo sobre v0.5.0 **sin desinstalar**.
6. Di «Jarvis, háblame de Júpiter» y verifica que no pronuncie «asterisco»; repite con un mensaje que contenga multiplicaciones.

**Estado:** comprobación local de Kotlin y pruebas de formato preparadas. La compilación Android y la prueba en el dispositivo están pendientes; no se incluyen claves privadas ni de API en este ZIP.

---

# J.A.R.V.I.S. Android v0.5.0 — conversación continua opcional

**Fase 1: conversación natural y estabilidad (entrega incremental).** Código abierto Apache-2.0.

## Nuevo en v0.5.0

- **Modo conversación continua opcional** desde la sección «Modo manos libres»; viene desactivado por defecto y se recuerda en el dispositivo.
- Tras decir «Jarvis, [pregunta]», el asistente puede aceptar preguntas de seguimiento **sin repetir «Jarvis»** durante los 15 segundos posteriores a cada respuesta de voz.
- Hasta **cuatro preguntas de seguimiento** por activación para reducir el riesgo de aceptar conversaciones ajenas. Después hay que volver a decir «Jarvis».
- Si dices «Jarvis» solo, contesta «A sus órdenes» y espera 12 segundos la primera consulta. Luego, si está activada la conversación continua, permite seguimientos.
- «Terminar conversación» o «Jarvis, descansa» cierran la ventana de seguimiento sin detener permanentemente el detector.
- Cuando termina la ventana, vuelve a escuchar solo la palabra de activación. Se conserva la pausa antieco de 1,2 segundos tras cada respuesta TTS.
- Se respeta el bloqueo: la IA sigue prohibida con el móvil bloqueado salvo que el usuario active explícitamente esa opción en Ajustes.
- Conserva Groq/Ollama, memoria de contexto, voz personalizada, Vosk, hora local y los datos cifrados de la versión anterior.

**Limitaciones:** el asistente no puede escuchar interrupciones de voz mientras está hablando (barge-in); por ahora se usa «Detener voz» desde la app o «Silenciar voz» desde la notificación. La ventana escucha audio ambiente para detectar el siguiente comando y puede reconocer una voz distinta a la del propietario: actívala únicamente donde sea apropiado. Android puede restringir el micrófono con pantalla apagada. Esta entrega debe compilarse y probarse en un teléfono real antes de considerarse estable.

## Instalación y pruebas (sin computadora)

1. Sube `JARVIS-Jiac-v0.5.0-source.zip` al repositorio GitHub en la rama `main`.
2. En `.github/workflows/build-apk.yml` cambia únicamente el nombre del ZIP usado por `unzip -q` a `JARVIS-Jiac-v0.5.0-source.zip`. Mantén la **firma fija ya configurada** (`JARVIS_DEBUG_KEYSTORE_B64`): no pongas la clave en el código ni la compartas.
3. Comprueba en GitHub Actions que pasen las pruebas, la compilación y la etapa de firma, y descarga el artefacto `app-debug.apk`.
4. Instala sobre la versión 0.4.2 **sin desinstalar**. Conserva la clave de Groq del teléfono si el identificador y la firma del APK no cambian.
5. Abre J.A.R.V.I.S.; en «Modo manos libres» activa «Conversación continua (15 segundos)», activa el detector y prueba «Jarvis, ¿qué es Marte?»; tras su respuesta, pregunta «¿Cuánto tarda en dar una vuelta al Sol?» sin decir Jarvis.
6. Verifica que el seguimiento funcione y que, después de 15 segundos de silencio, solo reaccione a una nueva activación «Jarvis». Prueba también «Terminar conversación».

---

## Corrección puntual v0.4.2: hora y fecha fiables

- Detecta variantes habituales de la pregunta horaria (por ejemplo «¿Qué hora es?», «Jarvis, dime la hora», «¿Me puedes decir qué hora es?») y consulta el reloj del propio Android **sin enviar la pregunta a Groq**.
- La misma regla se aplica tanto a la pantalla principal como al modo manos libres y con la pantalla bloqueada, sin solicitar permiso adicional.
- Evita tratar como hora local preguntas diferentes («¿A qué hora empieza la película?», «¿Qué hora es en Tokio?»).
- Incluye nuevas pruebas unitarias, con reloj fijo para validar hora y zona horaria.
- Mantiene el proveedor Groq, la clave del dispositivo, la voz masculina y el detector Vosk sin modificaciones.
- La escucha con pantalla bloqueada se validó satisfactoriamente en una prueba del usuario a 1, 3 y 5 minutos; no equivale a una garantía de funcionamiento indefinido.

## Mejoras de estabilidad v0.4.1

- Se suspende el detector Vosk durante respuestas de voz tanto de la pantalla principal como del servicio manos libres; se espera **1,2 segundos** tras terminar el TTS antes de reanudar la captura para reducir la realimentación acústica.
- El usuario puede **Detener voz** desde la app y **Silenciar voz** desde la notificación de escucha; el servicio puede seguir activado.
- Las respuestas por voz se acortan a aproximadamente 500 caracteres, con invitación a ampliar la explicación; el texto íntegro de IA permanece visible en la pantalla y en su historial local.
- Las respuestas TTS usan identificadores únicos para no reactivar el micrófono por una finalización antigua. Se registran los errores de Vosk sin imprimir conversaciones ni secretos.
- Se agregaron pruebas unitarias para el tiempo de silencio tras hablar y el acortamiento de respuestas.
- Corrección preventiva: hace falta **validar el comportamiento en un Android real**; esta entrega todavía no certifica la estabilidad con pantalla apagada.
 Evolución directa del proyecto 0.3.1: conserva la voz masculina seleccionada, la interfaz futurista y el detector Vosk; añade conversación con un modelo de IA opcional y contexto breve.

## ¿Qué puede hacer?

- Responder preguntas abiertas (explicaciones, recetas, ideas, programación, conversación) **cuando configures un modelo externo**. No hay IA generativa integrada sin configurar el proveedor.
- Escuchar órdenes tras la palabra **«Jarvis»**, tanto con la app abierta como con el servicio activado en segundo plano. La disponibilidad con la pantalla apagada sigue dependiendo de Android/fabricante.
- Hablar con el motor TTS y la **voz masculina** previamente seleccionada. No altera esos ajustes.
- Conservar localmente hasta seis intercambios anteriores como contexto y permitir **Borrar conversación local**.
- Mantener las funciones sin nube: hora, fecha, saludo, abrir ajustes (desde la pantalla activa), memoria local y detección Vosk.
- Conectarse por HTTPS a **Ollama** (`/api/chat`) o una **API compatible con OpenAI** (`/chat/completions`) como Groq u OpenRouter.
- Guardar la API key **cifrada en Android Keystore** y eliminarla desde Ajustes. No incluye credenciales en el APK ni en GitHub.
- Por defecto, **no consulta IA externa con el celular bloqueado**. La opción de permitirlo requiere activación explícita y puede exponer respuestas audibles o texto de preguntas al proveedor.

## Configura una IA conversacional usando solo el celular

1. Instala el APK 0.4 compilado desde **tu repositorio** y abre J.A.R.V.I.S.
2. Toca el engranaje ⚙️ en la parte superior y selecciona **API compatible (Groq, OpenRouter…)**.
3. Puedes registrarte en [GroqCloud](https://console.groq.com/keys) y crear tu **propia clave API**. Nunca la compartas en un chat ni la subas a GitHub.
4. Revisa los costos, cuotas y condiciones del proveedor antes de usarlo. Tener código abierto no hace gratuitas las llamadas a servicios de terceros.
5. Comprueba estos valores:
   - URL: `https://api.groq.com/openai/v1/chat/completions`
   - Modelo: `openai/gpt-oss-20b` (modelo que el proveedor documenta actualmente, sujeto a cambios)
   - Clave API: la creada por ti, introducida **solamente dentro de la app**.
6. Deja desactivado «Permitir respuestas de IA con pantalla bloqueada» inicialmente. Pulsa **Guardar**.
7. Prueba por texto: «Explícame cómo se produce un eclipse»; luego «Resúmelo en dos frases» para comprobar el contexto.
8. Para la prueba de voz di «Jarvis, explícale a alguien de 10 años qué es la inteligencia artificial». La consulta se enviará **como texto reconocido**, no como audio, al proveedor elegido.
9. Si deseas permitir respuestas cuando esté bloqueado, actívalo expresamente y comprende sus riesgos de privacidad. Comienza probando con la pantalla encendida.

Alternativa: selecciona **Servidor Ollama privado** con un endpoint HTTPS de `/api/chat` que tú controles. No publiques un Ollama sin autenticación en Internet.

## Seguridad y límites

- No promete entender literalmente todas las frases: la exactitud depende de Vosk, de la pronunciación, la calidad del micrófono y el modelo conectado.
- No realiza acciones arbitrarias como enviar WhatsApps, compras, movimientos bancarios o saltar bloqueos; esas acciones necesitan integraciones y confirmaciones adicionales.
- Los mensajes que no sean comandos locales se envían al proveedor elegido cuando la IA esté activada. El texto del diálogo se conserva localmente en las preferencias privadas de la app y se comparte como contexto con ese proveedor (máximo seis pares anteriores). Se puede borrar desde la interfaz.
- La versión 0.3.1 tenía reconocimiento **intermitente con pantalla bloqueada**. Esta entrega añade inteligencia conversacional, pero **no certifica la corrección de esa incidencia**; mantiene pendiente el diagnóstico de batería y micrófono.
- El motor de voz puede requerir conexión dependiendo del servicio TTS elegido. Vosk continúa funcionando localmente.
- La clave API está cifrada usando Android Keystore, pero una app maliciosa en un teléfono comprometido podría leer mensajes en pantalla. Evita poner secretos en preguntas.
- Si el APK tiene una firma de depuración distinta, Android puede rechazar la instalación sobre la versión existente; desinstalar puede borrar el modelo Vosk descargado, el historial y la selección local de voz.

## Compilación desde GitHub Actions (sin PC)

1. Sube `JARVIS-Jiac-v0.4.2-source.zip` al repositorio `JARVIS-Jiac` con **Add file → Upload files**.
2. En el workflow **raíz del repositorio** `.github/workflows/build-apk.yml`, cambia **solo** el ZIP de la línea `unzip -q ...` por `JARVIS-Jiac-v0.4.2-source.zip`. No cambies los ajustes de SDK 36 que ya funcionaron en la 0.3.1.
3. Opcional: cambia `name:` dentro de `uses: actions/upload-artifact@v4` por `JARVIS-Jiac-v0.4.2-debug-APK` para distinguir los entregables.
4. Pulsa **Commit changes**. Revisa **Actions** y comprueba `success`, pruebas y APK generado antes de instalar.
5. Descarga el artefacto ZIP en Actions y extrae `app-debug.apk`. Nunca instales un archivo que no provenga de tu compilación.

Este ZIP incluye el código del proyecto y sus pruebas, pero **NO es un APK**. La compilación Android y las pruebas de uso deben verificarse en GitHub Actions y el teléfono.

## Archivos principales

- `data/JarvisPreferences.kt`: preferencias del proveedor, privacidad en bloqueo.
- `data/SecureApiKeyStore.kt`: cifrado de credenciales con Keystore.
- `data/ConversationMemory.kt`: contexto conversacional corto borrable.
- `network/ConversationGateway.kt`: llamadas a Ollama o API compatible a través de HTTPS.
- `wake/JarvisListeningService.kt`: conexión del detector Vosk a las respuestas por IA y TTS.
- `domain/LocalRouting.kt`: evita que preguntas generales se confundan con órdenes locales.
- `ui/JarvisViewModel.kt`, `ui/JarvisScreen.kt`: interfaz de configuración y chat.

Licencia del proyecto: Apache-2.0. Los motores y modelos de terceros conservan sus propias licencias.
