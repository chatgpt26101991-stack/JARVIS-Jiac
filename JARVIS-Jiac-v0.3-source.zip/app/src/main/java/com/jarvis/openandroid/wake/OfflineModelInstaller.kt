package com.jarvis.openandroid.wake

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.util.zip.ZipInputStream

/** Modelo Apache-2.0 (proveedor: Alpha Cephei). Sin descarga automática. */
object OfflineModelInstaller {
    private const val MODEL_NAME = "vosk-model-small-es-0.42"
    private const val ZIP_URL = "https://alphacephei.com/vosk/models/$MODEL_NAME.zip"
    private const val MAX_DOWNLOAD = 85L * 1024L * 1024L
    private const val MAX_UNPACKED = 350L * 1024L * 1024L

    fun modelPath(context: Context): File = File(context.filesDir, "offline_models/$MODEL_NAME")
    fun isInstalled(context: Context): Boolean =
        File(modelPath(context), "am/final.mdl").isFile &&
        File(modelPath(context), "conf/mfcc.conf").isFile

    suspend fun install(context: Context, status: (String) -> Unit) = withContext(Dispatchers.IO) {
        if (isInstalled(context)) return@withContext
        val home = File(context.filesDir, "offline_models").apply { mkdirs() }
        val zip = File(home, "download.tmp")
        val stage = File(home, "stage")
        stage.deleteRecursively()
        stage.mkdirs()
        try {
            status("Descargando modelo español (~39 MB)…")
            val connection = URL(ZIP_URL).openConnection()
            connection.connectTimeout = 20_000
            connection.readTimeout = 45_000
            val advertised = connection.contentLengthLong
            require(advertised == -1L || advertised <= MAX_DOWNLOAD) { "Descarga demasiado grande" }
            var downloaded = 0L
            connection.getInputStream().use { input ->
                FileOutputStream(zip).use { output ->
                    val bytes = ByteArray(8192)
                    while (true) {
                        val length = input.read(bytes)
                        if (length < 0) break
                        downloaded += length
                        require(downloaded <= MAX_DOWNLOAD) { "Descarga excede el límite permitido" }
                        output.write(bytes, 0, length)
                    }
                }
            }
            status("Descomprimiendo modelo…")
            var uncompressed = 0L
            var files = 0
            val prefix = stage.canonicalPath + File.separator
            ZipInputStream(zip.inputStream().buffered()).use { stream ->
                while (true) {
                    val entry = stream.nextEntry ?: break
                    files++
                    require(files <= 1500) { "Demasiados archivos en el modelo" }
                    val target = File(stage, entry.name)
                    require(target.canonicalPath.startsWith(prefix)) { "Ruta no permitida en el ZIP" }
                    if (entry.isDirectory) {
                        target.mkdirs()
                    } else {
                        target.parentFile?.mkdirs()
                        target.outputStream().use { output ->
                            val buffer = ByteArray(8192)
                            while (true) {
                                val count = stream.read(buffer)
                                if (count < 0) break
                                uncompressed += count
                                require(uncompressed <= MAX_UNPACKED) { "Modelo demasiado grande" }
                                output.write(buffer, 0, count)
                            }
                        }
                    }
                    stream.closeEntry()
                }
            }
            val extracted = File(stage, MODEL_NAME)
            require(File(extracted, "am/final.mdl").isFile && File(extracted, "conf/mfcc.conf").isFile) {
                "El archivo no contiene un modelo Vosk español válido"
            }
            val final = modelPath(context)
            final.deleteRecursively()
            require(extracted.renameTo(final)) { "No pude mover el modelo a su ubicación definitiva" }
            status("Modelo local instalado. Ya puedes activar Jarvis.")
        } finally {
            zip.delete()
            stage.deleteRecursively()
        }
    }
}
