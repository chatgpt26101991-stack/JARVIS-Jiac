package com.jarvis.openandroid.wake

import android.Manifest
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import com.jarvis.openandroid.MainActivity
import com.jarvis.openandroid.domain.LocalCommandEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.util.Locale

/**
 * Servicio EXPLÍCITO iniciado desde la Activity visible.
 * No inicia con BOOT_COMPLETED, no intenta eludir el bloqueo de pantalla
 * ni abre otras aplicaciones desde segundo plano.
 */
class JarvisListeningService : Service(), RecognitionListener {
    companion object {
        const val ACTION_START = "com.jarvis.openandroid.wake.START"
        const val ACTION_STOP = "com.jarvis.openandroid.wake.STOP"
        private const val CHANNEL = "jarvis_active_listening"
        private const val NOTIFICATION_ID = 2203
        val isRunning = MutableStateFlow(false)
        val status = MutableStateFlow("Escucha desactivada")
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var speechService: SpeechService? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var awaitingCommandUntil = 0L
    private var workInProgress = false
    private val commandEngine = LocalCommandEngine()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(applicationContext) { code ->
            if (code == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setLanguage(Locale.forLanguageTag("es-MX"))
                val prefs = getSharedPreferences("jarvis_voice_v02", MODE_PRIVATE)
                val chosen = prefs.getString("voice_id", "").orEmpty()
                tts?.voices?.firstOrNull { it.name == chosen && it.locale.language == "es" }
                    ?.let { tts?.voice = it }
                tts?.setPitch(prefs.getFloat("pitch", 0.85f))
                tts?.setSpeechRate(prefs.getFloat("rate", 0.93f))
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) = resumeListening()
                    @Deprecated("Legacy callback")
                    override fun onError(utteranceId: String?) = resumeListening()
                })
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (isRunning.value) return START_NOT_STICKY
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
            !OfflineModelInstaller.isInstalled(this)) {
            status.value = "Faltan permiso de micrófono o modelo local"
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (error: Exception) {
            status.value = "No se pudo iniciar servicio: ${error.message.orEmpty()}"
            stopSelf()
            return START_NOT_STICKY
        }
        isRunning.value = true
        status.value = "Cargando detector de voz local…"
        scope.launch {
            try {
                val nativeModel = withContext(Dispatchers.IO) { Model(OfflineModelInstaller.modelPath(this@JarvisListeningService).absolutePath) }
                if (!isRunning.value) { nativeModel.close(); return@launch }
                model = nativeModel
                recognizer = Recognizer(nativeModel, 16000.0f)
                speechService = SpeechService(requireNotNull(recognizer), 16000.0f)
                speechService?.startListening(this@JarvisListeningService)
                status.value = "Escuchando «Jarvis» (sin enviar audio a internet)"
            } catch (error: Exception) {
                status.value = "Error iniciando Vosk: ${error.message ?: "desconocido"}"
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val showApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, JarvisListeningService::class.java).setAction(ACTION_STOP)
        val stop = PendingIntent.getService(
            this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("J.A.R.V.I.S. · escucha activa")
            .setContentText("Detectando la palabra Jarvis en este dispositivo")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(showApp)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Detener", stop).build())
            .build()
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL, "Escucha J.A.R.V.I.S.", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Escucha local iniciada por el usuario; se puede detener desde la notificación"
            }
        )
    }

    override fun onPartialResult(hypothesis: String?) = Unit // Evita disparar con hipótesis incompletas.
    override fun onResult(hypothesis: String?) = processHypothesis(hypothesis)
    override fun onFinalResult(hypothesis: String?) = Unit
    override fun onTimeout() = Unit
    override fun onError(exception: Exception?) {
        status.value = "El micrófono se detuvo: ${exception?.message ?: "error"}"
        stopSelf()
    }

    private fun processHypothesis(json: String?) {
        if (!isRunning.value || speaking || workInProgress || json.isNullOrBlank()) return
        val spoken = try { JSONObject(json).optString("text").trim() } catch (_: Exception) { "" }
        if (spoken.isBlank()) return
        val afterWake = WakeWordMatcher.commandAfterWakeWord(spoken)
        when {
            afterWake != null -> {
                if (afterWake.isNotBlank()) {
                    awaitingCommandUntil = 0L
                    handleCommand(afterWake)
                } else {
                    awaitingCommandUntil = SystemClock.elapsedRealtime() + 12_000L
                    say("A sus órdenes.")
                }
            }
            SystemClock.elapsedRealtime() < awaitingCommandUntil -> {
                awaitingCommandUntil = 0L
                handleCommand(spoken)
            }
        }
    }

    private fun handleCommand(phrase: String) {
        workInProgress = true
        scope.launch {
            try {
                val cleaned = phrase.lowercase(Locale.forLanguageTag("es-PE"))
                val keyguard = getSystemService(KeyguardManager::class.java)
                // Esta prueba inicial permite solo comandos públicos; no lee recuerdos,
                // no efectúa solicitudes remotas ni abre pantallas estando bloqueado.
                val safeQuery = listOf("hora", "fecha", "dia", "día", "hola", "puedes hacer").any { cleaned.contains(it) }
                val answer = if (!safeQuery) {
                    "Para esa operación, abre J.A.R.V.I.S. en el teléfono."
                } else {
                    commandEngine.answer(phrase, "")?.text
                        ?: "Todavía no reconozco esa orden en modo manos libres."
                }
                // Protección adicional: nunca anunciar información personal tras el bloqueo.
                val output = if (keyguard.isDeviceLocked && !safeQuery) {
                    "Desbloquea el teléfono y abre J.A.R.V.I.S. para continuar."
                } else answer
                say(output)
            } finally {
                workInProgress = false
            }
        }
    }

    private fun say(message: String) {
        speechService?.setPause(true)
        speechService?.reset()
        speaking = true
        if (!ttsReady || tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis-background") != TextToSpeech.SUCCESS) {
            resumeListening()
        }
    }

    private fun resumeListening() {
        android.os.Handler(mainLooper).post {
            speaking = false
            if (isRunning.value) {
                speechService?.reset()
                speechService?.setPause(false)
            }
        }
    }

    override fun onDestroy() {
        isRunning.value = false
        status.value = "Escucha desactivada"
        scope.cancel()
        try { speechService?.cancel() } catch (_: Exception) { }
        try { speechService?.shutdown() } catch (_: Exception) { }
        try { recognizer?.close() } catch (_: Exception) { }
        try { model?.close() } catch (_: Exception) { }
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
