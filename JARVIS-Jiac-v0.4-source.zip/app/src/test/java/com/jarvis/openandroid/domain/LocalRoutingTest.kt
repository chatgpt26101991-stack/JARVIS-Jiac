package com.jarvis.openandroid.domain

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalRoutingTest {
    @Test fun localActionsStayLocal() {
        assertTrue(LocalRouting.isLocal("Abre ajustes"))
        assertTrue(LocalRouting.isLocal("Jarvis, ¿Qué hora es?"))
        assertTrue(LocalRouting.isLocal("Recuerda que mañana salgo"))
    }

    @Test fun openConversationGoesToModel() {
        assertFalse(LocalRouting.isLocal("Explícame cómo funciona un Data Warehouse"))
        assertFalse(LocalRouting.isLocal("¿A qué hora empieza la película?"))
        assertFalse(LocalRouting.isLocal("Hazme un cuento sobre la luna"))
    }

    @Test fun lockedPhoneOnlyPublicLocalIntents() {
        assertTrue(LocalRouting.isPublicWhenLocked("qué hora es"))
        assertFalse(LocalRouting.isPublicWhenLocked("Qué recuerdas"))
    }
}
