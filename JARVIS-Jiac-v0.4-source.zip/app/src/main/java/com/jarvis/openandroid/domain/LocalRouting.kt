package com.jarvis.openandroid.domain

import java.util.Locale

/** Solo comandos inequívocos son locales cuando hay IA externa configurada. */
object LocalRouting {
    fun isLocal(phrase: String): Boolean {
        val normalized = phrase.trim().lowercase(Locale.forLanguageTag("es-PE"))
            .removePrefix("jarvis, ").removePrefix("jarvis ")
            .trim().trimStart('¿', '¡', ' ').trimEnd('?', '.', '!')
        return normalized.startsWith("recuerda que ") ||
            normalized in setOf("hola", "buenas", "qué hora es", "que hora es", "hora",
                "qué fecha es", "que fecha es", "fecha", "qué día es", "que dia es",
                "abre ajustes", "abrir ajustes", "abre configuración", "abre configuracion",
                "qué recuerdas", "que recuerdas", "borra el recuerdo", "olvida lo que recordaste")
    }

    fun isPublicWhenLocked(phrase: String): Boolean {
        val normalized = phrase.trim().lowercase(Locale.forLanguageTag("es-PE"))
            .trimStart('¿', '¡', ' ').trimEnd('?', '.', '!')
        return normalized in setOf("hora", "qué hora es", "que hora es", "fecha", "qué fecha es",
            "que fecha es", "qué día es", "que dia es", "hola", "buenas")
    }
}
