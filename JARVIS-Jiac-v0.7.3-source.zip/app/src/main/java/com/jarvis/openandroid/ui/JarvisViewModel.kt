package com.jarvis.openandroid.ui

import android.app.Application
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.openandroid.data.ConversationMemory
import com.jarvis.openandroid.data.ConversationHistory
import com.jarvis.openandroid.data.JarvisPreferences
import com.jarvis.openandroid.data.JarvisSettings
import com.jarvis.openandroid.data.PersonalMemoryCommands
import com.jarvis.openandroid.data.PersonalMemoryStore
import com.jarvis.openandroid.data.SecureApiKeyStore
import com.jarvis.openandroid.domain.AssistantAction
import com.jarvis.openandroid.domain.LocalCommandEngine
import com.jarvis.openandroid.domain.LocalRouting
import com.jarvis.openandroid.network.ConversationGateway
import com.jarvis.openandroid.vision.VisionGateway
import com.jarvis.openandroid.vision.VisionRequestPolicy
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatMessage(val text: String, val isUser: Boolean, val timestamp: Long = 0L, val origin: String = "")

data class JarvisUiState(
    val messages: List<ChatMessage> = listOf(ChatMessage("Sistemas iniciados. Di «Jarvis» para comenzar.", false)),
    val settings: JarvisSettings = JarvisSettings(),
    val personalMemories: List<String> = emptyList(),
    val busy: Boolean = false,
    val listening: Boolean = false
)

class JarvisViewModel(application: Application) : AndroidViewModel(application) {
    private val preferences = JarvisPreferences(application.applicationContext)
    private val local = LocalCommandEngine()
    private val remote = ConversationGateway()
    private val vision = VisionGateway()
    private val _photoPreview = MutableStateFlow<ByteArray?>(null)
    val photoPreview = _photoPreview.asStateFlow()
    private val conversation = ConversationMemory(application.applicationContext)
    private val history = ConversationHistory(application.applicationContext)
    private val personalMemories = PersonalMemoryStore(application.applicationContext)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val historyListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == ConversationHistory.KEY_ENTRIES) mainHandler.post { refreshHistory() }
    }
    private val memoryListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == PersonalMemoryStore.KEY_ITEMS) mainHandler.post { refreshPersonalMemories() }
    }
    private val tokenStore = SecureApiKeyStore(application.applicationContext)
    private val restored = history.read().map { ChatMessage(it.content, it.role == "user", it.timestamp, it.origin) }
    private val state = MutableStateFlow(JarvisUiState(
        messages = if (restored.isEmpty()) JarvisUiState().messages else restored,
        personalMemories = personalMemories.read()))
    val uiState = state.asStateFlow()

    private val _speech = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val speech = _speech.asSharedFlow()
    private val _actions = MutableSharedFlow<AssistantAction>(extraBufferCapacity = 2)
    val actions = _actions.asSharedFlow()

    init {
        history.registerListener(historyListener)
        personalMemories.registerListener(memoryListener)
        viewModelScope.launch {
            preferences.settings.collect { updated ->
                personalMemories.migrateLegacy(updated.memory)
                state.update { it.copy(settings = updated, personalMemories = personalMemories.read()) }
            }
        }
    }

    /** Actualiza la pantalla también cuando el servicio manos libres escribió el historial. */
    fun refreshHistory() {
        val stored = history.read().map { ChatMessage(it.content, it.role == "user", it.timestamp, it.origin) }
        state.update { current ->
            current.copy(messages = if (stored.isEmpty()) JarvisUiState().messages else stored)
        }
    }

    fun refreshPersonalMemories() {
        state.update { it.copy(personalMemories = personalMemories.read()) }
    }

    override fun onCleared() {
        personalMemories.unregisterListener(memoryListener)
        history.unregisterListener(historyListener)
        super.onCleared()
    }

    fun setSharePersonalMemories(enabled: Boolean) {
        viewModelScope.launch { preferences.saveSharePersonalMemories(enabled) }
    }

    fun savePersonalMemory(rawText: String) {
        if (rawText.isBlank()) return
        personalMemories.add(rawText)
        refreshPersonalMemories()
    }

    fun removePersonalMemory(index: Int) {
        personalMemories.remove(index)
        refreshPersonalMemories()
    }

    fun clearPersonalMemories() {
        personalMemories.clear()
        refreshPersonalMemories()
    }

    fun setContinuousVoice(enabled: Boolean) {
        viewModelScope.launch { preferences.saveContinuousVoice(enabled) }
    }

    /** Fotografía efímera: no se incluye en las preferencias ni en el historial. */
    fun setPhotoPreview(jpeg: ByteArray) {
        _photoPreview.value = jpeg
    }

    fun discardPhoto() { _photoPreview.value = null }

    fun analyzePhoto(question: String? = null) {
        val jpeg = _photoPreview.value ?: return
        if (state.value.busy) return
        val normalizedQuestion = try {
            VisionRequestPolicy.normalizeQuestion(question)
        } catch (error: IllegalArgumentException) {
            addJarvisAnswer(error.message ?: "La pregunta no es válida.")
            return
        }
        val settings = state.value.settings
        if (settings.provider != "compatible" ||
            !VisionRequestPolicy.isGroqEndpoint(settings.endpoint)) {
            addJarvisAnswer("Para analizar fotografías, primero configura Groq en Ajustes de IA. " +
                "La cámara es local y no ha enviado la foto.")
            return
        }
        if (tokenStore.read().isBlank()) {
            addJarvisAnswer("Configura tu clave Groq antes de enviar una fotografía.")
            return
        }
        val prompt = normalizedQuestion ?: "¿Qué se observa en la fotografía que acabo de tomar?"
        state.update { it.copy(busy = true, messages = it.messages + ChatMessage(prompt, true)) }
        viewModelScope.launch {
            try {
                val answer = vision.describe(jpeg, tokenStore.read(), normalizedQuestion)
                history.addPair(prompt, answer, "cámara")
                // Incorporar únicamente texto al contexto breve; jamás guardar el JPEG.
                conversation.addPair("Sobre la fotografía analizada: $prompt",
                    "Descripción de la fotografía: $answer")
                addJarvisAnswer(answer)
                _photoPreview.value = null
            } catch (error: Exception) {
                // Si falla Groq, la foto permanece en memoria solo para permitir reintentar.
                val notice = "No pude analizar la fotografía: ${error.message ?: "error de conexión"}"
                addJarvisAnswer(notice)
            } finally { state.update { it.copy(busy = false) } }
        }
    }

    fun setListening(value: Boolean) { state.update { it.copy(listening = value) } }

    fun submit(rawText: String, origin: String = "escrito") {
        val text = rawText.trim()
        if (text.isBlank() || state.value.busy) return
        state.update { it.copy(busy = true, messages = it.messages + ChatMessage(text, true)) }
        viewModelScope.launch {
            try {
                val settings = state.value.settings
                personalMemories.migrateLegacy(settings.memory)
                val memoryCommand = PersonalMemoryCommands.parse(text)
                val simpleCommand = settings.provider == "local" || LocalRouting.isLocal(text)
                val localAnswer = if (memoryCommand == null && simpleCommand) local.answer(text, "") else null
                val answer = if (memoryCommand != null) {
                    personalMemories.respond(memoryCommand)
                } else if (localAnswer != null) {
                    if (localAnswer.newMemory != null) preferences.saveMemory(localAnswer.newMemory)
                    localAnswer.action?.let { _actions.emit(it) }
                    localAnswer.text
                } else if (settings.provider != "local") {
                    val memoriesForAi = if (settings.usePersonalMemoriesWithAi) personalMemories.read() else emptyList()
                    val reply = remote.reply(settings, tokenStore.read(), text, conversation.read(), memoriesForAi)
                    conversation.addPair(text, reply)
                    reply
                } else {
                    "Para responder preguntas abiertas, configura un modelo en Ajustes → Inteligencia artificial."
                }
                history.addPair(text, answer, origin)
                addJarvisAnswer(answer)
            } catch (error: Exception) {
                val response = "No pude consultar el modelo: ${error.message ?: "error de conexión"}"
                history.addPair(text, response, origin)
                addJarvisAnswer(response)
            } finally { state.update { it.copy(busy = false) } }
        }
    }

    fun addJarvisAnswer(text: String) {
        state.update { it.copy(messages = it.messages + ChatMessage(text, false)) }
        _speech.tryEmit(text)
    }

    fun clearApiKey() {
        tokenStore.clear()
        addJarvisAnswer("Clave API eliminada de este dispositivo.")
    }

    fun clearChat() {
        conversation.clear()
        history.clear()
        state.update { it.copy(messages = JarvisUiState().messages) }
        addJarvisAnswer("Conversación borrada de este dispositivo.")
    }

    fun saveRemoteSettings(provider: String, endpoint: String, model: String, secret: String, allowOnLock: Boolean, personality: String) {
        viewModelScope.launch {
            try {
                require(provider in listOf("local", "ollama", "compatible")) { "Proveedor no válido." }
                if (provider != "local") {
                    ConversationGateway.validate(provider, endpoint)
                    require(model.trim().isNotBlank()) { "Debes indicar el nombre del modelo." }
                    if (provider == "compatible") require(secret.isNotBlank() || tokenStore.read().isNotBlank()) {
                        "Ingresa la clave API. Nunca la pegues en GitHub ni en este chat."
                    }
                }
                if (secret.isNotBlank()) {
                    require(provider == "compatible") { "La clave solo se utiliza con una API compatible." }
                    tokenStore.save(secret.trim())
                }
                preferences.saveAi(provider, if (provider == "local") "" else endpoint.trim(), model.trim(),
                    allowOnLock && provider != "local")
                preferences.savePersonality(personality)
                addJarvisAnswer(if (provider == "local") "Modo local activado." else
                    "Proveedor de IA guardado. Las preguntas abiertas se enviarán a ese servidor cuando me hables.")
            } catch (error: Exception) {
                addJarvisAnswer("No se guardó la configuración: ${error.message ?: "error"}")
            }
        }
    }
}
