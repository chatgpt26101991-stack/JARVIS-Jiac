# JIVAX Android 0.7.6 — verificación preliminar

- **Problema observado:** Vosk transcribe la llamada «JIVAX» como «y va» o variaciones. El matcher 0.7.5 no encontraba la palabra de activación.
- **Tratamiento:** frases deliberadas «Oye JIVAX» (incluyendo transcripción «oye y va») y «Hola asistente». Transcripción aislada «y va» requiere doble repetición con pausa, sin procesar resultados parciales y sin aceptar un solo «y va».
- **Pruebas locales:** compilan las clases puras Kotlin `WakeWordMatcher` y `WakeCandidateTracker`; pasaron 11 casos de coincidencia y 7 comprobaciones de temporización. El archivo ZIP superó comprobación de integridad.
- **Límite:** no se ha ejecutado una compilación Android completa ni probado audio real del dispositivo. Debe validarse mediante GitHub Actions y ensayo funcional.
- **Compatibilidad:** mismo `applicationId = com.jarvis.openandroid` y registros persistentes; versión 0.7.6 (`versionCode=27`). Instalar sobre la versión anterior solo con la misma firma.
