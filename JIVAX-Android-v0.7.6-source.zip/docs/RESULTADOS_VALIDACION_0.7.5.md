# JIVAX 0.7.5 — corrección del detector manos libres

## Causa identificada en código fuente 0.7.4

La pronunciación recomendada al usuario era «YÍ-VAKS», pero `WakeWordMatcher.WORDS_PATTERN` no incluía `yivaks` ni `jivaks`. Si el modelo Vosk devolvía esa transcripción, no se iniciaba la sesión manos libres. Esto constituye un desajuste comprobable en código, no demuestra todavía cuál fue el texto emitido por Vosk en el dispositivo.

## Cambios

- Se incorporan variantes fonéticas acotadas: `jivaks`, `yivaks`, `jibaks`, `yibaks`, otras terminaciones `-acs`/`-as` y `yi vaks`/`ji vaks`. No se incluyen palabras frecuentes como «vivas» para limitar activaciones accidentales.
- Se analiza `onFinalResult` además de `onResult`.
- `onPartialResult` sigue sin ejecutar comandos, pero el nuevo diagnóstico voluntario muestra temporalmente el resultado local de Vosk durante 20 segundos.
- La pantalla ofrece «Probar detector manos libres (20 s)» solo cuando la escucha está activa.
- `versionName` 0.7.5, `versionCode` 26; se conserva el `applicationId` y la firma de compilación para permitir actualización.

## Validación realizada

- Diez comprobaciones Kotlin de `WakeWordMatcher` mediante `kotlinc` con Java: **PASADAS**.
- XML de recursos y manifiesto parseados correctamente: **PASADO**.
- Inspección estática de conexión Activity → UI → servicio y versión: **PASADA**.
- Compilación Android de GitHub Actions: **NO EJECUTADA** en esta revisión.
- Audio real con Vosk en el teléfono, batería, permisos y bloqueo de pantalla: **PENDIENTE**.

## Prueba del usuario

1. Actualizar encima de JIVAX 0.7.4 sin desinstalar; debe usarse el mismo almacén de firma Android.
2. Pulsar «Activar JIVAX en segundo plano» y confirmar «Escuchando JIVAX (detección local)».
3. Pulsar «Probar detector manos libres (20 s)» y decir «YÍ-VAKS».
4. Si aparece «Vosk reconoció: ...», anotar solamente esas palabras para ajustar el detector, si hace falta.
5. Si no aparece transcripción, revisar autorización de micrófono, notificación, modo ahorro de batería y posible conflicto con otra aplicación que capture audio.
6. Verificar que el modo «Hablar con JIVAX» continúe operando y que el historial permanezca.

El diagnóstico no captura audio en archivos ni lo transmite. Solo muestra localmente la transcripción en pantalla mientras está activo.
