package com.jivax.openandroid.domain

import com.jivax.openandroid.wake.WakeCandidateTracker
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WakeCandidateTrackerTest {
    @Test fun twoSeparateCallsEnableWake() {
        val tracker = WakeCandidateTracker()
        assertFalse(tracker.onResult("y va", 1_000))
        assertTrue(tracker.onResult("y va", 2_800))
        assertFalse(tracker.onResult("y va", 4_000))
    }
    @Test fun rejectImmediateDuplicatesAndExpiredConfirmations() {
        val tracker = WakeCandidateTracker()
        assertFalse(tracker.onResult("y va", 1_000))
        assertFalse(tracker.onResult("y va", 1_100))
        assertFalse(tracker.onResult("y va", 9_000))
        assertTrue(tracker.onResult("y va", 10_000))
    }
    @Test fun interleavedSpeechCancelsPending() {
        val tracker = WakeCandidateTracker()
        assertFalse(tracker.onResult("y va", 1_000))
        assertFalse(tracker.onResult("vamos allá", 2_000))
        assertFalse(tracker.onResult("y va", 3_000))
        tracker.reset()
        assertFalse(tracker.onResult("y va", 4_000))
    }
}
