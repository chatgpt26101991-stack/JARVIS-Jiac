package com.jivax.openandroid.wake

/**
 * Confirma una transcripción ambigua («y va») SOLO si el usuario la repite
 * en dos frases finales separadas por una pausa, dentro de una ventana breve.
 * Nunca actúa sobre resultados parciales de Vosk ni ejecuta comandos de voz.
 * Las dos llamadas deben llegar desde callbacks onResult DISTINTOS.
 */
class WakeCandidateTracker(
    private val minGapMillis: Long = 550L,
    private val maxGapMillis: Long = 6_000L
) {
    init { require(minGapMillis > 0 && maxGapMillis > minGapMillis) }

    private var firstAtMillis = -1L

    fun onResult(text: String, nowMillis: Long): Boolean {
        if (!WakeWordMatcher.isAmbiguousWakeWord(text)) {
            reset()
            return false
        }
        val delta = nowMillis - firstAtMillis
        if (firstAtMillis >= 0L && delta in minGapMillis..maxGapMillis) {
            reset()
            return true
        }
        firstAtMillis = nowMillis
        return false
    }

    fun reset() { firstAtMillis = -1L }
}
