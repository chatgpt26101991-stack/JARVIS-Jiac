package com.jivax.openandroid

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.net.Uri
import java.io.File
import androidx.core.content.FileProvider
import com.jivax.openandroid.vision.VisionPhoto
import android.os.Build
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.jivax.openandroid.domain.AssistantAction
import com.jivax.openandroid.speech.TtsSpeaker
import com.jivax.openandroid.ui.JivaxScreen
import com.jivax.openandroid.ui.JivaxViewModel
import com.jivax.openandroid.wake.JivaxListeningService
import com.jivax.openandroid.wake.OfflineModelInstaller
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var model: JivaxViewModel
    private lateinit var speaker: TtsSpeaker
    private var recognizer: SpeechRecognizer? = null
    private var pendingCameraFile: File? = null
    private val camera = registerForActivityResult(ActivityResultContracts.TakePicture()) { captured ->
        val photo = pendingCameraFile
        pendingCameraFile = null
        if (photo != null) {
            try {
                if (captured) model.setPhotoPreview(VisionPhoto.toJpeg(photo))
            } catch (error: Exception) {
                model.addJivaxAnswer("No pude abrir la fotografía: ${error.message ?: "formato no admitido"}")
            } finally {
                // Ninguna copia de la imagen queda en caché cuando termina la cámara.
                photo.delete()
            }
        }
    }

    private val activityScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val modelReady = MutableStateFlow(false)
    private val downloading = MutableStateFlow(false)
    private val downloadProgress = MutableStateFlow(OfflineModelInstaller.Progress())
    private val requestWakePermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchWakeService()
        } else {
            model.addJivaxAnswer("Para activar JIVAX en segundo plano debes permitir el micrófono.")
        }
    }


    private val requestMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListening() else model.addJivaxAnswer("Sin permiso de micrófono puedes seguir escribiendo comandos.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        savedInstanceState?.getString("pending_vision_photo")?.let { pendingCameraFile = File(it) }
        model = ViewModelProvider(this)[JivaxViewModel::class.java]
        speaker = TtsSpeaker(this)
        modelReady.value = OfflineModelInstaller.isInstalled(this)
        setContent {
            val visionPhoto by model.photoPreview.collectAsState()
            val voiceOptions by speaker.voices.collectAsState()
            val voiceConfig by speaker.config.collectAsState()
            val activeWake by JivaxListeningService.isRunning.collectAsState()
            val wakeStatus by JivaxListeningService.status.collectAsState()
            val hasModel by modelReady.collectAsState()
            val downloadingModel by downloading.collectAsState()
            val progress by downloadProgress.collectAsState()
            LaunchedEffect(Unit) {
                model.speech.collect { speaker.speak(it) }
            }
            LaunchedEffect(Unit) {
                model.actions.collect { action ->
                    when (action) {
                        AssistantAction.OpenDeviceSettings -> startActivity(Intent(Settings.ACTION_SETTINGS))
                    }
                }
            }
            JivaxScreen(
                model = model,
                onListen = { requestListening() },
                onStopSpeech = { stopJivaxSpeech() },
                visionPhoto = visionPhoto,
                onCapturePhoto = { openCamera() },
                onAnalyzePhoto = { question -> model.analyzePhoto(question) },
                onDiscardPhoto = { model.discardPhoto() },
                voiceOptions = voiceOptions,
                voiceConfig = voiceConfig,
                onSaveVoice = { voiceId, pitch, rate -> speaker.saveVoice(voiceId, pitch, rate) },
                onPreviewVoice = { voiceId, pitch, rate -> speaker.preview(voiceId, pitch, rate) },
                wakeActive = activeWake,
                wakeStatus = wakeStatus,
                hasWakeModel = hasModel,
                downloadingWakeModel = downloadingModel,
                modelStatus = progress.message,
                modelDownloadProgress = progress,
                onInstallWakeModel = { downloadWakeModel() },
                onStartWake = { requestWakeActivation() },
                onDiagnoseWake = { diagnoseWake() },
                onStopWake = { stopService(Intent(this@MainActivity, JivaxListeningService::class.java)) }
            )
        }
    }

    private fun openCamera() {
        if (model.uiState.value.busy) return
        try {
            val tempDir = File(cacheDir, "vision").apply { mkdirs() }
            val photo = File.createTempFile("jivax_capture_", ".jpg", tempDir)
            pendingCameraFile = photo
            val uri: Uri = FileProvider.getUriForFile(this,
                "${packageName}.camera.fileprovider", photo)
            camera.launch(uri)
        } catch (error: Exception) {
            pendingCameraFile?.delete()
            pendingCameraFile = null
            model.addJivaxAnswer("No pude abrir la cámara del teléfono: ${error.message ?: "no disponible"}")
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        pendingCameraFile?.let { outState.putString("pending_vision_photo", it.absolutePath) }
        super.onSaveInstanceState(outState)
    }

    private fun downloadWakeModel() {
        if (downloading.value) return
        downloading.value = true
        activityScope.launch {
            try {
                OfflineModelInstaller.install(this@MainActivity) { downloadProgress.value = it }
                modelReady.value = OfflineModelInstaller.isInstalled(this@MainActivity)
                if (modelReady.value) model.addJivaxAnswer("Modelo local de voz instalado. Ya puedes activar el modo manos libres.")
            } catch (error: Exception) {
                val previous = downloadProgress.value
                val message = "Error al instalar: ${error.message ?: "desconocido"}. Pulsa Reintentar."
                downloadProgress.value = previous.copy(message = message, downloading = false)
                model.addJivaxAnswer(message)
            } finally {
                downloading.value = false
            }
        }
    }

    private fun requestWakeActivation() {
        if (!modelReady.value) {
            model.addJivaxAnswer("Primero descarga el modelo local en español.")
            return
        }
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        requestWakePermissions.launch(permissions.toTypedArray())
    }

    private fun launchWakeService() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, JivaxListeningService::class.java).setAction(JivaxListeningService.ACTION_START))
        } catch (error: Exception) {
            model.addJivaxAnswer("No se pudo activar la escucha: ${error.message}")
        }
    }

    private fun diagnoseWake() {
        if (!JivaxListeningService.isRunning.value) return
        try {
            startService(Intent(this, JivaxListeningService::class.java)
                .setAction(JivaxListeningService.ACTION_DIAGNOSTIC))
        } catch (error: Exception) {
            model.addJivaxAnswer("No pude iniciar el diagnóstico: ${error.message ?: "error"}")
        }
    }

    private fun stopJivaxSpeech() {
        speaker.stop()
        if (JivaxListeningService.isRunning.value) {
            try {
                startService(Intent(this, JivaxListeningService::class.java)
                    .setAction(JivaxListeningService.ACTION_SILENCE))
            } catch (error: Exception) {
                model.addJivaxAnswer("No pude detener la voz de fondo: ${error.message ?: "error"}")
            }
        }
    }

    private fun requestListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            requestMic.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            model.addJivaxAnswer("No encuentro un servicio de reconocimiento de voz instalado. Puedes usar el teclado.")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { model.setListening(true) }
                    override fun onBeginningOfSpeech() = Unit
                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() { model.setListening(false) }
                    override fun onError(error: Int) {
                        model.setListening(false)
                        model.addJivaxAnswer("No pude reconocer el audio (código $error). Inténtalo otra vez.")
                    }
                    override fun onResults(results: Bundle?) {
                        model.setListening(false)
                        val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        if (phrase.isNullOrBlank()) model.addJivaxAnswer("No escuché palabras reconocibles.")
                        else model.submit(phrase, "voz")
                    }
                    override fun onPartialResults(partialResults: Bundle?) = Unit
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })
            }
        }
        speaker.stop()
        model.setListening(true)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PE")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try {
            recognizer?.startListening(intent)
        } catch (error: Exception) {
            model.setListening(false)
            model.addJivaxAnswer("No pude iniciar el micrófono: ${error.message}")
        }
    }

    override fun onResume() {
        super.onResume()
        if (::model.isInitialized) model.refreshHistory()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        speaker.close()
        activityScope.cancel()
        super.onDestroy()
    }
}
