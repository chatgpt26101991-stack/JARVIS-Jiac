package com.jivax.openandroid.wake

import java.text.Normalizer
import java.util.Locale

/** Pure Kotlin, covered by JVM tests. Vosk returns words as JSON; parse JSON outside this class. */
object WakeWordMatcher {
    // Vosk puede escribir la X final como ks, cs, x o s al escuchar «YÍ-VAKS».
    // No admitir palabras comunes como «vivas» o «ibas» para evitar activaciones accidentales.
    // Estas alternativas se aplican únicamente a una palabra completa.
    const val WORDS_PATTERN = "jivax|yivax|jibax|yibax|jivacs|yivacs|jibacs|yibacs|jivaks|yivaks|jibaks|yibaks|jivas|yivas|jibas|yibas|(?:ji|yi)[\\s-]+(?:vaks|vacs|vax)"
    private val pattern = Regex("\\b(?:$WORDS_PATTERN)\\b")
    // Alternativas basadas en frases reales del vocabulario español de Vosk.
    // «y va» NO se acepta por sí sola: es demasiado habitual en una conversación.
    // Exigimos un saludo explícito al principio de la transcripción.
    private val spokenFallback = Regex(
        "^(?:oye|hola|hey|ey)[,;:]?\\s+(?:asistente|y\\s+va)\\b"
    )

    /** Transcripción exacta y ambigua que necesita DOS llamadas separadas para confirmar. */
    fun isAmbiguousWakeWord(phrase: String): Boolean = normalize(phrase) == "y va"

    private fun normalize(text: String): String = Normalizer.normalize(
        text.lowercase(Locale.ROOT).trim(), Normalizer.Form.NFD
    ).replace(Regex("\\p{M}+"), "")

    fun commandAfterWakeWord(phrase: String): String? {
        val normalized = normalize(phrase)
        val match = pattern.find(normalized) ?: spokenFallback.find(normalized) ?: return null
        return normalized.substring(match.range.last + 1).trim(' ', ',', '.', ':', '¿', '?', '¡', '!')
    }
}
