# JIVAX Android 0.7.6

**JIVAX** — *Jeison Iván Virtual Autonomous eXecutive*.

Asistente Android de código abierto, con palabra de activación local, voz, memoria, historial, preguntas sobre fotografías e integración opcional con modelos remotos. Esta versión migra el nombre anterior a una identidad propia.

**Frase de activación:** «JIVAX» (pronunciación sugerida: **YÍ-VAKS**). La detección de variantes depende de lo que transcriba el modelo Vosk y debe validarse en el teléfono.

## Actualización sobre 0.7.3

- La aplicación aparece como **JIVAX** con un icono propio y nuevos textos.
- Clases Kotlin, nombres de métodos, pruebas, `namespace` y componentes Android usan `com.jivax.openandroid`.
- `applicationId` **permanece** `com.jarvis.openandroid` por compatibilidad. No significa que la aplicación siga usando ese nombre visible.
- Se mantienen los identificadores históricos de DataStore, preferencias, historial, recuerdos y alias de Android Keystore para preservar la información del usuario.
- No se agregan permisos, accesos ocultos ni control irrestricto del teléfono en esta versión. Se mantienen las funciones existentes y los límites del sistema operativo.
- Versión: `versionName=0.7.6`, `versionCode=27`.

## Compilación y GitHub Actions

El archivo `.github/workflows/build-apk.yml` incluido funciona en un repositorio que almacena el ZIP `JIVAX-Android-v0.7.6-source.zip` en la raíz. Si subes los archivos **extraídos** a la raíz del repositorio, modifica el paso de extracción y el `working-directory` del workflow (o crea un workflow que compile desde la raíz).

**Conserva la firma anterior.** El workflow acepta `JIVAX_DEBUG_KEYSTORE_B64` o, si solo existe el antiguo, `JARVIS_DEBUG_KEYSTORE_B64`. Nunca publiques el contenido de esos secretos.

1. Sube el ZIP `JIVAX-Android-v0.7.6-source.zip` a la raíz de tu repositorio.
2. Sustituye también el archivo `.github/workflows/build-apk.yml` **de la raíz de GitHub** por el incluido o por `JIVAX-build-apk.yml` entregado aparte. El workflow que va dentro del ZIP no se ejecuta por sí solo.
3. Abre **Actions** y ejecuta «Compilar APK JIVAX».
4. Confirma `testDebugUnitTest` y `assembleDebug` exitosos y descarga el APK resultante.
5. Instálalo **encima** de la versión anterior con la misma firma, sin desinstalar ni borrar datos.
6. Ejecuta el protocolo de validación de `docs/PRUEBAS_MIGRACION.md`.

> **Estado:** cambio de código y comprobaciones estáticas; compilación Android, pruebas instrumentadas y validación de voz en hardware quedan pendientes de GitHub Actions y del teléfono.

Se conserva la trazabilidad técnica histórica en `docs/HISTORIAL_ANTERIOR.md`, con los nombres de versiones previas únicamente como documentación de archivo.

## Corrección manos libres 0.7.6

- El reconocimiento por botón usa el servicio de voz Android, mientras que manos libres usa **Vosk local**.
- Se incorporan variantes de reconocimiento de la pronunciación oficial «YÍ-VAKS» (`yivaks`, `jivaks`, etc.).
- Se aceptan resultados finales, además de resultados tras una pausa de voz.
- Se incluye **Probar detector manos libres (20 s)**. Debes tener activada la escucha. Durante la prueba di «Yívaks» y revisa el texto local mostrado. No se guarda el diagnóstico.
- **No se garantiza el reconocimiento por el solo cambio de patrones:** el modelo español Vosk puede transcribir una palabra inventada de otra manera; el diagnóstico permite identificar la salida real y ajustar el matcher.
- Si el modo manual funciona y el modo manos libres no, revisa el estado del servicio, la notificación, el permiso de micrófono y las restricciones de batería del dispositivo.

## Licencia

Apache License 2.0 (`LICENSE`), como en el proyecto original. Una licencia de código no concede derechos sobre marcas de terceros. Comprobar disponibilidad de JIVAX antes de publicarlo.

## Corrección de pronunciación 0.7.6

- Si Vosk transcribe «JIVAX» como «y va», la frase **«Oye JIVAX»** puede transcribirse «oye y va» y ahora activa JIVAX.
- **«Hola asistente»** y **«Oye asistente»** funcionan como respaldo con palabras comunes del español.
- Otra opción: pronunciar «JIVAX», hacer una pausa breve, y repetir «JIVAX». Para la transcripción exacta «y va» se requieren **dos resultados finales de Vosk distintos** entre 0,55 y 6 s; no se activa con «y va» una sola vez.
- El diagnóstico de 20 s prioriza el último resultado completo de Vosk; los resultados parciales siguen sin ejecutar órdenes.
- Son heurísticas locales, no un modelo de wake word personalizado. Deben probarse en teléfono, sin garantizar un porcentaje de acierto ni ausencia absoluta de falsos positivos.
