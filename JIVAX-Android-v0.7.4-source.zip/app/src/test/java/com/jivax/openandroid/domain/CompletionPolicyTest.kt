package com.jivax.openandroid.domain

import com.jivax.openandroid.network.CompletionPolicy
import org.junit.Assert.*
import org.junit.Test

class CompletionPolicyTest {
    @Test fun recognizesLengthFinishReasonOnly() {
        assertTrue(CompletionPolicy.needsContinuation("length"))
        assertTrue(CompletionPolicy.needsContinuation("MAX_TOKENS"))
        assertFalse(CompletionPolicy.needsContinuation("stop"))
        assertFalse(CompletionPolicy.needsContinuation(null))
    }

    @Test fun doesNotTruncateTypicalLongAnswers() {
        val longResponse = "a".repeat(6000)
        assertEquals(longResponse, CompletionPolicy.capWithNotice(longResponse))
    }

    @Test fun joinsAnswerPartsWithoutRepeatingOverlap() {
        assertEquals("Escribe las diferencias y compara a Bruce Wayne.",
            CompletionPolicy.join("Escribe las diferencias y compara a Bruce", "diferencias y compara a Bruce Wayne."))
    }

    @Test fun signalsProviderCutoff() {
        val result = CompletionPolicy.markIncomplete("| Aspecto físico")
        assertTrue(result.startsWith("| Aspecto físico"))
        assertTrue(result.contains("respuesta quedó incompleta"))
    }

    @Test fun marksExcessivelyLongContent() {
        val result = CompletionPolicy.capWithNotice("a".repeat(40000))
        assertTrue(result.length <= CompletionPolicy.MAX_FULL_ANSWER_LENGTH)
        assertTrue(result.contains("se alcanzó el límite"))
    }
}
