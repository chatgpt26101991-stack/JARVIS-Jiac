package com.jivax.openandroid.domain

import org.junit.Assert.*
import org.junit.Test

class JivaxPersonaTest {
    @Test fun `normaliza la configuracion sin perder equilibrio predeterminado`() {
        assertEquals(JivaxPersona.BALANCED, JivaxPersona.normalize(null))
        assertEquals(JivaxPersona.BALANCED, JivaxPersona.normalize("otro"))
        assertEquals(JivaxPersona.PROFESSIONAL, JivaxPersona.normalize("profesional"))
    }

    @Test fun `equilibrado indica una ocurrencia en conversaciones claramente ludicas`() {
        val prompt = JivaxPersona.systemPrompt(JivaxPersona.BALANCED,
            "JIVAX, construiré un traje de Iron Man con cartón, ¿qué opinas?")
        assertTrue(prompt.contains("MODO EQUILIBRADO"))
        assertTrue(prompt.contains("UNA observación breve"))
        assertTrue(prompt.contains("CONTEXTO ACTUAL"))
        assertTrue(prompt.contains("PRIORIDAD ABSOLUTA"))
    }

    @Test fun `pregunta sobre genio recibe pista de contexto pero pregunta normal no`() {
        assertTrue(JivaxPersona.isClearlyPlayful("JIVAX, ¿tú crees que soy un genio?"))
        assertFalse(JivaxPersona.isClearlyPlayful("¿Cuál es la capital de Perú?"))
        assertFalse(JivaxPersona.systemPrompt(JivaxPersona.BALANCED, "¿Cuál es la capital de Perú?")
            .contains("CONTEXTO ACTUAL"))
    }

    @Test fun `pregunta real sobre actualizaciones y personalidad recibe pista ludica`() {
        val pregunta = "JIVAX, ¿qué opinas de que llevemos tantas actualizaciones intentando perfeccionar tu personalidad?"
        assertTrue(JivaxPersona.isClearlyPlayful(pregunta))
        val prompt = JivaxPersona.systemPrompt(JivaxPersona.BALANCED, pregunta)
        assertTrue(prompt.contains("CONTEXTO ACTUAL"))
        assertTrue(prompt.contains("ocurrencia breve"))
    }

    @Test fun `no confunde cambio tecnico con una invitacion a bromear`() {
        assertFalse(JivaxPersona.isClearlyPlayful("Necesito instalar las actualizaciones del sistema."))
        assertFalse(JivaxPersona.isClearlyPlayful("¿Cómo actualizo la versión de Android?"))
        assertFalse(JivaxPersona.isClearlyPlayful("Corrige un defecto de la personalidad en el código de Kotlin."))
    }

    @Test fun `el contexto delicado anula cualquier broma sobre la personalidad`() {
        val prompt = JivaxPersona.systemPrompt(JivaxPersona.BALANCED,
            "Tengo una emergencia con las actualizaciones de tu personalidad, necesito ayuda urgente")
        assertFalse(prompt.contains("CONTEXTO ACTUAL"))
        assertTrue(prompt.contains("PRIORIDAD ABSOLUTA"))
    }

    @Test fun `emergencia tiene prioridad incluso si incluye palabras ludicas`() {
        assertFalse(JivaxPersona.isClearlyPlayful("Me herí probando mi traje de Iron Man"))
        assertFalse(JivaxPersona.isClearlyPlayful("Tengo una emergencia con un cartón"))
        val prompt = JivaxPersona.systemPrompt(JivaxPersona.WITTY, "Me herí probando mi traje de Iron Man")
        assertFalse(prompt.contains("CONTEXTO ACTUAL"))
        listOf(JivaxPersona.PROFESSIONAL, JivaxPersona.BALANCED, JivaxPersona.WITTY).forEach { mode ->
            val policy = JivaxPersona.systemPrompt(mode)
            assertTrue(policy.contains("omite absolutamente el sarcasmo y las bromas"))
            assertTrue(policy.contains("No inventes hechos"))
        }
    }

    @Test fun `profesional no recibe pista de humor aunque la solicitud sea ludica`() {
        val prompt = JivaxPersona.systemPrompt(JivaxPersona.PROFESSIONAL, "¿Soy un genio?")
        assertTrue(prompt.contains("sin sarcasmo y casi sin bromas"))
        assertFalse(prompt.contains("CONTEXTO ACTUAL"))
        assertFalse(prompt.contains("EJEMPLOS ORIENTATIVOS"))
    }
    @Test fun `la respuesta corporativa de la prueba 51 activa solo una reformulacion`() {
        val question = "JIVAX, ¿qué opinas de que llevemos tantas actualizaciones intentando perfeccionar tu personalidad?"
        val answer = "Me complace que sigamos refinando la forma en que respondo. " +
            "Cada actualización me permite ser más claro, útil y adaptarme mejor a tus necesidades."
        assertTrue(JivaxPersona.needsToneRepair(JivaxPersona.BALANCED, question, answer))
        assertTrue(JivaxPersona.needsToneRepair(JivaxPersona.WITTY, question, answer))
        assertFalse(JivaxPersona.needsToneRepair(JivaxPersona.PROFESSIONAL, question, answer))
        assertFalse(JivaxPersona.needsToneRepair(JivaxPersona.WITTY,
            "Necesito ayuda urgente tras un accidente", answer))
    }

    @Test fun `una ironia original no provoca reintentos`() {
        val question = "JIVAX, ¿qué opinas de tantas actualizaciones para perfeccionar tu personalidad?"
        assertFalse(JivaxPersona.needsToneRepair(JivaxPersona.BALANCED, question,
            "Mi carácter parece exigir más mantenimiento que un reactor arc. Al menos no hay que cambiarme la batería, señor."))
    }

}
