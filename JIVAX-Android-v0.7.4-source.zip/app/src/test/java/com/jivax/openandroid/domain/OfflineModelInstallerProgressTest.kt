package com.jivax.openandroid.domain

import com.jivax.openandroid.wake.OfflineModelInstaller
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class OfflineModelInstallerProgressTest {
    @Test fun reportsRealPercentage() {
        assertEquals(25, OfflineModelInstaller.Progress(downloadedBytes = 25L, totalBytes = 100L).percentage)
        assertEquals(100, OfflineModelInstaller.Progress(downloadedBytes = 110L, totalBytes = 100L).percentage)
    }

    @Test fun withoutTotalDoesNotInventPercentage() {
        assertNull(OfflineModelInstaller.Progress(downloadedBytes = 500L).percentage)
        assertNull(OfflineModelInstaller.Progress(downloadedBytes = 500L, totalBytes = 0L).percentage)
    }
}
