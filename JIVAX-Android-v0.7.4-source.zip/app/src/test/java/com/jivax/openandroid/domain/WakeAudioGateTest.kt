package com.jivax.openandroid.domain

import com.jivax.openandroid.wake.WakeAudioGate
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Test

class WakeAudioGateTest {
    @Test fun detectorRemainsMutedDuringSpeechAndTail() {
        val gate = WakeAudioGate(1200L)
        assertFalse(gate.mayAccept(100L))
        gate.prepareToResume(200L)
        assertFalse(gate.mayAccept(1399L))
        assertTrue(gate.mayAccept(1400L))
    }

    @Test fun newSpeechCancelsOldReadiness() {
        val gate = WakeAudioGate(1200L)
        gate.prepareToResume(0L)
        gate.mute()
        assertFalse(gate.mayAccept(5000L))
        gate.prepareToResume(5000L)
        assertEquals(1200L, gate.millisUntilReady(5000L))
        assertFalse(gate.mayAccept(6199L))
        assertTrue(gate.mayAccept(6200L))
    }
}
