package com.jivax.openandroid.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.Clock
import java.time.Instant
import java.time.ZoneId

class LocalTimeResponseTest {
    private val frozenClock = Clock.fixed(Instant.parse("2026-10-18T15:42:00Z"), ZoneId.of("America/Lima"))
    private val engine = LocalCommandEngine(frozenClock)

    @Test fun timeIsReadFromDeviceClockNotAI() {
        assertEquals("Son las 10:42.", engine.answer("JIVAX dime la hora", "")?.text)
        assertEquals("Son las 10:42.", engine.answer("¿Me puedes decir qué hora es?", "")?.text)
    }

    @Test fun ambiguousSchedulesAreNotLocalTime() {
        assertNull(engine.answer("¿A qué hora empieza mi reunión?", ""))
        assertNull(engine.answer("¿Qué hora es en Tokio?", ""))
    }
}
