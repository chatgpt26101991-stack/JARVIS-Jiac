package com.jivax.openandroid.domain

import com.jivax.openandroid.data.HistoryEntry
import com.jivax.openandroid.data.HistoryPolicy
import org.junit.Assert.*
import org.junit.Test

class ConversationHistoryPolicyTest {
    @Test fun recordsQuestionAndFullAnswerInOrder() {
        val stored = HistoryPolicy.append(emptyList(), "¿Qué es Júpiter?", "**Júpiter** es un planeta.", "manos libres", 123L)
        assertEquals(2, stored.size)
        assertEquals("user", stored[0].role)
        assertEquals("assistant", stored[1].role)
        assertEquals("**Júpiter** es un planeta.", stored[1].content)
        assertEquals("manos libres", stored[1].origin)
        assertEquals(123L, stored[0].timestamp)
    }

    @Test fun retainsOnlyOneHundredMostRecentPairs() {
        var entries: List<HistoryEntry> = emptyList()
        repeat(105) { i -> entries = HistoryPolicy.append(entries, "pregunta $i", "respuesta $i", "voz", i.toLong()) }
        assertEquals(200, entries.size)
        assertEquals("pregunta 5", entries.first().content)
        assertEquals("respuesta 104", entries.last().content)
    }

    @Test fun doesNotStoreEmptyRequestsOrUnboundedTexts() {
        assertTrue(HistoryPolicy.append(emptyList(), " ", "respuesta", "voz", 0).isEmpty())
        val stored = HistoryPolicy.append(emptyList(), "q".repeat(2500), "a".repeat(22000), "otro", 0)
        assertEquals(1500, stored[0].content.length)
        assertEquals(20000, stored[1].content.length)
        assertEquals("escrito", stored[0].origin)
    }
}
