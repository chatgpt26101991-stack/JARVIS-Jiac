package com.jivax.openandroid.domain

import com.jivax.openandroid.data.PersonalMemoryCommand
import com.jivax.openandroid.data.PersonalMemoryCommands
import com.jivax.openandroid.data.PersonalMemoryPolicy
import org.junit.Assert.*
import org.junit.Test

class PersonalMemoryPolicyTest {
    @Test fun `recuerda orden inicial y con palabra de activacion`() {
        assertEquals(PersonalMemoryCommand.Save("prefiero respuestas breves"),
            PersonalMemoryCommands.parse("Recuerda que prefiero respuestas breves"))
        assertEquals(PersonalMemoryCommand.Save("mi idioma es español"),
            PersonalMemoryCommands.parse("JIVAX, recuerda que mi idioma es español"))
    }

    @Test fun `permite consultar y protege borrado total con confirmacion visual`() {
        assertEquals(PersonalMemoryCommand.Show, PersonalMemoryCommands.parse("¿Qué recuerdas?"))
        assertEquals(PersonalMemoryCommand.RequestClear,
            PersonalMemoryCommands.parse("JIVAX olvida todos mis recuerdos"))
    }

    @Test fun `no secuestra preguntas normales`() {
        assertNull(PersonalMemoryCommands.parse("¿Por qué es importante recordar la historia?"))
        assertNull(PersonalMemoryCommands.parse("Dime por qué Júpiter tiene anillos"))
    }

    @Test fun `limita cantidad y longitud y evita duplicados`() {
        var list = emptyList<String>()
        (1..25).forEach { list = PersonalMemoryPolicy.add(list, "Preferencia $it") }
        assertEquals(20, list.size)
        assertEquals("Preferencia 6", list.first())
        assertEquals(list, PersonalMemoryPolicy.add(list, "PREFERENCIA 25"))
        assertEquals(240, PersonalMemoryPolicy.add(emptyList(), "x".repeat(300)).single().length)
    }
}
