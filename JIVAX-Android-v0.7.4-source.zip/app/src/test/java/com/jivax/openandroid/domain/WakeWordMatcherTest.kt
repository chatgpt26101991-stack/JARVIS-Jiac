package com.jivax.openandroid.domain

import com.jivax.openandroid.wake.WakeWordMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class WakeWordMatcherTest {
    @Test fun detectsJivax() { assertEquals("que hora es", WakeWordMatcher.commandAfterWakeWord("JIVAX, ¿qué hora es?")) }
    @Test fun noSubstringTrigger() { assertNull(WakeWordMatcher.commandAfterWakeWord("mi jivaxito funciona")) }
    @Test fun SpanishVariants() {
        assertEquals("abre ajustes", WakeWordMatcher.commandAfterWakeWord("Yivax abre ajustes"))
        assertEquals("abre ajustes", WakeWordMatcher.commandAfterWakeWord("Jibax, abre ajustes"))
    }
    @Test fun legacyWordIsNotTrigger() { assertNull(WakeWordMatcher.commandAfterWakeWord("Jarvis, hola")) }
    @Test fun noKeyword() { assertNull(WakeWordMatcher.commandAfterWakeWord("qué hora es")) }
}
