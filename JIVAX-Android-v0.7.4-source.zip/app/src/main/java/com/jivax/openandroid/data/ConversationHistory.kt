package com.jivax.openandroid.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class ConversationHistory(context: Context) {
    companion object {
        const val STORAGE_NAME = "jarvis_visible_history_v06"
        const val KEY_ENTRIES = "entries"
        private const val KEY_INITIALIZED = "initialized"
        private val storageLock = Any()
    }

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(STORAGE_NAME, Context.MODE_PRIVATE)

    init {
        synchronized(storageLock) {
            if (!prefs.getBoolean(KEY_INITIALIZED, false)) {
                // Conservar el historial remoto breve de la versión anterior en la primera migración.
                val legacy = ConversationMemory(appContext).read()
                val migrated = legacy.map { turn ->
                    HistoryEntry(turn.role, turn.content, 0L, "anterior")
                }
                prefs.edit().putString(KEY_ENTRIES, serialize(migrated))
                    .putBoolean(KEY_INITIALIZED, true).apply()
            }
        }
    }

    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.registerOnSharedPreferenceChangeListener(listener)

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.unregisterOnSharedPreferenceChangeListener(listener)

    fun read(): List<HistoryEntry> = synchronized(storageLock) { deserialize(prefs.getString(KEY_ENTRIES, "[]")) }

    fun addPair(question: String, answer: String, origin: String) {
        synchronized(storageLock) {
            val current = deserialize(prefs.getString(KEY_ENTRIES, "[]"))
            val updated = HistoryPolicy.append(current, question, answer, origin, System.currentTimeMillis())
            if (updated != current) prefs.edit().putString(KEY_ENTRIES, serialize(updated)).apply()
        }
    }

    fun clear() = synchronized(storageLock) {
        prefs.edit().putString(KEY_ENTRIES, "[]").putBoolean(KEY_INITIALIZED, true).apply()
    }

    private fun serialize(entries: List<HistoryEntry>): String = JSONArray().apply {
        entries.forEach { entry ->
            put(JSONObject().put("role", entry.role).put("content", entry.content)
                .put("time", entry.timestamp).put("origin", entry.origin))
        }
    }.toString()

    private fun deserialize(raw: String?): List<HistoryEntry> = try {
        val array = JSONArray(raw ?: "[]")
        (0 until array.length()).mapNotNull { index ->
            val row = array.optJSONObject(index) ?: return@mapNotNull null
            val role = row.optString("role")
            val content = row.optString("content")
            if (role !in listOf("user", "assistant") || content.isBlank()) null
            else HistoryEntry(role, content.take(if (role == "user") HistoryPolicy.MAX_QUESTION_LENGTH
                else HistoryPolicy.MAX_ANSWER_LENGTH), row.optLong("time", 0L),
                row.optString("origin", "anterior"))
        }.takeLast(HistoryPolicy.MAX_PAIRS * 2)
    } catch (_: Exception) { emptyList() }
}
