package com.jivax.openandroid.speech

import kotlinx.coroutines.flow.MutableStateFlow

/** Señal exclusivamente en este proceso: el servicio Vosk no debe captar nuestro propio TTS. */
object VoicePlaybackState {
    val appVoiceActive = MutableStateFlow(false)
}
