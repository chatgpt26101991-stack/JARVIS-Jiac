package com.jivax.openandroid.network

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Habla con el endpoint /api/chat de Ollama servido por HTTPS.
 * No transmite recuerdos locales ni contiene tokens en el APK.
 * Para instalaciones productivas: autenticación y HTTPS en el gateway.
 */
class OllamaRemoteEngine {
    suspend fun ask(endpoint: String, model: String, prompt: String): String = withContext(Dispatchers.IO) {
        val uri = Uri.parse(endpoint.trim())
        require(uri.scheme == "https" && !uri.host.isNullOrBlank()) {
            "El servidor debe tener una URL HTTPS válida."
        }
        require(uri.path == "/api/chat") {
            "La URL debe terminar en /api/chat."
        }
        val request = JSONObject().apply {
            put("model", model)
            put("stream", false)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", "Eres JIVAX, un asistente útil. Responde en español de forma precisa.")
                })
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
        }
        val connection = (URL(endpoint.trim()).openConnection() as HttpURLConnection)
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 10_000
            connection.readTimeout = 45_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.outputStream.use { it.write(request.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            if (code !in 200..299) error("El servidor respondió con HTTP $code")
            val payload = connection.inputStream.bufferedReader().use { it.readText() }
            JSONObject(payload).getJSONObject("message").getString("content").trim()
                .ifBlank { "El modelo devolvió una respuesta vacía." }
        } finally {
            connection.disconnect()
        }
    }
}
