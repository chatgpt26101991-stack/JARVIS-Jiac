package com.jivax.openandroid.wake

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream
import kotlin.coroutines.coroutineContext

/** Descarga reanudable para el modelo local de Vosk (Apache-2.0). */
object OfflineModelInstaller {
    private const val MODEL_NAME = "vosk-model-small-es-0.42"
    private const val ZIP_URL = "https://alphacephei.com/vosk/models/$MODEL_NAME.zip"
    private const val MAX_DOWNLOAD = 85L * 1024L * 1024L
    private const val MAX_UNPACKED = 350L * 1024L * 1024L
    private const val MAX_ATTEMPTS = 4

    data class Progress(
        val message: String = "Modelo local pendiente",
        val downloadedBytes: Long = 0L,
        val totalBytes: Long? = null,
        val downloading: Boolean = false
    ) {
        val percentage: Int?
            get() = totalBytes?.takeIf { it > 0L }?.let {
                ((downloadedBytes.coerceIn(0L, it) * 100L) / it).toInt()
            }
    }

    fun modelPath(context: Context): File = File(context.filesDir, "offline_models/$MODEL_NAME")

    fun isInstalled(context: Context): Boolean =
        File(modelPath(context), "am/final.mdl").isFile &&
        File(modelPath(context), "conf/mfcc.conf").isFile

    suspend fun install(context: Context, report: (Progress) -> Unit) = withContext(Dispatchers.IO) {
        if (isInstalled(context)) {
            report(Progress("Modelo local instalado. Ya puedes activar JIVAX."))
            return@withContext
        }
        val home = File(context.filesDir, "offline_models").apply { mkdirs() }
        // Mantener el archivo parcial entre intentos, incluso si Android cierra la pantalla.
        val partial = File(home, "$MODEL_NAME.zip.part")
        if (partial.length() > MAX_DOWNLOAD) partial.delete()
        var completed = false
        var lastError: IOException? = null

        for (attempt in 1..MAX_ATTEMPTS) {
            coroutineContext.ensureActive()
            var connection: HttpURLConnection? = null
            try {
                val offset = partial.length()
                connection = (URL(ZIP_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 35_000
                    instanceFollowRedirects = true
                    setRequestProperty("Accept-Encoding", "identity")
                    if (offset > 0L) setRequestProperty("Range", "bytes=$offset-")
                }
                val code = connection.responseCode
                if (code == 416 && offset > 0L) {
                    // El servidor no reconoce este segmento: descargar desde el principio.
                    partial.delete()
                    throw IOException("El segmento guardado ya no está disponible")
                }
                if (code != HttpURLConnection.HTTP_OK && code != HttpURLConnection.HTTP_PARTIAL) {
                    throw IOException("Servidor HTTP $code")
                }
                if (code == HttpURLConnection.HTTP_PARTIAL && offset == 0L) {
                    throw IOException("Respuesta parcial inesperada del servidor")
                }
                if (code == HttpURLConnection.HTTP_PARTIAL) {
                    val start = Regex("^bytes\\s+(\\d+)-\\d+/(?:\\d+|\\*)$")
                        .find(connection.getHeaderField("Content-Range").orEmpty())
                        ?.groupValues?.getOrNull(1)?.toLongOrNull()
                    if (start != offset) {
                        partial.delete()
                        throw IOException("El servidor envió un rango distinto al solicitado")
                    }
                }
                // Algunos servidores ignoran Range y responden 200. Reiniciar en lugar de
                // concatenar dos ZIP y mostrar un porcentaje engañoso.
                val resume = code == HttpURLConnection.HTTP_PARTIAL && offset > 0L
                val initial = if (resume) offset else 0L
                val remaining = connection.contentLengthLong
                val rangeTotal = if (resume) connection.getHeaderField("Content-Range")
                    ?.substringAfterLast('/')?.toLongOrNull() else null
                val total = rangeTotal ?: remaining.takeIf { it >= 0L }?.let { it + initial }
                require(total == null || total <= MAX_DOWNLOAD) { "Descarga demasiado grande" }
                var received = initial
                var lastReported = -1L
                report(Progress("Descargando modelo español (intento $attempt/$MAX_ATTEMPTS)", received, total, true))
                connection.inputStream.use { input ->
                    FileOutputStream(partial, resume).use { output ->
                        val bytes = ByteArray(32 * 1024)
                        while (true) {
                            coroutineContext.ensureActive()
                            val length = input.read(bytes)
                            if (length < 0) break
                            received += length
                            require(received <= MAX_DOWNLOAD) { "Descarga excede el límite de seguridad" }
                            output.write(bytes, 0, length)
                            if (received - lastReported >= 128 * 1024 || lastReported < 0L) {
                                lastReported = received
                                report(Progress("Descargando modelo español (intento $attempt/$MAX_ATTEMPTS)", received, total, true))
                            }
                        }
                    }
                }
                if (total != null && received != total) {
                    throw IOException("Descarga incompleta: $received de $total bytes")
                }
                report(Progress("Descarga completa. Verificando y extrayendo modelo…", received, total, true))
                completed = true
                break
            } catch (error: IOException) {
                lastError = error
                if (attempt == MAX_ATTEMPTS) break
                report(Progress(
                    "Conexión interrumpida. Reintentando ($attempt/$MAX_ATTEMPTS)…",
                    partial.length(), null, true
                ))
                delay(1000L * attempt)
            } finally {
                connection?.disconnect()
            }
        }
        if (!completed) {
            throw IOException("No se completó la descarga después de $MAX_ATTEMPTS intentos: " +
                (lastError?.message ?: "error de conexión") + ". Se conservaron los datos descargados.")
        }

        val stage = File(home, "stage")
        stage.deleteRecursively()
        stage.mkdirs()
        try {
            var uncompressed = 0L
            var files = 0
            val prefix = stage.canonicalPath + File.separator
            ZipInputStream(partial.inputStream().buffered()).use { stream ->
                while (true) {
                    coroutineContext.ensureActive()
                    val entry = stream.nextEntry ?: break
                    files++
                    require(files <= 1500) { "Demasiados archivos en el modelo" }
                    val target = File(stage, entry.name)
                    require(target.canonicalPath.startsWith(prefix)) { "Ruta no permitida en el ZIP" }
                    if (entry.isDirectory) {
                        target.mkdirs()
                    } else {
                        target.parentFile?.mkdirs()
                        target.outputStream().use { output ->
                            val buffer = ByteArray(32 * 1024)
                            while (true) {
                                coroutineContext.ensureActive()
                                val count = stream.read(buffer)
                                if (count < 0) break
                                uncompressed += count
                                require(uncompressed <= MAX_UNPACKED) { "Modelo demasiado grande" }
                                output.write(buffer, 0, count)
                            }
                        }
                    }
                    stream.closeEntry()
                }
            }
            val extracted = File(stage, MODEL_NAME)
            require(File(extracted, "am/final.mdl").isFile &&
                    File(extracted, "conf/mfcc.conf").isFile) {
                "El ZIP no contiene un modelo Vosk español válido"
            }
            val final = modelPath(context)
            final.deleteRecursively()
            require(extracted.renameTo(final)) { "No pude mover el modelo a su ubicación definitiva" }
            partial.delete()
            report(Progress("Modelo instalado. Puedes activar JIVAX en segundo plano."))
        } catch (error: Exception) {
            // El ZIP puede estar corrupto si la descarga original se cortó sin Content-Length.
            // En ese caso no se debe reutilizar en el siguiente intento.
            if (error is java.util.zip.ZipException || error is IllegalArgumentException ||
                (error is IllegalStateException && error.message?.contains("ZIP") == true)) {
                partial.delete()
            }
            throw error
        } finally {
            stage.deleteRecursively()
        }
    }
}
