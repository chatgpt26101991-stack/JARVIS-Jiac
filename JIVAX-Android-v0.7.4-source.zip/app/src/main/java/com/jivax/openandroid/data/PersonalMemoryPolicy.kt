package com.jivax.openandroid.data

import java.text.Normalizer
import java.util.Locale
import com.jivax.openandroid.wake.WakeWordMatcher

/** Reglas de memoria personal puras, sin dependencias de Android. */
object PersonalMemoryPolicy {
    const val MAX_ITEMS = 20
    const val MAX_LENGTH = 240

    fun clean(text: String): String = text.trim().replace(Regex("\\s+"), " ").take(MAX_LENGTH)

    fun add(previous: List<String>, newText: String): List<String> {
        val item = clean(newText)
        if (item.isBlank()) return previous
        if (previous.any { it.equals(item, ignoreCase = true) }) return previous
        return (previous + item).takeLast(MAX_ITEMS)
    }
}

/** Solo órdenes explícitas. Las preguntas normales siguen enviándose al motor correspondiente. */
sealed interface PersonalMemoryCommand {
    data class Save(val value: String) : PersonalMemoryCommand
    data object Show : PersonalMemoryCommand
    data object RequestClear : PersonalMemoryCommand
}

object PersonalMemoryCommands {
    private val wakePrefix = Regex("^(?:(?:oye|hola)\\s+)?(?:${WakeWordMatcher.WORDS_PATTERN})[,.:!\\s]+", RegexOption.IGNORE_CASE)
    private val savePrefix = Regex("^recuerda\\s+que(?:\\s+|$)", RegexOption.IGNORE_CASE)
    private val nonLetters = Regex("[^a-z0-9 ]")

    private fun normalized(text: String) = Normalizer.normalize(text.lowercase(Locale.forLanguageTag("es-PE")), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace(nonLetters, " ").replace(Regex("\\s+"), " ").trim()

    fun parse(phrase: String): PersonalMemoryCommand? {
        val original = phrase.trim().replace(wakePrefix, "").trim()
        val match = savePrefix.find(original)
        if (match != null) return PersonalMemoryCommand.Save(original.substring(match.range.last + 1).trim())
        return when (normalized(original)) {
            "que recuerdas", "que es lo que recuerdas", "que cosas recuerdas",
            "muestrame mis recuerdos", "dime que recuerdas", "mis recuerdos" -> PersonalMemoryCommand.Show
            "borra todos mis recuerdos", "olvida todos mis recuerdos", "olvida lo que recuerdas",
            "borra el recuerdo", "olvida lo que recordaste" -> PersonalMemoryCommand.RequestClear
            else -> null
        }
    }
}
