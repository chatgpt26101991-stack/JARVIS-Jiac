package com.jivax.openandroid.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Cifra la clave con Android Keystore; jamás se almacena en el repositorio. */
class SecureApiKeyStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("jarvis_ai_credentials", Context.MODE_PRIVATE)
    private val alias = "jarvis_ai_key_v04"

    private fun encryptionKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build())
        return generator.generateKey()
    }

    @Synchronized
    fun save(secret: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, encryptionKey())
        val encoded = cipher.doFinal(secret.toByteArray(Charsets.UTF_8))
        prefs.edit()
            .putString("value", Base64.encodeToString(encoded, Base64.NO_WRAP))
            .putString("nonce", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .apply()
    }

    @Synchronized
    fun read(): String {
        val value = prefs.getString("value", null) ?: return ""
        val nonce = prefs.getString("nonce", null) ?: return ""
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, encryptionKey(),
                GCMParameterSpec(128, Base64.decode(nonce, Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(value, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    @Synchronized
    fun clear() { prefs.edit().clear().apply() }
}
