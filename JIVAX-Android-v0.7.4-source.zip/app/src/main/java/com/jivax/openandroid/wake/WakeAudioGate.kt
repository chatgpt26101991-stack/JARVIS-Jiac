package com.jivax.openandroid.wake

/** Control del eco TTS usando tiempo monotónico (elapsedRealtime), no la hora del reloj. */
class WakeAudioGate(private val tailSilenceMillis: Long = 1200L) {
    private var paused = true
    private var allowedAtMillis = Long.MAX_VALUE

    fun mute() {
        paused = true
        allowedAtMillis = Long.MAX_VALUE
    }

    fun prepareToResume(nowMillis: Long) {
        paused = false
        allowedAtMillis = nowMillis + tailSilenceMillis
    }

    fun mayAccept(nowMillis: Long): Boolean = !paused && nowMillis >= allowedAtMillis

    fun millisUntilReady(nowMillis: Long): Long =
        if (paused) tailSilenceMillis else (allowedAtMillis - nowMillis).coerceAtLeast(0)
}
