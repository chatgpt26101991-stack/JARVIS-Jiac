package com.jivax.openandroid.wake

import java.text.Normalizer
import java.util.Locale

/** Pure Kotlin, covered by JVM tests. Vosk returns words as JSON; parse JSON outside this class. */
object WakeWordMatcher {
    // Variantes fonéticas de JIVAX usadas cuando Vosk transcribe la pronunciación española.
    // Mantenerlas sincronizadas con LocalRouting y PersonalMemoryCommands.
    const val WORDS_PATTERN = "jivax|yivax|jibax|yibax|jivacs|yivacs"
    private val pattern = Regex("\\b(?:$WORDS_PATTERN)\\b")

    fun commandAfterWakeWord(phrase: String): String? {
        val normalized = Normalizer.normalize(phrase.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        val match = pattern.find(normalized) ?: return null
        // Indexes generally align for 'jivax'; extracting from normalized text is intentional.
        return normalized.substring(match.range.last + 1).trim(' ', ',', '.', ':', '¿', '?', '¡', '!')
    }
}
