package com.jivax.openandroid.wake

import java.text.Normalizer
import java.util.Locale

/**
 * Ventana de seguimiento tras una activación explícita («Jivax»).
 * No inicia escuchas: solo decide si una transcripción de Vosk sin wake word
 * puede aceptarse. El micrófono y sus permisos siguen a cargo del servicio.
 *
 * El reloj del llamador debe ser monotónico (SystemClock.elapsedRealtime()).
 */
class ConversationSession(
    private val followupWindowMillis: Long = 15_000L,
    private val wakeCommandWindowMillis: Long = 12_000L,
    private val maxFollowups: Int = 4
) {
    init {
        require(followupWindowMillis > 0 && wakeCommandWindowMillis > 0 && maxFollowups >= 0)
    }

    private var deadlineMillis: Long = 0L
    private var openAfterSpeech = false
    private var waitingForFirstCommand = false
    private var remainingFollowups = 0

    /** Una activación reinicia el contador y autoriza un diálogo breve si el usuario lo activó. */
    fun onWake(hasCommand: Boolean, continuousEnabled: Boolean) {
        deadlineMillis = 0L
        waitingForFirstCommand = !hasCommand
        remainingFollowups = if (continuousEnabled) maxFollowups else 0
        openAfterSpeech = waitingForFirstCommand || remainingFollowups > 0
    }

    /** Llamar SOLO cuando el TTS terminó y el micrófono reanudó tras el filtro antieco. */
    fun onRecognitionResumed(nowMillis: Long): Long? {
        if (!openAfterSpeech) {
            deadlineMillis = 0L
            return null
        }
        val duration = if (waitingForFirstCommand) wakeCommandWindowMillis else followupWindowMillis
        deadlineMillis = nowMillis + duration
        openAfterSpeech = false
        return deadlineMillis
    }

    fun isOpen(nowMillis: Long): Boolean = deadlineMillis > 0L && nowMillis < deadlineMillis

    /** Acepta una única transcripción mientras la ventana esté abierta. */
    fun takeFollowup(nowMillis: Long): Boolean {
        if (!isOpen(nowMillis)) {
            deadlineMillis = 0L
            return false
        }
        deadlineMillis = 0L
        if (waitingForFirstCommand) {
            waitingForFirstCommand = false
            openAfterSpeech = remainingFollowups > 0
        } else {
            remainingFollowups = (remainingFollowups - 1).coerceAtLeast(0)
            openAfterSpeech = remainingFollowups > 0
        }
        return true
    }

    fun end() {
        deadlineMillis = 0L
        openAfterSpeech = false
        waitingForFirstCommand = false
        remainingFollowups = 0
    }

    companion object {
        private val endingPhrases = setOf(
            "terminar conversacion", "finalizar conversacion", "fin de conversacion",
            "hasta luego jivax", "jivax hasta luego", "jivax descansa",
            "hasta luego yivax", "yivax hasta luego", "yivax descansa",
            "dejar de escuchar", "termina conversacion"
        )
        fun isEndCommand(text: String): Boolean {
            val normalized = Normalizer.normalize(text.lowercase(Locale.ROOT).trim(), Normalizer.Form.NFD)
                .replace(Regex("\\p{M}+"), "")
                .trim(' ', '.', '?', '¿', '!', '¡', ',')
            return normalized in endingPhrases
        }
    }
}
