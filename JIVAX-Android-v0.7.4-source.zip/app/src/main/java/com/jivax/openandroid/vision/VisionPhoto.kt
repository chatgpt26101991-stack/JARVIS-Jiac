package com.jivax.openandroid.vision

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File

/** Reduce una captura temporal a JPEG razonable antes de mostrarla o enviarla.
 * No conserva la imagen en el historial ni en almacenamiento público.
 */
object VisionPhoto {
    fun toJpeg(photo: File): ByteArray {
        require(photo.exists() && photo.length() > 0L) { "La cámara no devolvió ninguna fotografía." }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(photo.absolutePath, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "No se pudo leer la fotografía." }
        var downsample = 1
        while (bounds.outWidth / downsample > 2000 || bounds.outHeight / downsample > 2000)
            downsample *= 2
        val bitmap = BitmapFactory.decodeFile(photo.absolutePath,
            BitmapFactory.Options().apply { inSampleSize = downsample })
            ?: error("No se pudo decodificar la fotografía.")
        try {
            val rotation = try {
                when (ExifInterface(photo.absolutePath).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } catch (_: Exception) { 0f }
            var transformed: Bitmap = bitmap
            if (rotation != 0f) {
                val matrix = Matrix().apply { postRotate(rotation) }
                transformed = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height,
                    matrix, true)
            }
            try {
                val maxSide = maxOf(transformed.width, transformed.height)
                val scale = (1600f / maxSide).coerceAtMost(1f)
                val finalBitmap = if (scale < 1f) Bitmap.createScaledBitmap(transformed,
                    (transformed.width * scale).toInt().coerceAtLeast(1),
                    (transformed.height * scale).toInt().coerceAtLeast(1), true)
                    else transformed
                try {
                    return ByteArrayOutputStream().use { stream ->
                        require(finalBitmap.compress(Bitmap.CompressFormat.JPEG, 78, stream)) {
                            "No se pudo comprimir la fotografía."
                        }
                        stream.toByteArray().also { require(it.size <= VisionRequestPolicy.MAX_IMAGE_BYTES) {
                            "La fotografía es demasiado grande para analizarla."
                        } }
                    }
                } finally {
                    if (finalBitmap !== transformed) finalBitmap.recycle()
                }
            } finally {
                if (transformed !== bitmap) transformed.recycle()
            }
        } finally { bitmap.recycle() }
    }
}
