package com.jivax.openandroid.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.jivax.openandroid.domain.JivaxPersona
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.jivaxDataStore by preferencesDataStore(name = "jarvis_settings")

data class JivaxSettings(
    val endpoint: String = "",
    val model: String = "openai/gpt-oss-20b",
    val memory: String = "",
    val provider: String = "local",
    val allowOnLock: Boolean = false,
    val continuousVoice: Boolean = false,
    val usePersonalMemoriesWithAi: Boolean = false,
    val personalityMode: String = "equilibrado"
)

class JivaxPreferences(private val context: Context) {
    private val endpointKey = stringPreferencesKey("ollama_endpoint")
    private val modelKey = stringPreferencesKey("ollama_model")
    private val memoryKey = stringPreferencesKey("memory_text")
    private val providerKey = stringPreferencesKey("ai_provider_v04")
    private val lockedKey = booleanPreferencesKey("ai_on_lock_v04")
    private val continuousKey = booleanPreferencesKey("continuous_voice_v05")
    private val shareMemoryKey = booleanPreferencesKey("share_personal_memories_with_ai_v061")
    private val personalityKey = stringPreferencesKey("personality_mode_v062")

    val settings: Flow<JivaxSettings> = context.jivaxDataStore.data.map { preferences ->
        val endpoint = preferences[endpointKey].orEmpty()
        JivaxSettings(
            endpoint = endpoint,
            model = preferences[modelKey] ?: (if (endpoint.isBlank()) "openai/gpt-oss-20b" else "llama3.2"),
            memory = preferences[memoryKey].orEmpty(),
            provider = preferences[providerKey] ?: (if (endpoint.isBlank()) "local" else "ollama"),
            allowOnLock = preferences[lockedKey] ?: false,
            continuousVoice = preferences[continuousKey] ?: false,
            usePersonalMemoriesWithAi = preferences[shareMemoryKey] ?: false,
            personalityMode = JivaxPersona.normalize(preferences[personalityKey])
        )
    }

    suspend fun saveAi(provider: String, endpoint: String, model: String, allowOnLock: Boolean) {
        context.jivaxDataStore.edit { preferences ->
            preferences[providerKey] = provider
            preferences[endpointKey] = endpoint.trim()
            preferences[modelKey] = model.trim()
            preferences[lockedKey] = allowOnLock
        }
    }

    suspend fun saveContinuousVoice(enabled: Boolean) {
        context.jivaxDataStore.edit { preferences -> preferences[continuousKey] = enabled }
    }

    suspend fun saveSharePersonalMemories(enabled: Boolean) {
        context.jivaxDataStore.edit { preferences -> preferences[shareMemoryKey] = enabled }
    }

    suspend fun savePersonality(mode: String) {
        context.jivaxDataStore.edit { preferences ->
            preferences[personalityKey] = JivaxPersona.normalize(mode)
        }
    }

    suspend fun saveMemory(text: String) {
        context.jivaxDataStore.edit { preferences -> preferences[memoryKey] = text }
    }
}
