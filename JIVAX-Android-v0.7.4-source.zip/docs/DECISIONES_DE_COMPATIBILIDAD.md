# Decisiones de compatibilidad de la migración

La versión 0.7.4 conserva **por diseño** los siguientes identificadores históricos internos, pese a renombrar la interfaz y el código fuente:

- `applicationId = com.jarvis.openandroid`: mismo paquete para actualización in-place.
- DataStore `jarvis_settings`.
- Preferencias `jarvis_voice_v02`, `jarvis_conversation_v04`, `jarvis_visible_history_v06`, `jarvis_personal_memories_v061`, `jarvis_ai_credentials`.
- Alias de Android Keystore `jarvis_ai_key_v04`.
- Canal de notificaciones `jarvis_active_listening`, para conservar los ajustes del usuario.
- Secreto de GitHub Actions anterior `JARVIS_DEBUG_KEYSTORE_B64` como opción de compatibilidad de firma.

Renombrar arbitrariamente cualquiera de ellos puede provocar pérdida aparente de datos, restablecer configuraciones, inaccesibilidad de claves cifradas o impedir actualizar el APK.

En una edición futura se puede implementar una migración explícita con copia y verificación, seguida de una estrategia de respaldo/recuperación. Los secretos no se entregan en el ZIP.
