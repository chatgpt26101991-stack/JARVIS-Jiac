# J.A.R.V.I.S. Android v0.7.3 — Historial y contexto textual de fotografías

Esta actualización parte directamente del código fuente 0.7.2 aportado por el usuario.

## Cambios

- El título «HISTORIAL LOCAL» ahora abre una ventana desplazable y seleccionable con consultas y respuestas previamente guardadas, sin borrarlas.
- Después de analizar una foto, su **descripción textual** se incorpora también a `ConversationMemory`, usada por los mensajes posteriores enviados al proveedor de IA. No persiste ni transmite de nuevo el JPEG en consultas posteriores.
- Se acepta el origen `cámara` dentro del historial local.
- Se incrementa la versión a `0.7.3` (`versionCode=24`).

## Limitaciones pendientes

- El reconocimiento manos libres corre en un servicio separado. Las órdenes de voz sobre una **foto todavía en vista previa** no quedan vinculadas a la vista previa en esta entrega. Por privacidad, el envío de la fotografía sigue requiriendo pulsar «Describir foto con Groq» o «Preguntar sobre la foto con Groq».
- Las preguntas posteriores sobre la foto usan la descripción **textual guardada**, no los píxeles originales. Preguntas que exijan nuevos detalles pueden necesitar volver a enviar otra fotografía.
- No se han ejecutado aquí la compilación Android ni pruebas de dispositivo; validar en GitHub Actions y teléfono.

## Para GitHub

**Opción recomendada:** extraer el ZIP y subir los archivos extraídos a la raíz de un repositorio que tenga el proyecto completo; el workflow incluido presupone **otro esquema** basado en un ZIP en la raíz del repositorio. Si se mantiene el esquema previo basado en ZIP, sustituir en GitHub el ZIP antiguo por `JARVIS-Jiac-v0.7.3-source.zip` y actualizar `.github/workflows/build-apk.yml` en la **raíz del repositorio**, de modo que use el nuevo nombre.

Instalar sobre la app existente sin desinstalar, usando la misma firma de pruebas. No subir claves API ni keystores a GitHub.

# J.A.R.V.I.S. Android v0.7.2 — Preguntas específicas sobre fotografías (fase 3.2)

Esta entrega parte de la versión 0.7.1, que ya pasó las pruebas de captura y análisis de varios objetos. **Nuevo:** desde la vista previa de una fotografía se puede escribir una pregunta específica, por ejemplo «¿De qué color es la lata?» o «¿Qué se lee en la etiqueta?».

- **Describir foto con Groq:** mantiene el análisis general de 0.7.1 y no necesita pregunta.
- **Preguntar sobre la foto con Groq:** envía esa misma imagen con la pregunta escrita (máximo 300 caracteres); aparece en el historial local solo el texto de la pregunta y la respuesta; J.A.R.V.I.S. responde por pantalla y voz. Si hay duda en el contenido visual, se pide al modelo que lo indique en vez de inventar.
- **Descartar foto sin enviarla:** la elimina de memoria y no hace ninguna llamada al servicio.
- La foto sigue sin guardarse en el historial, y se elimina de la memoria al completar el análisis correctamente. El envío al proveedor se realiza únicamente al pulsar un botón de análisis; evitar datos sensibles.
- Conserva `applicationId=com.jarvis.openandroid`, firma fija, Vosk, TTS, Groq conversacional, personalidad, memoria e historial; solo aumenta `versionCode=23` y `versionName=0.7.2`.
- Se agregan pruebas unitarias para preguntas vacías, normalización y límite de longitud. **Pendiente:** ejecutar compilación GitHub Actions y validar en el teléfono; todavía no se debe reportar como aprobado.

## Instalación desde teléfono

1. Subir `JARVIS-Jiac-v0.7.2-source.zip` a la raíz del repositorio GitHub.
2. Editar `.github/workflows/build-apk.yml` **en el repositorio**, cambiando el ZIP extraído a `JARVIS-Jiac-v0.7.2-source.zip` y el artefacto a `JARVIS-Jiac-v0.7.2-debug-APK`. El archivo incluido dentro del ZIP no cambia el workflow del repositorio automáticamente.
3. Mantener `JARVIS_DEBUG_KEYSTORE_B64` sin modificaciones; ejecutar Actions, comprobar tests y construcción del APK.
4. Instalar **encima** de 0.7.1 sin borrar datos ni desinstalar.
5. En J.A.R.V.I.S. tomar una foto no sensible, escribir «¿De qué color es la lata?» y elegir **Preguntar sobre la foto con Groq**. Verificar que contesta a la pregunta por escrito y con voz masculina. Probar aparte «Describir foto con Groq» y «Descartar foto sin enviarla».

---

# J.A.R.V.I.S. Android v0.7.1 — Corrección de error HTTP 404 en visión

**Actualización correctiva para el paso 64.** En 0.7.0 la cámara y la vista previa pasaron, pero Groq devolvió HTTP 404 al intentar analizar la fotografía. No se conoce el código exacto devuelto por el proveedor porque 0.7.0 mostraba solamente el código HTTP. La documentación actual de Groq muestra `qwen/qwen3.8-27b` para visión; 0.7.0 usaba `qwen/qwen3.6-27b`.

- Se actualiza **solo** el identificador del modelo visual a `qwen/qwen3.8-27b`, según la documentación oficial https://console.groq.com/docs/vision . El modelo conversacional `openai/gpt-oss-20b` no cambia.
- Se mejora el diagnóstico de errores HTTP (401, 403, 404, 429, 5xx) y, si Groq informa un código técnico seguro, se muestra sin revelar claves, fotos o cuerpos de respuesta.
- Se agregan pruebas locales para verificar el modelo y las rutas de error. No se ha hecho ninguna llamada en vivo a Groq; se requiere comprobar la respuesta en el teléfono.
- `applicationId=com.jarvis.openandroid`, `versionCode=22`, `versionName=0.7.1`. Sin cambios en Android Keystore, Vosk, TTS, memorias, historial, UI de cámara ni servicios de voz.
- **Instala encima de v0.7.0, sin desinstalar ni borrar datos.** La foto pendiente no persiste después de cerrar la app: deberás tomar otra de prueba.

## GitHub desde teléfono

1. Subir `JARVIS-Jiac-v0.7.1-source.zip` al mismo repositorio sin eliminar los ZIP anteriores.
2. Editar el archivo **del repositorio** `.github/workflows/build-apk.yml` (el workflow dentro del ZIP no se usa directamente al ejecutar Actions). Cambiar `unzip -q JARVIS-Jiac-v0.7.0-source.zip -d source` por `unzip -q JARVIS-Jiac-v0.7.1-source.zip -d source` y `JARVIS-Jiac-v0.7.0-debug-APK` por `JARVIS-Jiac-v0.7.1-debug-APK`.
3. No tocar los secretos ni la firma fija `JARVIS_DEBUG_KEYSTORE_B64`. Ejecutar el workflow y verificar que todas las pruebas y compilación terminen en verde.
4. Instalar el APK **encima** de la app instalada. Abrir cámara, tomar una foto no sensible (p. ej. una lata), pulsar Analizar con Groq, comprobar texto y voz. Si vuelve a fallar, compartir el **mensaje completo de error sin claves ni datos personales**.

---

# J.A.R.V.I.S. Android v0.7.0 — Fase 3.1: cámara y primera visión

**Primera entrega funcional de la fase 3 (beta).** A partir del código 0.6.10 aprobado en la fase 2. No se sustituyen ni borran la voz masculina, Vosk, Groq conversacional, los recuerdos, el historial ni el modo manos libres. La app mantiene `com.jarvis.openandroid`; `versionCode=21`, `versionName=0.7.0`.

## Qué permite hacer

1. Abrir **la aplicación de cámara del sistema Android** pulsando `Abrir cámara · Fase 3` dentro de J.A.R.V.I.S. La cámara no queda capturando continuamente y no se abre automáticamente con el teléfono bloqueado.
2. Tomar una fotografía. Se guarda provisionalmente en un archivo privado de caché mediante `FileProvider`. J.A.R.V.I.S. la decodifica a JPEG de hasta 1600 px y elimina el archivo temporal inmediatamente después de recibirla.
3. Revisar la foto dentro de J.A.R.V.I.S. y elegir **Descartar foto** (sin subir nada) o **Analizar con Groq** (consentimiento explícito para enviar la foto a Groq).
4. Tras pulsar Analizar, se envía la foto a `https://api.groq.com/openai/v1/chat/completions` utilizando el modelo multimodal independiente `qwen/qwen3.6-27b`. Se reutiliza la clave API de Groq almacenada en Android Keystore; no está en el repositorio. **La foto sale del dispositivo únicamente tras ese consentimiento explícito.**
5. La descripción de la imagen se añade al historial **solo como texto**, y se lee con la voz ya instalada. Ni la foto ni su base64 se guardan en la memoria personal o en el historial local. Se necesita conexión, permisos que haya solicitado la aplicación de cámara y disponibilidad/cuota del modelo de visión.

## Límites de esta versión

- La captura se inicia desde el botón de la app abierta, no con una orden de voz bajo bloqueo. La orden «Jarvis, ¿qué estás viendo?» y la cámara en directo se abordarán en etapas posteriores, tras comprobar la seguridad y la experiencia de usuario.
- Se toma **una sola foto** por análisis. No reconoce vídeo, no opera la cámara en segundo plano y no identifica personas por nombre. Evitar fotografías privadas o sensibles.
- La fotografía pendiente se conserva **solo en memoria**; se pierde si Android cierra el proceso. Si se cancela la captura se borra el archivo de caché.
- La opción de visión funciona en esta entrega **solo con una cuenta Groq configurada** (no Ollama ni proveedores genéricos), mediante `qwen/qwen3.6-27b`. El modelo conversacional puede seguir siendo `openai/gpt-oss-20b` sin cambios. La disponibilidad de modelos externos puede cambiar y el proveedor puede aplicar cargos/cuotas.
- Si Groq falla, permanece la foto en memoria para reintentar o descartar. Si finaliza con éxito, el JPEG en memoria se descarta. La imagen no se guarda en el historial.

## Pruebas propuestas al instalar el APK

1. Confirmar V0.7.0; que la memoria, personalidad, historial y voz siguen funcionando sin pérdida de datos.
2. Pulsar `Abrir cámara · Fase 3`, tomar una foto **de un objeto cotidiano no sensible** y comprobar la vista previa.
3. Pulsar `Descartar foto`: verificar que vuelve el botón de cámara y no hay análisis ni envío.
4. Tomar otra foto y pulsar `Analizar con Groq`: verificar que la descripción aparece por escrito, se puede copiar y se escucha por voz.
5. Verificar que no haya permisos de captura continua ni necesidad de desinstalar. Si falla, enviar el mensaje visible, sin compartir credenciales ni fotos privadas.

## Compilación desde GitHub Actions

Subir `JARVIS-Jiac-v0.7.0-source.zip` al repositorio. En `.github/workflows/build-apk.yml` del **repositorio**, cambiar la línea `unzip -q` para usar este ZIP y renombrar el artefacto `JARVIS-Jiac-v0.7.0-debug-APK`. Mantener `JARVIS_DEBUG_KEYSTORE_B64` sin cambios y no desinstalar la app actual. Ejecutar `:app:testDebugUnitTest` y `:app:assembleDebug`.

**Estado de validación:** comprobaciones JVM de reglas HTTPS/JPEG y XML correctas. **Todavía no se ha compilado ni ejecutado en un dispositivo Android.** La publicación no sustituye esa prueba funcional.

---

# J.A.R.V.I.S. Android v0.6.10 — Corrección de personalidad en Groq (fase 2)

La prueba 51 falló tanto con **Equilibrado** como con **Ingenioso**: Groq respondió con casi el mismo texto corporativo sobre actualizaciones. La detección del contexto lúdico ya funcionaba en 0.6.9, por lo que cambiar más palabras clave no resolvería el problema.

## Ajustes

- Cuando se utiliza un modelo compatible **openai/gpt-oss-20b / 120b**, la guía de personalidad se transmite con rol **developer**, adecuado para los modelos GPT-OSS. Otros modelos compatibles y Ollama mantienen **system** para no introducir regresiones por roles no admitidos.
- En consultas explícitamente juguetonas, respuestas corporativas previamente guardadas se omiten **solo del contexto remoto enviado**; el historial visible no se elimina ni modifica.
- Si una respuesta claramente informal coincide con patrones genéricos ya observados, se solicita **como máximo una reformulación a Groq** con instrucciones de humor elegante y seriedad cuando corresponda, usando un contexto separado. No hay frases pregrabadas. La reformulación adicional puede consumir más tokens y tiempo. Si falla o se corta, J.A.R.V.I.S. conserva la respuesta original.
- Se mantiene el tratamiento serio de emergencias, enfermedad, angustia y solicitudes sensibles. **Modo Profesional nunca activa reformulación humorística.**
- Se conservan voz larga, tratamiento de almohadillas y tablas, historial, memoria, Groq, Vosk, permisos y firma de pruebas. No compartir la clave API.

## Validación

Se agregaron pruebas unitarias de reconocimiento de respuestas genéricas y roles de mensaje. Sin una clave API real del usuario **no se ha ejecutado una prueba en vivo con Groq**: la fase 2 sigue abierta hasta comprobar en Android humor en modo Equilibrado y seriedad ante un caso delicado. No desinstalar la aplicación ni borrar datos.

## Publicación desde el teléfono

1. Sube `JARVIS-Jiac-v0.6.10-source.zip` al repositorio GitHub.
2. En `.github/workflows/build-apk.yml` cambia la línea de extracción a `unzip -q JARVIS-Jiac-v0.6.10-source.zip -d source` y el artefacto a `JARVIS-Jiac-v0.6.10-debug-APK`.
3. Mantén intacto `JARVIS_DEBUG_KEYSTORE_B64`.
4. Ejecuta las pruebas/compilación, instala sobre 0.6.9 y vuelve al modo **Equilibrado** para la prueba.

---

# J.A.R.V.I.S. Android v0.6.9 — Personalidad Equilibrado, humor contextual

**Fase 2 · corrección tras prueba 48 (0.6.8).** La limpieza de almohadillas y la atribución de características a Iron Man y Batman pasaron. La prueba de humor **falló** con la consulta: «¿Qué opinas de que llevemos tantas actualizaciones intentando perfeccionar tu personalidad?». El modo Equilibrado no reconocía ese tipo de comentario como una conversación lúdica porque su detección estaba restringida a ciertas palabras (como «genio» o «Iron Man»).

- Se amplía la detección de comentarios juguetones relacionados con la propia personalidad del asistente, sus mejoras y actualizaciones, sin tratar todas las actualizaciones técnicas como bromas.
- Se ajustan las instrucciones del modelo de IA para que, cuando corresponda, añada **una sola ironía ingeniosa y respetuosa** a su respuesta útil. No se agregan frases fijas a la aplicación ni se garantiza que un modelo remoto obedezca siempre el estilo.
- La norma de **seriedad ante emergencias, angustia, salud y temas delicados** sigue teniendo prioridad. El modo Profesional conserva su estilo sin humor; el modo Ingenioso mantiene su propia configuración.
- Se agregan pruebas de regresión para la pregunta exacta de la prueba 48, consultas técnicas normales y situaciones sensibles.
- No se cambian los servicios de voz ni Vosk, el historial, la memoria, Groq/Ollama, la firma, los permisos o los datos de usuario. Actualizar encima de 0.6.8, **sin desinstalar**.

**Pendiente:** compilación Android mediante GitHub Actions y validación real del humor del modelo. No se considera corregido el fallo hasta probarlo con preguntas casuales y serias en el teléfono.

---

# J.A.R.V.I.S. Android v0.6.8 — Protección final contra «almohadilla» en la voz

**Fase 2 · corrección de pronunciación (regresión 0.6.7).** La versión anterior filtraba encabezados `#` válidos, pero no algunos marcadores de numeral intercalados en texto generado por Groq; Android TTS los podía leer como «almohadilla».

`SpokenResponse.plainForSpeech()` incorpora ahora un filtro final: las almohadillas restantes nunca llegan al sintetizador, incluso si el modelo las coloca en medio de una oración o como un fragmento mal formado. La notación `C#` se lee «C sharp» y `#1` como «número 1». El texto original de Groq, la interfaz, el historial, la función de copia, la memoria y las configuraciones no se modifican. El lector continúa fragmentando las respuestas largas y verbalizando las tablas identificando cada columna.

Se agregaron pruebas automatizadas para títulos, almohadillas inline, caracteres escapados, tablas, C# y números ordinales. Esta versión aún requiere compilación y pruebas reales en Android antes de dar el defecto por corregido. Instalar por encima de la anterior, sin desinstalar ni borrar datos, conservando la misma firma fija de GitHub Actions.

---

# J.A.R.V.I.S. Android v0.6.7 — Voz legible para comparaciones y Markdown

**Fase 2: corrección de pronunciación.** Al leer comparaciones entre Iron Man y Batman, el motor TTS podía decir «almohadilla» por los encabezados Markdown y mezclar características de las columnas de una tabla.

Esta versión corrige solo la **presentación para voz**: elimina encabezados como `#` o `##` del texto hablado, verbaliza filas de tablas como «Tecnología. Iron Man: ... Batman: ...» e instruye a la IA para evitar tablas Markdown en conversaciones de voz y atribuir cada característica a su personaje. El texto original, la copia, el historial, la memoria y las preferencias se mantienen sin cambios.

También se conservan las mejoras de 0.6.6: lectura de todos los fragmentos largos, antieco y detención voluntaria. Las pruebas incluyen títulos Markdown mal formados, comparaciones de 2 y 3 columnas, respuestas largas y preservación de C#.

La compilación y las pruebas de integración Android deben realizarse en GitHub Actions antes de instalar y validar el comportamiento en el celular. Instalar encima de la versión anterior sin desinstalar ni borrar datos. Mantener la firma fija `JARVIS_DEBUG_KEYSTORE_B64`.

# J.A.R.V.I.S. Android v0.6.6 — Corrección de lectura larga por voz

**Fase 2.** La versión 0.6.5 solucionó la generación y visualización del texto largo,
pero las dos rutas de síntesis de voz seguían ejecutando `SpokenResponse.concise()`
(500 caracteres por respuesta). Eso explicaba que la voz terminara mucho antes que
el texto copiable, aun si Groq entregaba una respuesta completa.

Esta versión utiliza `SpokenResponse.chunks(...)` (bloques de hasta 650 caracteres)
y reproduce cada bloque al completarse el anterior, tanto desde la Activity como
el servicio manos libres de Vosk. El micrófono permanece pausado mientras se
reproduce la respuesta y se reanuda con el antieco al finalizar el **último** bloque.
El botón «Detener voz» y la acción de silenciar la notificación cancelan todos los
bloques pendientes. El temporizador de 90 segundos opera por bloque y evita quedarse
sin escucha si un motor TTS deja de notificar su finalización. La aplicación indica
cuando la lectura de manos libres falló durante un bloque.

El historial, Groq, memoria personal, portapapeles y las preferencias del motor de voz
se conservan. No se modifican permisos ni se incorporan credenciales.

## Instalación y verificación

1. Sube `JARVIS-Jiac-v0.6.6-source.zip` al repositorio de GitHub.
2. Cambia la línea `unzip -q` del workflow para apuntar a ese ZIP y cambia el
   nombre del artefacto a `JARVIS-Jiac-v0.6.6-debug-APK`. Conserva la firma fija.
3. Ejecuta las pruebas de GitHub Actions y compila el APK.
4. Instala sobre la versión actual SIN desinstalar y sin borrar datos.
5. Pide una comparación larga de Iron Man y Batman, deja que J.A.R.V.I.S. lea
   todos los bloques y verifica que alcance la última línea que puedes copiar.
6. Repite en modo manos libres y después pulsa «Detener voz» para comprobar la
   cancelación y la reanudación de Vosk sin eco.

**Nota:** TTS de Android puede fallar por causas externas (motor, audio, batería).
En ese caso la lectura se detiene y la respuesta completa permanece en pantalla.
El código solo está preparado y probado localmente: requiere build de Android en
GitHub Actions y validación real en el teléfono.

---

# J.A.R.V.I.S. Android v0.6.5 — respuestas completas y aviso de cortes

**Corrección del fallo detectado en la prueba 39 (v0.6.4).** Una comparación entre Iron Man y Batman llegó al historial y al portapapeles incompleta, terminando en «Aspecto físico». Se identificaron límites de 600 tokens en la solicitud y un recorte incondicional de 1.800 caracteres al recibir el resultado. El historial 0.6.4 admitía 4.000 caracteres.

Cambios:

- Incrementa el presupuesto de generación a 2.600 tokens por solicitud y **elimina `take(1800)` de la respuesta de Groq/Ollama**.
- Cuando el proveedor devuelve `finish_reason: length` (o `done_reason: length`), solicita hasta dos continuaciones adicionales y une el texto; si se alcanza el límite o hay un fallo, muestra una **advertencia explícita** en lugar de presentar una respuesta cortada como completa. Una respuesta puede tardar más o consumir más cuota de proveedor.
- Se amplía el espacio del historial local a 20.000 caracteres por respuesta y la generación individual se limita a 16.000 caracteres con aviso expreso cuando supera esa longitud; mantiene el límite de 100 pares. Los recuerdos personales y el contexto breve enviado a Groq continúan separados del historial visible.
- Para comparaciones orientadas a un teléfono, se solicitan listas legibles en lugar de tablas Markdown con barras verticales; es una preferencia del modelo, no un renderizador de tablas.
- Añade pruebas locales de ensamblado, límite de respuesta, persistencia de textos largos y señalización de cortes. **La validación de Gradle/GitHub Actions y las pruebas sobre Android están pendientes.**
- Mantiene la identidad `com.jarvis.openandroid`, versión 0.6.5, firma fija de pruebas, Groq, Vosk, voz, memoria, personalidad y acciones existentes. Actualizar **encima** de la 0.6.4, nunca desinstalar para esta prueba.

**Importante:** los fragmentos que ya fueron descartados por 0.6.4 no pueden reconstruirse desde el historial. Para comprobar la corrección, vuelve a formular la pregunta después de instalar 0.6.5, abre «Leer completa» y usa «Copiar todo». Si aparece una advertencia de respuesta incompleta, repórtala.

## Instalación desde el celular

1. Sube `JARVIS-Jiac-v0.6.5-source.zip` al repositorio GitHub en `main`.
2. Edita `.github/workflows/build-apk.yml` para leer `JARVIS-Jiac-v0.6.5-source.zip` y publicar el artefacto `JARVIS-Jiac-v0.6.5-debug-APK`.
3. Conserva `JARVIS_DEBUG_KEYSTORE_B64`; no publiques la clave ni la compartas.
4. Valida las pruebas y la compilación del APK con GitHub Actions; instala el APK sobre la versión anterior.
5. Repite «Jarvis, explícame cinco diferencias entre Iron Man y Batman, con ejemplos detallados». Verifica que la explicación no termine a media oración, y copia la respuesta completa.

---

# J.A.R.V.I.S. Android v0.6.4 — Mejoras de lectura y copia (fase 2)

Esta versión incluye íntegramente las funciones 0.6.3: personalidad equilibrada, memoria personal, voz, reconocimiento Vosk y almacenamiento del historial. No modifica las preferencias ni la firma de Android.

## Mejoras de interfaz 0.6.4

- Los mensajes del historial muestran una vista previa compacta y un botón **Leer completa**. Al pulsarlo, se abre una vista de lectura de casi toda la pantalla con desplazamiento vertical y selección de texto. **No borra ni modifica el mensaje original.**
- Cada mensaje de usuario y de J.A.R.V.I.S. dispone de **Copiar**. En el lector ampliado existe **Copiar todo**, que usa el portapapeles de Android para pegar después en WhatsApp, notas, ChatGPT, etc.
- La presentación y el texto copiado eliminan las marcas habituales de Markdown (`**negrita**`, cursiva, títulos, código en línea), sin modificar lo almacenado en el historial.
- La tarjeta del modo manos libres obtiene la **versión real del paquete instalado** mediante Android PackageManager, en lugar de mostrar una constante desactualizada.
- Se conserva el límite de seguridad previo del historial local: hasta 100 pares de pregunta/respuesta, con máximo de 4.000 caracteres por respuesta y 1.500 por pregunta. Los mensajes históricos ya recortados no pueden recuperarse con esta actualización.

## Cómo compilar desde el teléfono

1. Sube `JARVIS-Jiac-v0.6.4-source.zip` al repositorio GitHub.
2. En el `build-apk.yml` **de la raíz del repositorio**, cambia únicamente el origen del ZIP a `JARVIS-Jiac-v0.6.4-source.zip` y el nombre del artefacto a `JARVIS-Jiac-v0.6.4-debug-APK`.
3. Preserva intacto el secreto de firma fija `JARVIS_DEBUG_KEYSTORE_B64` para actualizar sin borrar la app.
4. Cuando GitHub Actions termine correctamente, descarga el artefacto, extrae `app-debug.apk` e instálalo sobre 0.6.3.
5. Comprueba la versión 0.6.4, abre una respuesta larga con **Leer completa**, desplázate hasta el final y usa **Copiar todo** para pegarla en otra aplicación.

---

# J.A.R.V.I.S. Android v0.6.3 — Fase 2: corrección del estilo equilibrado

Actualización incremental sobre v0.6.2. Corrige la prueba funcional 33/33.1: personalidad demasiado seria aunque Equilibrado estaba guardado.

- Refuerza las instrucciones enviadas a Groq para conversaciones claramente juguetonas: primero una respuesta útil y después una sola observación ingeniosa o irónica, amable y breve.
- Usa ejemplos de estilo orientativos y una pista adicional para frases claramente lúdicas (p. ej., traje de Iron Man de cartón o «¿soy un genio?»), sin respuestas enlatadas.
- Prioridad absoluta: **sin sarcasmo ni bromas** en emergencias y contextos sensibles. El modo Profesional tampoco recibe una pista humorística.
- El mismo `ConversationGateway` aplica estas instrucciones a mensajes escritos y manos libres.
- Conserva los formatos y preferencias existentes: memoria local, historial, opción de compartir recuerdos con Groq, API cifrada por Android y firma fija de pruebas. Actualiza sobre la APK anterior; **no desinstales**.
- La personalidad es una guía para el modelo, no una garantía determinista; debe comprobarse con pruebas reales.

## Compilación de J.A.R.V.I.S. 0.6.3

1. Sube `JARVIS-Jiac-v0.6.3-source.zip` al repositorio de GitHub.
2. En `.github/workflows/build-apk.yml` **del repositorio**, sustituye el ZIP usado en `unzip -q` por `JARVIS-Jiac-v0.6.3-source.zip` y el artefacto por `JARVIS-Jiac-v0.6.3-debug-APK`. No cambies el secreto `JARVIS_DEBUG_KEYSTORE_B64`.
3. Verifica que pasen `:app:testDebugUnitTest` y `:app:assembleDebug` y que GitHub publique el artefacto.
4. Descarga el ZIP del artefacto, extrae `app-debug.apk` e instálalo sobre la versión existente. Verifica memoria, historial y voz.
5. Repite las dos frases de la prueba 33, después una solicitud seria y una consulta factual.

---

# J.A.R.V.I.S. Android v0.6.2 — Fase 2: memoria y personalidad

**Actualización consolidada de la fase 2 sobre la versión 0.6.0**, que incorpora las funciones de memoria de v0.6.1 y una nueva personalidad configurable. No contiene cambios de la fase 3.

## Personalidad

- Predeterminado: **Equilibrado**, inteligencia, trato refinado y sarcasmo elegante ocasional, inspirado en un asistente de ciencia ficción.
- Opciones en **Ajustes → Inteligencia artificial → Personalidad**: Profesional (sin sarcasmo), Equilibrado y Ingenioso.
- Las instrucciones de todos los modos indican expresamente **no bromear en emergencias, salud, seguridad u otras situaciones delicadas**; una indicación al modelo es una preferencia de comportamiento, no una garantía absoluta del proveedor.
- La personalidad afecta las respuestas del modelo Groq/Ollama, tanto en pantalla como en manos libres. Los comandos locales conservan respuestas objetivas.
- Se conserva la memoria personal de hasta 20 recuerdos, el panel «Mis recuerdos», el historial escrito, la voz masculina, Vosk y la conversación continua.
- **Privacidad:** los recuerdos no se envían a Groq por defecto; el usuario debe activar el interruptor en «Mis recuerdos». Nunca subas claves API ni secretos de firma a GitHub.

## Validación recomendada antes de cerrar fase 2

1. Compilar `testDebugUnitTest` y `assembleDebug` en GitHub Actions utilizando `JARVIS-Jiac-v0.6.2-source.zip`, conservando `JARVIS_DEBUG_KEYSTORE_B64`.
2. Instalar APK sobre v0.6.0, **sin desinstalar**, para conservar Groq, Vosk y el historial.
3. Probar memoria: «Jarvis, recuerda que prefiero respuestas breves», «¿Qué recuerdas?», cerrar/reabrir, borrar un recuerdo y comprobar el control opcional de envío a Groq.
4. Probar personalidad equilibrada con consultas ordinarias y serias; confirmar tono, utilidad y ausencia de bromas inadecuadas. Probar también el modo Profesional.
5. Verificar que la conversación continua, el historial escrito, la voz masculina y la escucha bloqueada siguen funcionando. No avanzar a fase 3 si existen defectos por corregir.

**Estado:** código y pruebas locales preparadas. Es necesario compilar y probar en el teléfono antes de declarar finalizada la fase 2.

---

# J.A.R.V.I.S. Android v0.6.1 — Fase 2: recuerdos personales explícitos

**Actualización incremental sobre v0.6.0, sin eliminar el historial ni cambiar la firma fija.**

## Qué incorpora

- Guarda hasta **20 recuerdos separados**, de hasta 240 caracteres cada uno, con la orden **«Jarvis, recuerda que prefiero respuestas breves»** o desde el panel «Mis recuerdos».
- Responde **«¿Qué recuerdas?»** desde la aplicación o manos libres (cuando el dispositivo está desbloqueado).
- Panel **«Mis recuerdos (N)»** en la cabecera del historial para ver, agregar, eliminar recuerdos individuales o borrar todos mediante confirmación.
- Conserva recuerdos al cerrar/reabrir la aplicación y migra una sola vez la memoria individual de versiones anteriores.
- **No envía los recuerdos a Groq/Ollama por defecto.** Solo si se activa «Usar recuerdos en las respuestas de Groq/Ollama» desde «Mis recuerdos», los incluye como contexto con las consultas externas; nunca los incluye desde el modo manos libres cuando el dispositivo está bloqueado.
- La orden de voz «borra todos mis recuerdos» **no borra sin confirmación**: indica cómo abrir el panel para confirmar. Así se reducen pérdidas por reconocimientos falsos.
- El historial visible, el contexto breve, los recuerdos personales y la API Key de Groq son almacenamientos diferentes. Borrar el historial **no borra** recuerdos; borrar recuerdos **no borra** transcripciones del historial ni los datos recibidos previamente por proveedores externos.
- Conserva Groq, voz masculina TTS, Vosk, la conversación continua de 15 segundos y el tratamiento de Markdown.

**Privacidad:** los recuerdos se almacenan en las preferencias privadas de Android, sin cifrado adicional. No guardes contraseñas, claves API, datos bancarios u otra información sensible. No se sincronizan entre dispositivos.

## Pasos de compilación desde Android

1. Sube `JARVIS-Jiac-v0.6.1-source.zip` al repositorio GitHub público.
2. En `.github/workflows/build-apk.yml` del repositorio, cambia **solamente** la línea `unzip -q` para utilizar `JARVIS-Jiac-v0.6.1-source.zip` y el nombre de artefacto a `JARVIS-Jiac-v0.6.1-debug-APK`.
3. Mantén el secreto `JARVIS_DEBUG_KEYSTORE_B64` y toda la sección de firma fija sin cambios. Nunca publiques la clave privada o tu API Key.
4. Verifica que GitHub Actions complete `testDebugUnitTest` y `assembleDebug` con éxito; instala el APK **sobre v0.6.0, sin desinstalar**.
5. Prueba «Jarvis, recuerda que prefiero respuestas breves», «¿Qué recuerdas?», cierre y reapertura, borrado individual y uso opt-in de recuerdos en Groq.

**Estado de validación:** comprobaciones locales de comandos y reglas de memoria superadas. Falta compilar y verificar el APK Android mediante GitHub Actions y probar la funcionalidad en el teléfono.

---

# J.A.R.V.I.S. Android v0.6.0 — Fase 2 (entrega 1): historial escrito local

**Actualización incremental desde v0.5.1.** Esta primera entrega de la fase 2 hace visible el historial de preguntas y respuestas; la memoria personal de preferencias y la personalidad configurable se desarrollarán en pasos siguientes.

## Mejoras

- Guarda preguntas y respuestas de la pantalla principal, reconocimiento de voz desde la aplicación y servicio manos libres (incluidas preguntas de seguimiento y comandos locales).
- Muestra **texto completo de la respuesta almacenada**, separado del resumen hablado por TTS, y fecha/hora cuando se dispone de ella.
- El historial es local y se restaura al cerrar y volver a abrir la aplicación; también se actualiza al regresar desde segundo plano.
- Migra en el primer inicio las últimas entradas disponibles del contexto remoto v0.5.1. Las consultas locales o manos libres antiguas que no se almacenaban antes **no pueden recuperarse**.
- Historial limitado a las **últimas 100 parejas**; cada pregunta se limita a 1.500 caracteres y cada respuesta a 4.000 caracteres para contener el consumo de almacenamiento.
- El panel manos libres tiene sección «Opciones» plegable para que el historial no quede oculto en pantallas pequeñas.
- «Borrar historial» solicita confirmación y elimina también el contexto de conversación local de Groq; **no elimina datos ya recibidos por servicios externos**.
- Conserva la firma fija, clave Groq en Android Keystore, Vosk, conversación continua y voz masculina. No modifica los permisos ni sincroniza el historial con otros dispositivos.

**Privacidad:** el historial está almacenado en las preferencias privadas de la aplicación (sandbox Android), pero **no cuenta con cifrado adicional**. Evita dictar contraseñas u otros datos sensibles si no deseas conservarlos. La memoria de contexto enviada a Groq sigue siendo independiente y limitada a unos pocos turnos.

## Instalación desde el celular

1. Sube `JARVIS-Jiac-v0.6.0-source.zip` a la rama `main` del repositorio público.
2. Edita **solo** la línea de `unzip -q` en `.github/workflows/build-apk.yml` para leer el ZIP 0.6.0 y renombra el artefacto a `JARVIS-Jiac-v0.6.0-debug-APK`.
3. **No edites el paso que restaura `JARVIS_DEBUG_KEYSTORE_B64` ni publiques el secreto.**
4. Espera GitHub Actions, verifica pruebas y compilación; descarga el artefacto e instala el APK encima de v0.5.1, sin desinstalar.
5. Con Groq y Vosk activos, pregunta «Jarvis, háblame de Júpiter» desde segundo plano; abre la aplicación y busca las dos burbujas («TÚ», «J.A.R.V.I.S.»). Cierra/abre la app para comprobar la persistencia.
6. Prueba el modo escrito, el diálogo de borrado y que la clave de Groq se conserve.

**Estado:** las pruebas locales de la política del historial pasaron; la compilación de Android en GitHub y las pruebas en el teléfono siguen pendientes.

---

# J.A.R.V.I.S. Android v0.5.1 — voz natural sin símbolos Markdown

**Actualización incremental sobre 0.5.0.** Se corrige que el motor TTS pronuncie literalmente marcas como `**Júpiter**`. El texto íntegro de la respuesta, el historial conversacional y el contexto de Groq/Ollama no se modifican: se aplica el procesamiento únicamente en `SpokenResponse.concise(...)`, usado por el TTS de la pantalla y del modo manos libres.

- Quita asteriscos y guiones bajos de énfasis Markdown cuando están bien delimitados, marcas de título, viñetas, enlaces Markdown y delimitadores de código.
- Conserva operadores matemáticos como `2 * 3`, `2 ** 3`, `10 × 2`, identificadores con `_` y signos de puntuación.
- Incluye pruebas unitarias de formato y regresión de duración de voz.
- Mantiene la conversación continua, cierre por inactividad, voz masculina, motor Vosk y clave Groq guardada en el teléfono.
- Mantiene el mismo identificador de paquete y el esquema de firma fija del repositorio GitHub.

## Compilar desde el celular

1. Sube `JARVIS-Jiac-v0.5.1-source.zip` al repositorio GitHub en `main`.
2. Edita **solo** la línea de descompresión en el workflow raíz `.github/workflows/build-apk.yml`: cambia el ZIP a `JARVIS-Jiac-v0.5.1-source.zip`.
3. Cambia el nombre del artefacto a `JARVIS-Jiac-v0.5.1-debug-APK` si quieres distinguirlo.
4. Conserva intacta la firma fija `JARVIS_DEBUG_KEYSTORE_B64` de GitHub Actions.
5. Espera a que pasen las pruebas y la compilación; descarga el APK e instálalo sobre v0.5.0 **sin desinstalar**.
6. Di «Jarvis, háblame de Júpiter» y verifica que no pronuncie «asterisco»; repite con un mensaje que contenga multiplicaciones.

**Estado:** comprobación local de Kotlin y pruebas de formato preparadas. La compilación Android y la prueba en el dispositivo están pendientes; no se incluyen claves privadas ni de API en este ZIP.

---

# J.A.R.V.I.S. Android v0.5.0 — conversación continua opcional

**Fase 1: conversación natural y estabilidad (entrega incremental).** Código abierto Apache-2.0.

## Nuevo en v0.5.0

- **Modo conversación continua opcional** desde la sección «Modo manos libres»; viene desactivado por defecto y se recuerda en el dispositivo.
- Tras decir «Jarvis, [pregunta]», el asistente puede aceptar preguntas de seguimiento **sin repetir «Jarvis»** durante los 15 segundos posteriores a cada respuesta de voz.
- Hasta **cuatro preguntas de seguimiento** por activación para reducir el riesgo de aceptar conversaciones ajenas. Después hay que volver a decir «Jarvis».
- Si dices «Jarvis» solo, contesta «A sus órdenes» y espera 12 segundos la primera consulta. Luego, si está activada la conversación continua, permite seguimientos.
- «Terminar conversación» o «Jarvis, descansa» cierran la ventana de seguimiento sin detener permanentemente el detector.
- Cuando termina la ventana, vuelve a escuchar solo la palabra de activación. Se conserva la pausa antieco de 1,2 segundos tras cada respuesta TTS.
- Se respeta el bloqueo: la IA sigue prohibida con el móvil bloqueado salvo que el usuario active explícitamente esa opción en Ajustes.
- Conserva Groq/Ollama, memoria de contexto, voz personalizada, Vosk, hora local y los datos cifrados de la versión anterior.

**Limitaciones:** el asistente no puede escuchar interrupciones de voz mientras está hablando (barge-in); por ahora se usa «Detener voz» desde la app o «Silenciar voz» desde la notificación. La ventana escucha audio ambiente para detectar el siguiente comando y puede reconocer una voz distinta a la del propietario: actívala únicamente donde sea apropiado. Android puede restringir el micrófono con pantalla apagada. Esta entrega debe compilarse y probarse en un teléfono real antes de considerarse estable.

## Instalación y pruebas (sin computadora)

1. Sube `JARVIS-Jiac-v0.5.0-source.zip` al repositorio GitHub en la rama `main`.
2. En `.github/workflows/build-apk.yml` cambia únicamente el nombre del ZIP usado por `unzip -q` a `JARVIS-Jiac-v0.5.0-source.zip`. Mantén la **firma fija ya configurada** (`JARVIS_DEBUG_KEYSTORE_B64`): no pongas la clave en el código ni la compartas.
3. Comprueba en GitHub Actions que pasen las pruebas, la compilación y la etapa de firma, y descarga el artefacto `app-debug.apk`.
4. Instala sobre la versión 0.4.2 **sin desinstalar**. Conserva la clave de Groq del teléfono si el identificador y la firma del APK no cambian.
5. Abre J.A.R.V.I.S.; en «Modo manos libres» activa «Conversación continua (15 segundos)», activa el detector y prueba «Jarvis, ¿qué es Marte?»; tras su respuesta, pregunta «¿Cuánto tarda en dar una vuelta al Sol?» sin decir Jarvis.
6. Verifica que el seguimiento funcione y que, después de 15 segundos de silencio, solo reaccione a una nueva activación «Jarvis». Prueba también «Terminar conversación».

---

## Corrección puntual v0.4.2: hora y fecha fiables

- Detecta variantes habituales de la pregunta horaria (por ejemplo «¿Qué hora es?», «Jarvis, dime la hora», «¿Me puedes decir qué hora es?») y consulta el reloj del propio Android **sin enviar la pregunta a Groq**.
- La misma regla se aplica tanto a la pantalla principal como al modo manos libres y con la pantalla bloqueada, sin solicitar permiso adicional.
- Evita tratar como hora local preguntas diferentes («¿A qué hora empieza la película?», «¿Qué hora es en Tokio?»).
- Incluye nuevas pruebas unitarias, con reloj fijo para validar hora y zona horaria.
- Mantiene el proveedor Groq, la clave del dispositivo, la voz masculina y el detector Vosk sin modificaciones.
- La escucha con pantalla bloqueada se validó satisfactoriamente en una prueba del usuario a 1, 3 y 5 minutos; no equivale a una garantía de funcionamiento indefinido.

## Mejoras de estabilidad v0.4.1

- Se suspende el detector Vosk durante respuestas de voz tanto de la pantalla principal como del servicio manos libres; se espera **1,2 segundos** tras terminar el TTS antes de reanudar la captura para reducir la realimentación acústica.
- El usuario puede **Detener voz** desde la app y **Silenciar voz** desde la notificación de escucha; el servicio puede seguir activado.
- Las respuestas por voz se acortan a aproximadamente 500 caracteres, con invitación a ampliar la explicación; el texto íntegro de IA permanece visible en la pantalla y en su historial local.
- Las respuestas TTS usan identificadores únicos para no reactivar el micrófono por una finalización antigua. Se registran los errores de Vosk sin imprimir conversaciones ni secretos.
- Se agregaron pruebas unitarias para el tiempo de silencio tras hablar y el acortamiento de respuestas.
- Corrección preventiva: hace falta **validar el comportamiento en un Android real**; esta entrega todavía no certifica la estabilidad con pantalla apagada.
 Evolución directa del proyecto 0.3.1: conserva la voz masculina seleccionada, la interfaz futurista y el detector Vosk; añade conversación con un modelo de IA opcional y contexto breve.

## ¿Qué puede hacer?

- Responder preguntas abiertas (explicaciones, recetas, ideas, programación, conversación) **cuando configures un modelo externo**. No hay IA generativa integrada sin configurar el proveedor.
- Escuchar órdenes tras la palabra **«Jarvis»**, tanto con la app abierta como con el servicio activado en segundo plano. La disponibilidad con la pantalla apagada sigue dependiendo de Android/fabricante.
- Hablar con el motor TTS y la **voz masculina** previamente seleccionada. No altera esos ajustes.
- Conservar localmente hasta seis intercambios anteriores como contexto y permitir **Borrar conversación local**.
- Mantener las funciones sin nube: hora, fecha, saludo, abrir ajustes (desde la pantalla activa), memoria local y detección Vosk.
- Conectarse por HTTPS a **Ollama** (`/api/chat`) o una **API compatible con OpenAI** (`/chat/completions`) como Groq u OpenRouter.
- Guardar la API key **cifrada en Android Keystore** y eliminarla desde Ajustes. No incluye credenciales en el APK ni en GitHub.
- Por defecto, **no consulta IA externa con el celular bloqueado**. La opción de permitirlo requiere activación explícita y puede exponer respuestas audibles o texto de preguntas al proveedor.

## Configura una IA conversacional usando solo el celular

1. Instala el APK 0.4 compilado desde **tu repositorio** y abre J.A.R.V.I.S.
2. Toca el engranaje ⚙️ en la parte superior y selecciona **API compatible (Groq, OpenRouter…)**.
3. Puedes registrarte en [GroqCloud](https://console.groq.com/keys) y crear tu **propia clave API**. Nunca la compartas en un chat ni la subas a GitHub.
4. Revisa los costos, cuotas y condiciones del proveedor antes de usarlo. Tener código abierto no hace gratuitas las llamadas a servicios de terceros.
5. Comprueba estos valores:
   - URL: `https://api.groq.com/openai/v1/chat/completions`
   - Modelo: `openai/gpt-oss-20b` (modelo que el proveedor documenta actualmente, sujeto a cambios)
   - Clave API: la creada por ti, introducida **solamente dentro de la app**.
6. Deja desactivado «Permitir respuestas de IA con pantalla bloqueada» inicialmente. Pulsa **Guardar**.
7. Prueba por texto: «Explícame cómo se produce un eclipse»; luego «Resúmelo en dos frases» para comprobar el contexto.
8. Para la prueba de voz di «Jarvis, explícale a alguien de 10 años qué es la inteligencia artificial». La consulta se enviará **como texto reconocido**, no como audio, al proveedor elegido.
9. Si deseas permitir respuestas cuando esté bloqueado, actívalo expresamente y comprende sus riesgos de privacidad. Comienza probando con la pantalla encendida.

Alternativa: selecciona **Servidor Ollama privado** con un endpoint HTTPS de `/api/chat` que tú controles. No publiques un Ollama sin autenticación en Internet.

## Seguridad y límites

- No promete entender literalmente todas las frases: la exactitud depende de Vosk, de la pronunciación, la calidad del micrófono y el modelo conectado.
- No realiza acciones arbitrarias como enviar WhatsApps, compras, movimientos bancarios o saltar bloqueos; esas acciones necesitan integraciones y confirmaciones adicionales.
- Los mensajes que no sean comandos locales se envían al proveedor elegido cuando la IA esté activada. El texto del diálogo se conserva localmente en las preferencias privadas de la app y se comparte como contexto con ese proveedor (máximo seis pares anteriores). Se puede borrar desde la interfaz.
- La versión 0.3.1 tenía reconocimiento **intermitente con pantalla bloqueada**. Esta entrega añade inteligencia conversacional, pero **no certifica la corrección de esa incidencia**; mantiene pendiente el diagnóstico de batería y micrófono.
- El motor de voz puede requerir conexión dependiendo del servicio TTS elegido. Vosk continúa funcionando localmente.
- La clave API está cifrada usando Android Keystore, pero una app maliciosa en un teléfono comprometido podría leer mensajes en pantalla. Evita poner secretos en preguntas.
- Si el APK tiene una firma de depuración distinta, Android puede rechazar la instalación sobre la versión existente; desinstalar puede borrar el modelo Vosk descargado, el historial y la selección local de voz.

## Compilación desde GitHub Actions (sin PC)

1. Sube `JARVIS-Jiac-v0.4.2-source.zip` al repositorio `JARVIS-Jiac` con **Add file → Upload files**.
2. En el workflow **raíz del repositorio** `.github/workflows/build-apk.yml`, cambia **solo** el ZIP de la línea `unzip -q ...` por `JARVIS-Jiac-v0.4.2-source.zip`. No cambies los ajustes de SDK 36 que ya funcionaron en la 0.3.1.
3. Opcional: cambia `name:` dentro de `uses: actions/upload-artifact@v4` por `JARVIS-Jiac-v0.4.2-debug-APK` para distinguir los entregables.
4. Pulsa **Commit changes**. Revisa **Actions** y comprueba `success`, pruebas y APK generado antes de instalar.
5. Descarga el artefacto ZIP en Actions y extrae `app-debug.apk`. Nunca instales un archivo que no provenga de tu compilación.

Este ZIP incluye el código del proyecto y sus pruebas, pero **NO es un APK**. La compilación Android y las pruebas de uso deben verificarse en GitHub Actions y el teléfono.

## Archivos principales

- `data/JarvisPreferences.kt`: preferencias del proveedor, privacidad en bloqueo.
- `data/SecureApiKeyStore.kt`: cifrado de credenciales con Keystore.
- `data/ConversationMemory.kt`: contexto conversacional corto borrable.
- `network/ConversationGateway.kt`: llamadas a Ollama o API compatible a través de HTTPS.
- `wake/JarvisListeningService.kt`: conexión del detector Vosk a las respuestas por IA y TTS.
- `domain/LocalRouting.kt`: evita que preguntas generales se confundan con órdenes locales.
- `ui/JarvisViewModel.kt`, `ui/JarvisScreen.kt`: interfaz de configuración y chat.

Licencia del proyecto: Apache-2.0. Los motores y modelos de terceros conservan sus propias licencias.
