package com.jarvis.openandroid.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class TtsSpeaker(context: Context) : TextToSpeech.OnInitListener {
    private var ready = false
    private var pending: String? = null
    private val speaker = TextToSpeech(context.applicationContext, this)

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val locale = Locale("es", "PE")
        val result = speaker.setLanguage(locale)
        ready = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        pending?.let { speak(it) }
        pending = null
    }

    fun speak(text: String) {
        if (!ready) { pending = text; return }
        speaker.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-response")
    }

    fun stop() { speaker.stop() }
    fun close() { speaker.shutdown() }
}
