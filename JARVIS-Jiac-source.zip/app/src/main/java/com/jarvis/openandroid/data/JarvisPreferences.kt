package com.jarvis.openandroid.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.jarvisDataStore by preferencesDataStore(name = "jarvis_settings")

data class JarvisSettings(
    val endpoint: String = "",
    val model: String = "llama3.2",
    val memory: String = ""
)

class JarvisPreferences(private val context: Context) {
    private val endpointKey = stringPreferencesKey("ollama_endpoint")
    private val modelKey = stringPreferencesKey("ollama_model")
    private val memoryKey = stringPreferencesKey("memory_text")

    val settings: Flow<JarvisSettings> = context.jarvisDataStore.data.map { preferences ->
        JarvisSettings(
            endpoint = preferences[endpointKey].orEmpty(),
            model = preferences[modelKey] ?: "llama3.2",
            memory = preferences[memoryKey].orEmpty()
        )
    }

    suspend fun saveEndpoint(endpoint: String, model: String) {
        context.jarvisDataStore.edit { preferences ->
            preferences[endpointKey] = endpoint.trim()
            preferences[modelKey] = model.trim().ifBlank { "llama3.2" }
        }
    }

    suspend fun saveMemory(text: String) {
        context.jarvisDataStore.edit { preferences ->
            preferences[memoryKey] = text
        }
    }
}
