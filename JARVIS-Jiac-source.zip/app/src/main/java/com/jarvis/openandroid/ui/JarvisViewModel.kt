package com.jarvis.openandroid.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.openandroid.data.JarvisPreferences
import com.jarvis.openandroid.data.JarvisSettings
import com.jarvis.openandroid.domain.AssistantAction
import com.jarvis.openandroid.domain.LocalCommandEngine
import com.jarvis.openandroid.network.OllamaRemoteEngine
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch


data class ChatMessage(val text: String, val isUser: Boolean)

data class JarvisUiState(
    val messages: List<ChatMessage> = listOf(ChatMessage("Sistemas iniciados. Di 'hola Jarvis' para comenzar.", false)),
    val settings: JarvisSettings = JarvisSettings(),
    val busy: Boolean = false,
    val listening: Boolean = false
)

class JarvisViewModel(application: Application) : AndroidViewModel(application) {
    private val preferences = JarvisPreferences(application.applicationContext)
    private val local = LocalCommandEngine()
    private val remote = OllamaRemoteEngine()
    private val state = MutableStateFlow(JarvisUiState())
    val uiState = state.asStateFlow()

    private val _speech = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val speech = _speech.asSharedFlow()
    private val _actions = MutableSharedFlow<AssistantAction>(extraBufferCapacity = 2)
    val actions = _actions.asSharedFlow()

    init {
        viewModelScope.launch {
            preferences.settings.collect { updated ->
                state.update { it.copy(settings = updated) }
            }
        }
    }

    fun setListening(value: Boolean) { state.update { it.copy(listening = value) } }

    fun submit(rawText: String) {
        val text = rawText.trim()
        if (text.isBlank() || state.value.busy) return
        state.update { it.copy(busy = true, messages = it.messages + ChatMessage(text, true)) }
        viewModelScope.launch {
            try {
                val config = state.value.settings
                val localAnswer = local.answer(text, config.memory)
                val answer = if (localAnswer != null) {
                    if (localAnswer.newMemory != null) preferences.saveMemory(localAnswer.newMemory)
                    localAnswer.action?.let { _actions.emit(it) }
                    localAnswer.text
                } else if (config.endpoint.isNotBlank()) {
                    remote.ask(config.endpoint, config.model, text)
                } else {
                    "Ese comando todavía no está disponible en modo local. Puedes configurar un modelo de Ollama en el icono de ajustes."
                }
                addJarvisAnswer(answer)
            } catch (error: Exception) {
                addJarvisAnswer("No pude completar la solicitud: ${error.message ?: "error desconocido"}")
            } finally {
                state.update { it.copy(busy = false) }
            }
        }
    }

    fun addJarvisAnswer(text: String) {
        state.update { it.copy(messages = it.messages + ChatMessage(text, false)) }
        _speech.tryEmit(text)
    }

    fun saveRemoteSettings(endpoint: String, model: String) {
        viewModelScope.launch {
            val candidate = endpoint.trim()
            if (candidate.isNotEmpty() && !candidate.matches(Regex("https://[^\\s/]+/api/chat/?"))) {
                addJarvisAnswer("Configura una URL HTTPS que termine en /api/chat; deja vacío para usar solo comandos locales.")
                return@launch
            }
            preferences.saveEndpoint(candidate.removeSuffix("/"), model)
            addJarvisAnswer(if (candidate.isBlank()) "Modo de comandos locales activado." else "Proveedor Ollama guardado. Las preguntas abiertas se enviarán a ese servidor.")
        }
    }
}
