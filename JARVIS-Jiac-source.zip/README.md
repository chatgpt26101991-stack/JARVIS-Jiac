# J.A.R.V.I.S. Android — v0.1.0

Asistente personal Android de código abierto (Apache-2.0), preparado para motor de comandos local y proveedor opcional de Ollama por HTTPS.

**Estado:** código fuente inicial entregado. No compilado ni probado en un dispositivo dentro de este entorno; verifica compilación y pruebas con Android Studio.

## Requisitos

- PC Windows con Android Studio reciente compatible con AGP 9.3.
- JDK 17 (puedes usar el JDK incluido con Android Studio).
- Android SDK 37 instalado desde **Settings > Android SDK > SDK Platforms**.
- Android físico 8.0+ (API 26) o emulador con servicio de reconocimiento de voz disponible.
- Conexión a internet para descargar las dependencias de Gradle.

## Cómo abrir y ejecutar (Windows PowerShell)

1. Extrae el ZIP a una carpeta, por ejemplo `C:\Proyectos\JARVIS-Android-v0.1`.
2. Abre una terminal PowerShell en esa carpeta.
3. Descarga y verifica el wrapper oficial (necesario una única vez):

```powershell
powershell -ExecutionPolicy Bypass -File .\setup-wrapper.ps1
```

El instalador descarga **solo** el `gradle-wrapper.jar` oficial de `https://services.gradle.org` y compara SHA256 contra la suma publicada por Gradle. Revisa el script antes de ejecutarlo.

4. En Android Studio, usa **Open** y selecciona la carpeta raíz que contiene `settings.gradle.kts`.
5. Espera la sincronización. Si te falta API 37, instálala desde SDK Manager.
6. Conecta un teléfono con depuración USB habilitada o crea un emulador. Pulsa **Run ▶**.
7. Alternativamente, desde PowerShell compila y ejecuta tests:

```powershell
.\gradlew.bat :app:testDebugUnitTest
.\gradlew.bat :app:assembleDebug
```

El APK de depuración se genera en `app\build\outputs\apk\debug\app-debug.apk`.

## Comandos de prueba

- `Hola Jarvis`
- `¿Qué hora es?`
- `¿Qué fecha es hoy?`
- `Recuerda que mi color favorito es azul`
- `¿Qué recuerdas?`
- `Borra el recuerdo`
- `Abre ajustes`
- `¿Qué puedes hacer?`

**Nota:** la voz usa `SpeechRecognizer`/`TextToSpeech` instalados en Android. Dependiendo del dispositivo, su motor puede ser propietario y requerir internet. El resto del modo local no requiere un servidor de IA.

## Modo híbrido (opcional)

1. Configura un modelo en tu servidor Ollama de confianza; por ejemplo `llama3.2`.
2. Publica **/api/chat** detrás de un gateway **HTTPS con autenticación y protección de acceso**. El inicio rápido no incluye autenticación para endpoints externos, por lo que **NO publiques Ollama abiertamente en internet**.
3. En la app, pulsa ⚙, pega la URL completa `https://tu-servidor-seguro/api/chat` y escribe el modelo disponible.
4. Las preguntas abiertas irán a Ollama. Fecha, hora, memoria y ajustes siguen resolviéndose en el celular.

La versión 0.1 solo soporta el formato Ollama `/api/chat` sin streaming. No guarda credenciales; si tu gateway requiere API Key, deberás implementar un flujo seguro de autenticación antes de usarlo.

## Diseño y privacidad

```
app/
  src/main/java/com/jarvis/openandroid/
    MainActivity.kt             # permisos, voz y acciones Android
    domain/AssistantEngine.kt   # comandos deterministas + acciones tipadas
    data/JarvisPreferences.kt   # DataStore: configuración y 1 recuerdo
    network/OllamaRemoteEngine.kt # adaptador de modelo externo
    speech/TtsSpeaker.kt        # TextToSpeech y cierre de recursos
    ui/JarvisViewModel.kt       # flujo de estado, decisiones y errores
    ui/JarvisScreen.kt          # Jetpack Compose, interfaz y chat
  src/test/...                 # pruebas básicas del motor local
```

- No incluye secretos ni claves de API en el repositorio.
- Deshabilitado el backup automático de la app en este prototipo.
- No se envía a Ollama el recuerdo local.
- El historial mostrado está en memoria RAM: se pierde al cerrar el proceso (todavía no implementamos historial persistente).
- Un único recuerdo de texto se guarda localmente en DataStore; no está cifrado por una clave propia.
- Un modelo **LLM local en el propio teléfono** está previsto para una siguiente iteración. El módulo actual de comandos locales NO es un LLM.
- La escucha permanente de micrófono en segundo plano NO está implementada.
- No hay automatizaciones peligrosas ni ejecución arbitraria de comandos.

## Limitaciones de esta entrega

El `gradle-wrapper.jar` binario no se incluye en el ZIP para evitar distribuir un binario que no se haya validado; se obtiene del distribuidor oficial al correr `setup-wrapper.ps1`. El código no se ha compilado en este entorno, que carece del SDK de Android y de acceso a los artefactos de Gradle. Si Android Studio informa un error de sincronización, captura el texto exacto y lo corregimos.

## Próximos hitos

1. QA de instalación, micrófono, TextToSpeech y UI en dispositivo físico.
2. Separa capas en módulos Gradle si el proyecto crece.
3. Añade proveedor LLM en el dispositivo (con soporte según hardware/modelo), Room para historial y recuperación.
4. Autenticación segura del gateway, autorización de acciones y registros de auditoría.
5. Activación por palabra clave, evaluando restricciones de Android y consumo de batería.

Licencia: Apache License, Version 2.0. Revisa los avisos y licencias de componentes y modelos de terceros antes de redistribuirlos.
